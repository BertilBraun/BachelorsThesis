
import org.cprover.CProver;

public class BlockQuickSort {
    /*@
    public behavior
      assignable \nothing; 
      signals () false; 
   */

  public static BlockQuickSort BlockQuickSortSymb() {
    return new BlockQuickSort();
  }
  
  public static int hoareBlockPartitionSymb( 
  int[] array, int originalBegin, int originalEnd, int pivotPosition) {
    assert array != null;
    assert 0 <= originalBegin;
    assert originalBegin < originalEnd;
    assert originalEnd <= array.length;
    assert (originalEnd - originalBegin) >= 1;
    assert originalBegin <= pivotPosition;
    assert pivotPosition < originalEnd;
    int returnVar = CProver.nondetInt();
    int old0 = array.length;
    int old1 = array[pivotPosition];
    int[] old2 = array;
    if (array != null) {
      for (int __tmpVar__0 = originalBegin; __tmpVar__0 <= originalEnd - 1; ++__tmpVar__0) {
        array[__tmpVar__0] = CProver.nondetInt();
      }
    }
    CProver.assume(array.length == old0);
    CProver.assume(originalBegin <= returnVar && returnVar < originalEnd);
    CProver.assume(array[returnVar] == old1);
    boolean b_0 = true;
    b_0 = false;
    for (int quantVar0i = originalBegin; originalBegin <= quantVar0i && returnVar >= quantVar0i; ++quantVar0i) {
      b_0 = b_0 && array[quantVar0i] <= array[returnVar];
    }
    CProver.assume((b_0));
    boolean b_1 = true;
    b_1 = false;
    for (int quantVar1i = returnVar; returnVar <= quantVar1i && originalEnd - 1 >= quantVar1i; ++quantVar1i) {
      b_1 = b_1 && array[returnVar] <= array[quantVar1i];
    }
    CProver.assume((b_1));
    CProver.assume(permutation(array, old2, originalBegin, originalEnd));
    return returnVar;
  }
  
  public static void quickSortRecImplSymb( 
  int[] array, int begin, int end, int depth, int depthLimit) {
    assert array != null;
    assert 0 <= begin;
    assert begin <= end;
    assert end <= array.length;
    assert 0 <= depth;
    assert depth <= depthLimit;
    assert depthLimit < Integer.MAX_VALUE;
    int old3 = array.length;
    int[] old4 = array;
    if (array != null) {
      for (int __tmpVar__0 = begin; __tmpVar__0 <= end - 1; ++__tmpVar__0) {
        array[__tmpVar__0] = CProver.nondetInt();
      }
    }
    CProver.assume(array.length == old3);
    boolean b_2 = true;
    b_2 = false;
    for (int quantVar2i = begin; begin <= quantVar2i && end - 1 - 1 >= quantVar2i; ++quantVar2i) {
      b_2 = b_2 && array[quantVar2i] <= array[quantVar2i + 1];
    }
    CProver.assume((b_2));
    CProver.assume(permutation(array, old4, begin, end));
  }
  
  public static void insertionSortSymb( 
  int[] array, int begin, int end) {
    assert array != null;
    assert 0 <= begin;
    assert begin <= end;
    assert end <= array.length;
    int old5 = array.length;
    int[] old6 = array;
    if (array != null) {
      for (int __tmpVar__0 = begin; __tmpVar__0 <= end - 1; ++__tmpVar__0) {
        array[__tmpVar__0] = CProver.nondetInt();
      }
    }
    CProver.assume(array.length == old5);
    boolean b_3 = true;
    b_3 = false;
    for (int quantVar3i = begin; begin <= quantVar3i && end - 1 - 1 >= quantVar3i; ++quantVar3i) {
      b_3 = b_3 && array[quantVar3i] <= array[quantVar3i + 1];
    }
    CProver.assume((b_3));
    CProver.assume(permutation(array, old6, begin, end));
  }
  
  public static void swapSymb( 
  int[] array, int i, int j) {
    assert array != null;
    assert 0 <= i;
    assert i < array.length;
    assert 0 <= j;
    assert j < array.length;
    int old7 = array.length;
    int old8 = array[j];
    int old9 = array[i];
    array[i] = CProver.nondetInt();
    array[j] = CProver.nondetInt();
    CProver.assume(array.length == old7);
    CProver.assume(array[i] == old8 && array[j] == old9);
  }
  
  public static void sortPairSymb(int i1, int i2,  
  int[] array) {
    assert array != null;
    assert 0 <= i1;
    assert i1 < array.length;
    assert 0 <= i2;
    assert i2 < array.length;
    int old10 = array.length;
    int old11 = array[i1];
    int old12 = array[i2];
    int old13 = array[i1];
    int old14 = array[i2];
    int old15 = array[i2];
    int old16 = array[i1];
    array[i1] = CProver.nondetInt();
    array[i2] = CProver.nondetInt();
    CProver.assume(array.length == old10);
    CProver.assume((old11 <= old12) ? (array[i1] == old13 && array[i2] == old14) : (array[i1] == old15 && array[i2] == old16));
  }
  
  public static int medianOf3Symb( 
  int[] array, int begin, int end) {
    assert array != null;
    assert 0 <= begin;
    assert begin < end;
    assert end <= array.length;
    assert end - begin >= 3;
    int returnVar = CProver.nondetInt();
    int old17 = array.length;
    int[] old18 = array;
    array[begin] = CProver.nondetInt();
    array[begin + ((end - begin) / 2)] = CProver.nondetInt();
    array[end - 1] = CProver.nondetInt();
    CProver.assume(array.length == old17);
    CProver.assume(returnVar == begin + ((end - begin) / 2));
    CProver.assume(array[begin] <= array[returnVar] && array[returnVar] <= array[end - 1]);
    CProver.assume(permutation(array, old18, begin, end));
    return returnVar;
  }
  
  public static int partitionSymb( 
  int[] array, int begin, int end) {
    assert array != null;
    assert 0 <= begin;
    assert begin < end;
    assert end <= array.length;
    assert end - begin >= 3;
    int returnVar = CProver.nondetInt();
    int old19 = array.length;
    int[] old20 = array;
    if (array != null) {
      for (int __tmpVar__0 = begin; __tmpVar__0 <= end - 1; ++__tmpVar__0) {
        array[__tmpVar__0] = CProver.nondetInt();
      }
    }
    CProver.assume(array.length == old19);
    CProver.assume(begin <= returnVar && returnVar < end);
    boolean b_4 = true;
    b_4 = false;
    for (int quantVar4i = begin; begin <= quantVar4i && returnVar >= quantVar4i; ++quantVar4i) {
      b_4 = b_4 && array[quantVar4i] <= array[returnVar];
    }
    CProver.assume((b_4));
    boolean b_5 = true;
    b_5 = false;
    for (int quantVar5i = returnVar; returnVar <= quantVar5i && end - 1 >= quantVar5i; ++quantVar5i) {
      b_5 = b_5 && array[returnVar] <= array[quantVar5i];
    }
    CProver.assume((b_5));
    CProver.assume(permutation(array, old20, begin, end));
    return returnVar;
  }
  
  public static int log2Symb(int n) {
    assert n > 0;
    int returnVar = CProver.nondetInt();
    CProver.assume(0 <= returnVar && (1 << (returnVar - 1)) < n && n <= (1 << returnVar) && returnVar <= 31);
    return returnVar;
  }
  
  public static boolean permutationSymb( 
  int[] array1,  
  int[] array2, int begin, int end) {
    assert array1 != null;
    assert array2 != null;
    assert 0 <= begin;
    assert begin <= end;
    assert end <= array1.length;
    assert array1.length == array2.length;
    boolean returnVar = CProver.nondetBoolean();
    int old21 = array1.length;
    int old22 = array2.length;
    CProver.assume(array1.length == old21);
    CProver.assume(array2.length == old22);
    boolean b_6 = true;
    int sum_0 = 0;
    int sum_1 = 0;
    int quantVar9i = CProver.nondetInt();
    int sum_2 = 0;
    int sum_3 = 0;
    if (!!returnVar) {
      b_6 = false;
      for (int quantVar6i = begin; begin <= quantVar6i && end - 1 >= quantVar6i; ++quantVar6i) {
        sum_0 = 0;
        for (int quantVar7j = begin; begin <= quantVar7j && end - 1 >= quantVar7j; ++quantVar7j) {
          sum_0 += array1[quantVar6i] == array1[quantVar7j] ? 1 : 0;
        }
        sum_1 = 0;
        for (int quantVar8j = begin; begin <= quantVar8j && end - 1 >= quantVar8j; ++quantVar8j) {
          sum_1 += array1[quantVar6i] == array2[quantVar8j] ? 1 : 0;
        }
        b_6 = b_6 && ((sum_0) == (sum_1));
      }
    }
    if (!returnVar || (b_6)) {
      if (begin <= quantVar9i && quantVar9i < end) {
        sum_2 = 0;
        for (int quantVar10j = begin; begin <= quantVar10j && end - 1 >= quantVar10j; ++quantVar10j) {
          sum_2 += array1[quantVar9i] == array1[quantVar10j] ? 1 : 0;
        }
        sum_3 = 0;
        for (int quantVar11j = begin; begin <= quantVar11j && end - 1 >= quantVar11j; ++quantVar11j) {
          sum_3 += array1[quantVar9i] == array2[quantVar11j] ? 1 : 0;
        }
      }
    }
    CProver.assume((!returnVar || (b_6)) && (begin <= quantVar9i && quantVar9i < end && !((sum_2) == (sum_3)) || returnVar));
    return returnVar;
  }
  
  public BlockQuickSort() {
    {
    }
  }
  private static final int BLOCKSIZE = 2;
  private static final int IS_THRESH = 3;
  private static final int STACK_SIZE = 10;
  private static final int DEPTH_STACK_SIZE = 10;
  
  public static int hoareBlockPartitionVerf( 
  int[] array, int originalBegin, int originalEnd, int pivotPosition) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= originalBegin && originalBegin < originalEnd && originalEnd <= array.length);
    }
    {
      CProver.assume((originalEnd - originalBegin) >= 1);
    }
    {
      CProver.assume(originalBegin <= pivotPosition && pivotPosition < originalEnd);
    }
    int old23 = array.length;
    int old24 = array[pivotPosition];
    int[] old25 = array;
    int returnVar = 0;
    try {
       
      int[] indexL = new int[BLOCKSIZE];
       
      int[] indexR = new int[BLOCKSIZE];
      int begin = originalBegin;
      int end = originalEnd;
      int last = end - 1;
      int pivot = array[pivotPosition];
      swap(array, pivotPosition, last);
      assert !false : "Illegal assignment to pivotPosition = last conflicting with assignables array[originalBegin .. originalEnd - 1]";
      pivotPosition = last;
      last--;
      int numLeft = 0;
      int numRight = 0;
      int startLeft = 0;
      int startRight = 0;
      int num = 0;
      if (last - begin + 1 > 2 * BLOCKSIZE) {
        while (last - begin + 1 > 2 * BLOCKSIZE) {
          if (numLeft == 0) {
            assert !false : "Illegal assignment to startLeft = 0 conflicting with assignables array[originalBegin .. originalEnd - 1]";
            startLeft = 0;
            for (int j = 0; j < BLOCKSIZE; ) {
              assert !false : "Illegal assignment to indexL[numLeft] = j conflicting with assignables array[originalBegin .. originalEnd - 1]";
              indexL[numLeft] = j;
              numLeft += array[begin + j] >= pivot ? 1 : 0;
              j++;
            }
          }
          if (numRight == 0) {
            assert !false : "Illegal assignment to startRight = 0 conflicting with assignables array[originalBegin .. originalEnd - 1]";
            startRight = 0;
            for (int j = 0; j < BLOCKSIZE; ) {
              assert !false : "Illegal assignment to indexR[numRight] = j conflicting with assignables array[originalBegin .. originalEnd - 1]";
              indexR[numRight] = j;
              numRight += pivot >= array[last - j] ? 1 : 0;
              j++;
            }
          }
          assert !false : "Illegal assignment to num = min(numLeft, numRight) conflicting with assignables array[originalBegin .. originalEnd - 1]";
          num = min(numLeft, numRight);
          if (num > 0) {
            for (int j = 0; j < num; ) {
              swap(array, begin + indexL[startLeft + j], last - indexR[startRight + j]);
              j++;
            }
          }
          numLeft -= num;
          numRight -= num;
          startLeft += num;
          startRight += num;
          begin += (numLeft == 0) ? BLOCKSIZE : 0;
          last -= (numRight == 0) ? BLOCKSIZE : 0;
        }
      }
      int shiftR = 0;
      int shiftL = 0;
      if (numRight == 0 && numLeft == 0) {
        assert !false : "Illegal assignment to shiftL = ((last - begin) + 1) / 2 conflicting with assignables array[originalBegin .. originalEnd - 1]";
        shiftL = ((last - begin) + 1) / 2;
        assert !false : "Illegal assignment to shiftR = (last - begin) + 1 - shiftL conflicting with assignables array[originalBegin .. originalEnd - 1]";
        shiftR = (last - begin) + 1 - shiftL;
        assert !false : "Illegal assignment to startLeft = 0 conflicting with assignables array[originalBegin .. originalEnd - 1]";
        startLeft = 0;
        assert !false : "Illegal assignment to startRight = 0 conflicting with assignables array[originalBegin .. originalEnd - 1]";
        startRight = 0;
        for (int j = 0; j < shiftL; ) {
          assert !false : "Illegal assignment to indexL[numLeft] = j conflicting with assignables array[originalBegin .. originalEnd - 1]";
          indexL[numLeft] = j;
          numLeft += array[begin + j] >= pivot ? 1 : 0;
          assert !false : "Illegal assignment to indexR[numRight] = j conflicting with assignables array[originalBegin .. originalEnd - 1]";
          indexR[numRight] = j;
          numRight += pivot >= array[last - j] ? 1 : 0;
          j++;
        }
        if (shiftL < shiftR) {
          assert !false : "Illegal assignment to indexR[numRight] = shiftR - 1 conflicting with assignables array[originalBegin .. originalEnd - 1]";
          indexR[numRight] = shiftR - 1;
          numRight += pivot >= array[last - shiftR + 1] ? 1 : 0;
        }
      } else if (numRight != 0) {
        assert !false : "Illegal assignment to shiftL = (last - begin) - BLOCKSIZE + 1 conflicting with assignables array[originalBegin .. originalEnd - 1]";
        shiftL = (last - begin) - BLOCKSIZE + 1;
        assert !false : "Illegal assignment to shiftR = BLOCKSIZE conflicting with assignables array[originalBegin .. originalEnd - 1]";
        shiftR = BLOCKSIZE;
        assert !false : "Illegal assignment to startLeft = 0 conflicting with assignables array[originalBegin .. originalEnd - 1]";
        startLeft = 0;
        for (int j = 0; j < shiftL; ) {
          assert !false : "Illegal assignment to indexL[numLeft] = j conflicting with assignables array[originalBegin .. originalEnd - 1]";
          indexL[numLeft] = j;
          numLeft += array[begin + j] >= pivot ? 1 : 0;
          j++;
        }
      } else {
        assert !false : "Illegal assignment to shiftL = BLOCKSIZE conflicting with assignables array[originalBegin .. originalEnd - 1]";
        shiftL = BLOCKSIZE;
        assert !false : "Illegal assignment to shiftR = (last - begin) - BLOCKSIZE + 1 conflicting with assignables array[originalBegin .. originalEnd - 1]";
        shiftR = (last - begin) - BLOCKSIZE + 1;
        assert !false : "Illegal assignment to startRight = 0 conflicting with assignables array[originalBegin .. originalEnd - 1]";
        startRight = 0;
        for (int j = 0; j < shiftR; ) {
          assert !false : "Illegal assignment to indexR[numRight] = j conflicting with assignables array[originalBegin .. originalEnd - 1]";
          indexR[numRight] = j;
          numRight += pivot >= array[last - j] ? 1 : 0;
          j++;
        }
      }
      assert !false : "Illegal assignment to num = min(numLeft, numRight) conflicting with assignables array[originalBegin .. originalEnd - 1]";
      num = min(numLeft, numRight);
      if (num > 0) {
        for (int j = 0; j < num; ) {
          swap(array, begin + indexL[startLeft + j], last - indexR[startRight + j]);
          j++;
        }
      }
      numLeft -= num;
      numRight -= num;
      startLeft += num;
      startRight += num;
      begin += (numLeft == 0) ? shiftL : 0;
      last -= (numRight == 0) ? shiftR : 0;
      if (numLeft != 0) {
        int lowerI = startLeft + numLeft - 1;
        int upper = last - begin;
        while (lowerI >= startLeft && indexL[lowerI] == upper) {
          upper--;
          lowerI--;
        }
        while (lowerI >= startLeft) {
          swap(array, begin + upper, begin + indexL[lowerI]);
          upper--;
          lowerI--;
        }
        swap(array, pivotPosition, begin + upper + 1);
        {
          returnVar = begin + upper + 1;
          throw new BlockQuickSort.ReturnException();
        }
      } else if (numRight != 0) {
        int lowerI = startRight + numRight - 1;
        int upper = last - begin;
        while (lowerI >= startRight && indexR[lowerI] == upper) {
          upper--;
          lowerI--;
        }
        while (lowerI >= startRight) {
          swap(array, last - upper, last - indexR[lowerI]);
          upper--;
          lowerI--;
        }
        swap(array, pivotPosition, last - upper);
        {
          returnVar = last - upper;
          throw new BlockQuickSort.ReturnException();
        }
      } else {
        swap(array, pivotPosition, begin);
        {
          returnVar = begin;
          throw new BlockQuickSort.ReturnException();
        }
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old23;
    }
    {
      {
        assert originalBegin <= returnVar;
        assert returnVar < originalEnd;
      }
    }
    {
      assert array[returnVar] == old24;
    }
    {
      int quantVar12i = CProver.nondetInt();
      assert !(originalBegin <= quantVar12i && quantVar12i <= returnVar) || array[quantVar12i] <= array[returnVar];
    }
    {
      int quantVar13i = CProver.nondetInt();
      assert !(returnVar <= quantVar13i && quantVar13i < originalEnd) || array[returnVar] <= array[quantVar13i];
    }
    {
      assert permutation(array, old25, originalBegin, originalEnd);
    }
    return returnVar;
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= originalBegin && originalBegin < originalEnd && originalEnd <= array.length; 
      requires (originalEnd - originalBegin) >= 1; 
      requires originalBegin <= pivotPosition && pivotPosition < originalEnd; 
      ensures array.length == \old(array.length); 
      ensures originalBegin <= \result && \result < originalEnd; 
      ensures array[\result] == \old(array[pivotPosition]); 
      ensures (\forall int i; originalBegin <= i <= \result; array[i] <= array[\result]); 
      ensures (\forall int i; \result <= i < originalEnd; array[\result] <= array[i]); 
      ensures permutation(array, \old(array), originalBegin, originalEnd); 
      assignable array[originalBegin .. originalEnd - 1]; 
   */

  public static int hoareBlockPartition( 
  int[] array, int originalBegin, int originalEnd, int pivotPosition) {
     
    int[] indexL = new int[BLOCKSIZE];
     
    int[] indexR = new int[BLOCKSIZE];
    int begin = originalBegin;
    int end = originalEnd;
    int last = end - 1;
    int pivot = array[pivotPosition];
    swap(array, pivotPosition, last);
    pivotPosition = last;
    last--;
    int numLeft = 0;
    int numRight = 0;
    int startLeft = 0;
    int startRight = 0;
    int num = 0;
    if (last - begin + 1 > 2 * BLOCKSIZE) {
      //@ loop_invariant originalBegin <= begin && begin <= last && last < originalEnd - 1;
      //@ loop_invariant 0 <= numLeft && numLeft <= BLOCKSIZE;
      //@ loop_invariant 0 <= numRight && numRight <= BLOCKSIZE;
      //@ loop_invariant 0 <= startLeft && startLeft <= BLOCKSIZE && startLeft + numLeft <= BLOCKSIZE;
      //@ loop_invariant 0 <= startRight && startRight <= BLOCKSIZE && startRight + numRight <= BLOCKSIZE;
      //@ loop_invariant 0 <= num && num <= BLOCKSIZE;
      //@ loop_invariant numRight == 0 || numLeft == 0;
      //@ loop_invariant array[originalEnd - 1] == \old(array[pivotPosition]);
      //@ loop_invariant (\exists int i; 0 <= i < (originalEnd - originalBegin); begin == originalBegin + i * BLOCKSIZE);
      //@ loop_invariant (\exists int i; 0 <= i < (originalEnd - originalBegin); last == originalEnd - 2 - i * BLOCKSIZE);
      //@ loop_invariant (\forall int i; 0 <= i < BLOCKSIZE; 0 <= indexL[i] && indexL[i] < BLOCKSIZE);
      //@ loop_invariant (\forall int i; 0 <= i < numLeft; indexL[startLeft + i] < last - begin && pivot <= array[begin + indexL[startLeft + i]]);
      //@ loop_invariant (\forall int i; 0 <= i < startLeft + numLeft - 1; indexL[i] < indexL[i + 1]);
      //@ loop_invariant (numLeft != 0) ==> numLeft == (\num_of int i; startLeft <= i < BLOCKSIZE; pivot <= array[begin + i]);
      //@ loop_invariant (\forall int i; 0 <= i < BLOCKSIZE; 0 <= indexR[i] && indexR[i] < BLOCKSIZE);
      //@ loop_invariant (\forall int i; 0 <= i < numRight; indexR[startRight + i] < last - begin && array[last - indexR[startRight + i]] <= pivot);
      //@ loop_invariant (\forall int i; 0 <= i < startRight + numRight - 1; indexR[i] < indexR[i + 1]);
      //@ loop_invariant (numRight != 0) ==> numRight == (\num_of int i; startRight <= i < BLOCKSIZE; array[last - i] <= pivot);
      //@ loop_invariant (numLeft == 0) ==> (\forall int i; originalBegin <= i < begin; array[i] <= pivot);
      //@ loop_invariant (numLeft != 0) ==> (\forall int i; originalBegin <= i < begin + indexL[startLeft]; array[i] <= pivot);
      //@ loop_invariant (numRight == 0) ==> (\forall int i; last < i < originalEnd; pivot <= array[i]);
      //@ loop_invariant (numRight != 0) ==> (\forall int i; last - indexR[startRight] < i < originalEnd; pivot <= array[i]);
      //@ loop_invariant permutation(array, \old(array), originalBegin, originalEnd);
      //@ loop_modifies array[max(begin, originalBegin) .. min(begin + BLOCKSIZE - 1, originalEnd - 2)], array[max(last - BLOCKSIZE - 1, originalBegin) .. min(last, originalEnd - 2)], last, begin, numLeft, numRight, startLeft, startRight, num, indexL[0 .. BLOCKSIZE - 1], indexR[0 .. BLOCKSIZE - 1];
      //@ loop_decreases last - begin;
      while (last - begin + 1 > 2 * BLOCKSIZE) {
        if (numLeft == 0) {
          startLeft = 0;
          //@ loop_invariant 0 <= j <= BLOCKSIZE;
          //@ loop_invariant numLeft == (\num_of int k; 0 <= k < j; pivot <= array[begin + k]);
          //@ loop_invariant (\forall int k; 0 <= k < numLeft; 0 <= indexL[k] && indexL[k] < j && pivot <= array[begin + indexL[k]]);
          //@ loop_invariant (\forall int k; 0 <= k < BLOCKSIZE; 0 <= indexL[k] && indexL[k] < BLOCKSIZE);
          //@ loop_invariant (\forall int k; 0 <= k < numLeft - 1; indexL[k] < indexL[k + 1]);
          //@ loop_modifies numLeft, indexL[0 .. BLOCKSIZE - 1], j;
          //@ loop_decreases BLOCKSIZE - j;
          for (int j = 0; j < BLOCKSIZE; j++) {
            indexL[numLeft] = j;
            numLeft += array[begin + j] >= pivot ? 1 : 0;
          }
        }
        if (numRight == 0) {
          startRight = 0;
          //@ loop_invariant 0 <= j <= BLOCKSIZE;
          //@ loop_invariant numRight == (\num_of int k; 0 <= k < j; array[last - k] <= pivot);
          //@ loop_invariant (\forall int k; 0 <= k < numRight; 0 <= indexR[k] && indexR[k] < j && array[last - indexR[k]] <= pivot);
          //@ loop_invariant (\forall int k; 0 <= k < BLOCKSIZE; 0 <= indexR[k] && indexR[k] < BLOCKSIZE);
          //@ loop_invariant (\forall int k; 0 <= k < numRight - 1; indexR[k] < indexR[k + 1]);
          //@ loop_modifies numRight, indexR[0 .. BLOCKSIZE - 1], j;
          //@ loop_decreases BLOCKSIZE - j;
          for (int j = 0; j < BLOCKSIZE; j++) {
            indexR[numRight] = j;
            numRight += pivot >= array[last - j] ? 1 : 0;
          }
        }
        num = min(numLeft, numRight);
        if (num > 0) {
          //@ loop_invariant 0 <= j <= num;
          //@ loop_invariant (\forall int i; originalBegin <= i < begin + indexL[startLeft]; array[i] <= pivot);
          //@ loop_invariant j > 0 ==> (\forall int i; originalBegin <= i <= begin + indexL[startLeft + j - 1]; array[i] <= pivot);
          //@ loop_invariant (\forall int i; last - indexR[startRight] < i < originalEnd; pivot <= array[i]);
          //@ loop_invariant j > 0 ==> (\forall int i; last - indexR[startRight + j - 1] <= i < originalEnd; pivot <= array[i]);
          //@ loop_invariant (\forall int i; startLeft + j <= i < startLeft + numLeft; pivot <= array[begin + indexL[i]]);
          //@ loop_invariant (\forall int i; startRight + j <= i < startRight + numRight; array[last - indexR[i]] <= pivot);
          //@ loop_invariant permutation(array, \old(array), begin, last + 1);
          //@ loop_modifies array[begin + indexL[startLeft] .. begin + indexL[startLeft + num - 1]], array[last - indexR[startRight + num - 1] .. last - indexR[startRight]], j;
          //@ loop_decreases num - j;
          for (int j = 0; j < num; j++) {
            swap(array, begin + indexL[startLeft + j], last - indexR[startRight + j]);
          }
        }
        numLeft -= num;
        numRight -= num;
        startLeft += num;
        startRight += num;
        begin += (numLeft == 0) ? BLOCKSIZE : 0;
        last -= (numRight == 0) ? BLOCKSIZE : 0;
      }
    }
    int shiftR = 0;
    int shiftL = 0;
    if (numRight == 0 && numLeft == 0) {
      shiftL = ((last - begin) + 1) / 2;
      shiftR = (last - begin) + 1 - shiftL;
      startLeft = 0;
      startRight = 0;
      //@ loop_invariant 0 <= j <= shiftL;
      //@ loop_invariant 0 <= numLeft && numLeft <= j;
      //@ loop_invariant 0 <= numRight && numRight <= j;
      //@ loop_invariant numLeft == (\num_of int k; 0 <= k < j; pivot <= array[begin + k]);
      //@ loop_invariant numRight == (\num_of int k; 0 <= k < j; array[last - k] <= pivot);
      //@ loop_invariant (\forall int k; 0 <= k < numLeft; 0 <= indexL[k] && indexL[k] < j && pivot <= array[begin + indexL[k]]);
      //@ loop_invariant (\forall int k; 0 <= k < BLOCKSIZE; 0 <= indexL[k] && indexL[k] < BLOCKSIZE);
      //@ loop_invariant (\forall int k; 0 <= k < numRight; 0 <= indexR[k] && indexR[k] < j && array[last - indexR[k]] <= pivot);
      //@ loop_invariant (\forall int k; 0 <= k < BLOCKSIZE; 0 <= indexR[k] && indexR[k] < BLOCKSIZE);
      //@ loop_invariant (\forall int k; 0 <= k < numLeft - 1; indexL[k] < indexL[k + 1]);
      //@ loop_invariant (\forall int k; 0 <= k < numRight - 1; indexR[k] < indexR[k + 1]);
      //@ loop_decreases shiftL - j;
      //@ loop_modifies indexL[0 .. shiftL - 1], numLeft, indexR[0 .. shiftL - 1], numRight, j;
      for (int j = 0; j < shiftL; j++) {
        indexL[numLeft] = j;
        numLeft += array[begin + j] >= pivot ? 1 : 0;
        indexR[numRight] = j;
        numRight += pivot >= array[last - j] ? 1 : 0;
      }
      if (shiftL < shiftR) {
        indexR[numRight] = shiftR - 1;
        numRight += pivot >= array[last - shiftR + 1] ? 1 : 0;
      }
    } else if (numRight != 0) {
      shiftL = (last - begin) - BLOCKSIZE + 1;
      shiftR = BLOCKSIZE;
      startLeft = 0;
      //@ loop_invariant 0 <= j <= shiftL;
      //@ loop_invariant numLeft == (\num_of int k; 0 <= k < j; pivot <= array[begin + k]);
      //@ loop_invariant (\forall int k; 0 <= k < numLeft; 0 <= indexL[k] && indexL[k] < j && pivot <= array[begin + indexL[k]]);
      //@ loop_invariant (\forall int k; 0 <= k < BLOCKSIZE; 0 <= indexL[k] && indexL[k] < BLOCKSIZE);
      //@ loop_invariant (\forall int k; 0 <= k < numLeft - 1; indexL[k] < indexL[k + 1]);
      //@ loop_modifies numLeft, indexL[0 .. shiftL - 1], j;
      //@ loop_decreases shiftL - j;
      for (int j = 0; j < shiftL; j++) {
        indexL[numLeft] = j;
        numLeft += array[begin + j] >= pivot ? 1 : 0;
      }
    } else {
      shiftL = BLOCKSIZE;
      shiftR = (last - begin) - BLOCKSIZE + 1;
      startRight = 0;
      //@ loop_invariant 0 <= j <= shiftR;
      //@ loop_invariant numRight == (\num_of int k; 0 <= k < j; array[last - k] <= pivot);
      //@ loop_invariant (\forall int k; 0 <= k < numRight; 0 <= indexR[k] && indexR[k] < j && array[last - indexR[k]] <= pivot);
      //@ loop_invariant (\forall int k; 0 <= k < BLOCKSIZE; 0 <= indexR[k] && indexR[k] < BLOCKSIZE);
      //@ loop_invariant (\forall int k; 0 <= k < numRight - 1; indexR[k] < indexR[k + 1]);
      //@ loop_modifies numRight, indexR[0 .. shiftR - 1], j;
      //@ loop_decreases shiftR - j;
      for (int j = 0; j < shiftR; j++) {
        indexR[numRight] = j;
        numRight += pivot >= array[last - j] ? 1 : 0;
      }
    }
    num = min(numLeft, numRight);
    if (num > 0) {
      //@ loop_invariant 0 <= j <= num;
      //@ loop_invariant (\forall int i; originalBegin <= i < begin + indexL[startLeft]; array[i] <= pivot);
      //@ loop_invariant j > 0 ==> (\forall int i; originalBegin <= i <= begin + indexL[startLeft + j - 1]; array[i] <= pivot);
      //@ loop_invariant (\forall int i; last - indexR[startRight] < i < originalEnd; pivot <= array[i]);
      //@ loop_invariant j > 0 ==> (\forall int i; last - indexR[startRight + j - 1] <= i < originalEnd; pivot <= array[i]);
      //@ loop_invariant (\forall int i; startLeft + j <= i < startLeft + numLeft; pivot <= array[begin + indexL[i]]);
      //@ loop_invariant (\forall int i; startRight + j <= i < startRight + numRight; array[last - indexR[i]] <= pivot);
      //@ loop_invariant permutation(array, \old(array), begin, last + 1);
      //@ loop_modifies array[begin + indexL[startLeft] .. begin + indexL[startLeft + num - 1]], array[last - indexR[startRight + num - 1] .. last - indexR[startRight]], j;
      //@ loop_decreases num - j;
      for (int j = 0; j < num; j++) {
        swap(array, begin + indexL[startLeft + j], last - indexR[startRight + j]);
      }
    }
    numLeft -= num;
    numRight -= num;
    startLeft += num;
    startRight += num;
    begin += (numLeft == 0) ? shiftL : 0;
    last -= (numRight == 0) ? shiftR : 0;
    if (numLeft != 0) {
      int lowerI = startLeft + numLeft - 1;
      int upper = last - begin;
      //@ loop_invariant 0 <= startLeft && startLeft - 1 <= lowerI && lowerI < startLeft + numLeft && startLeft + numLeft <= BLOCKSIZE;
      //@ loop_invariant upper == last - begin - (startLeft + numLeft - 1 - lowerI);
      //@ loop_invariant (\forall int i; lowerI < i < startLeft + numLeft - 1; indexL[i] == upper + (i - lowerI));
      //@ loop_invariant (\forall int i; begin <= i < begin + indexL[startLeft]; array[i] <= pivot);
      //@ loop_invariant (\forall int i; begin + upper < i <= last; pivot <= array[i]);
      //@ loop_modifies lowerI, upper;
      //@ loop_decreases lowerI + 1;
      while (lowerI >= startLeft && indexL[lowerI] == upper) {
        upper--;
        lowerI--;
      }
      //@ loop_invariant 0 <= startLeft && startLeft - 1 <= lowerI && lowerI < startLeft + numLeft && startLeft + numLeft <= BLOCKSIZE;
      //@ loop_invariant upper == last - begin - (startLeft + numLeft - 1 - lowerI);
      //@ loop_invariant (\forall int i; startLeft <= i < lowerI; indexL[i] == indexL[i + 1] - 1);
      //@ loop_invariant (\forall int i; begin + indexL[startLeft] <= i < begin + upper; pivot <= array[i]);
      //@ loop_invariant (\forall int i; begin + upper < i <= last; pivot <= array[i]);
      //@ loop_invariant lowerI >= startLeft ==> indexL[lowerI] == upper || array[begin + upper] <= pivot;
      //@ loop_invariant lowerI < startLeft && upper >= 0 ==> array[begin + upper] <= pivot;
      //@ loop_invariant permutation(array, \old(array), begin, last + 1);
      //@ loop_modifies upper, lowerI, array[begin + indexL[startLeft] .. last];
      //@ loop_decreases lowerI + 1;
      while (lowerI >= startLeft) {
        swap(array, begin + upper, begin + indexL[lowerI]);
        upper--;
        lowerI--;
      }
      swap(array, pivotPosition, begin + upper + 1);
      return begin + upper + 1;
    } else if (numRight != 0) {
      int lowerI = startRight + numRight - 1;
      int upper = last - begin;
      //@ loop_invariant 0 <= startRight && startRight - 1 <= lowerI && lowerI < startRight + numRight && startRight + numRight <= BLOCKSIZE;
      //@ loop_invariant upper == last - begin - (startRight + numRight - 1 - lowerI);
      //@ loop_invariant (\forall int i; lowerI < i < startRight + numRight - 1; indexR[i] == upper + (i - lowerI));
      //@ loop_invariant (\forall int i; last - indexR[startRight] < i <= last; pivot <= array[i]);
      //@ loop_invariant (\forall int i; begin <= i < last - upper; array[i] <= pivot);
      //@ loop_modifies lowerI, upper;
      //@ loop_decreases lowerI + 1;
      while (lowerI >= startRight && indexR[lowerI] == upper) {
        upper--;
        lowerI--;
      }
      //@ loop_invariant 0 <= startRight && startRight - 1 <= lowerI && lowerI < startRight + numRight && startRight + numRight <= BLOCKSIZE;
      //@ loop_invariant upper == last - begin - (startRight + numRight - 1 - lowerI);
      //@ loop_invariant (\forall int i; startRight <= i < lowerI; indexR[i] == indexR[i + 1] - 1);
      //@ loop_invariant (\forall int i; begin <= i < last - upper; array[i] <= pivot);
      //@ loop_invariant (\forall int i; last - upper < i <= last - indexR[startRight]; array[i] <= pivot);
      //@ loop_invariant lowerI >= startRight ==> indexR[lowerI] == upper || pivot <= array[last - upper];
      //@ loop_invariant lowerI < startRight && upper >= 0 ==> pivot <= array[last - upper];
      //@ loop_invariant permutation(array, \old(array), begin, last + 1);
      //@ loop_modifies upper, lowerI, array[begin .. last - indexR[startRight]];
      //@ loop_decreases lowerI + 1;
      while (lowerI >= startRight) {
        swap(array, last - upper, last - indexR[lowerI]);
        upper--;
        lowerI--;
      }
      swap(array, pivotPosition, last - upper);
      return last - upper;
    } else {
      swap(array, pivotPosition, begin);
      return begin;
    }
  }
  
  public static void quickSortVerf( 
  int[] array, int originalBegin, int originalEnd) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= originalBegin && originalBegin < originalEnd && originalEnd <= array.length);
    }
    int old26 = array.length;
    int[] old27 = array;
    try {
      int begin = originalBegin;
      int end = originalEnd;
      int depthLimit = 2 * log2(end - begin) + 3;
       
      int[] stack = new int[STACK_SIZE];
       
      int[] depthStack = new int[DEPTH_STACK_SIZE];
      int stackPointer = 0;
      int depthPointer = 0;
      int depth = 0;
      assert !false : "Illegal assignment to stack[stackPointer] = begin conflicting with assignables array[originalBegin .. originalEnd - 1]";
      stack[stackPointer] = begin;
      assert !false : "Illegal assignment to stack[stackPointer + 1] = end conflicting with assignables array[originalBegin .. originalEnd - 1]";
      stack[stackPointer + 1] = end;
      stackPointer += 2;
      assert !false : "Illegal assignment to depthStack[depthPointer] = depth conflicting with assignables array[originalBegin .. originalEnd - 1]";
      depthStack[depthPointer] = depth;
      depthPointer++;
      while (stackPointer > 0) {
        if (depth < depthLimit && (end - begin > IS_THRESH)) {
          int pivot = partition(array, begin, end);
          if (pivot - begin > end - pivot - 1) {
            assert !false : "Illegal assignment to stack[stackPointer] = begin conflicting with assignables array[originalBegin .. originalEnd - 1]";
            stack[stackPointer] = begin;
            assert !false : "Illegal assignment to stack[stackPointer + 1] = pivot conflicting with assignables array[originalBegin .. originalEnd - 1]";
            stack[stackPointer + 1] = pivot;
            assert !false : "Illegal assignment to begin = pivot + 1 conflicting with assignables array[originalBegin .. originalEnd - 1]";
            begin = pivot + 1;
          } else {
            assert !false : "Illegal assignment to stack[stackPointer] = pivot + 1 conflicting with assignables array[originalBegin .. originalEnd - 1]";
            stack[stackPointer] = pivot + 1;
            assert !false : "Illegal assignment to stack[stackPointer + 1] = end conflicting with assignables array[originalBegin .. originalEnd - 1]";
            stack[stackPointer + 1] = end;
            assert !false : "Illegal assignment to end = pivot conflicting with assignables array[originalBegin .. originalEnd - 1]";
            end = pivot;
          }
          stackPointer += 2;
          depth++;
          assert !false : "Illegal assignment to depthStack[depthPointer] = depth conflicting with assignables array[originalBegin .. originalEnd - 1]";
          depthStack[depthPointer] = depth;
          depthPointer++;
        } else {
          insertionSort(array, begin, end);
          stackPointer -= 2;
          assert !false : "Illegal assignment to begin = stack[stackPointer] conflicting with assignables array[originalBegin .. originalEnd - 1]";
          begin = stack[stackPointer];
          assert !false : "Illegal assignment to end = stack[stackPointer + 1] conflicting with assignables array[originalBegin .. originalEnd - 1]";
          end = stack[stackPointer + 1];
          depthPointer--;
          assert !false : "Illegal assignment to depth = depthStack[depthPointer] conflicting with assignables array[originalBegin .. originalEnd - 1]";
          depth = depthStack[depthPointer];
        }
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old26;
    }
    {
      int quantVar14i = CProver.nondetInt();
      assert !(originalBegin <= quantVar14i && quantVar14i < originalEnd - 1) || array[quantVar14i] <= array[quantVar14i + 1];
    }
    {
      assert permutation(array, old27, originalBegin, originalEnd);
    }
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= originalBegin && originalBegin < originalEnd && originalEnd <= array.length; 
      ensures array.length == \old(array.length); 
      ensures (\forall int i; originalBegin <= i < originalEnd - 1; array[i] <= array[i + 1]); 
      ensures permutation(array, \old(array), originalBegin, originalEnd); 
      assignable array[originalBegin .. originalEnd - 1]; 
   */

  public static void quickSort( 
  int[] array, int originalBegin, int originalEnd) {
    int begin = originalBegin;
    int end = originalEnd;
    int depthLimit = 2 * log2(end - begin) + 3;
     
    int[] stack = new int[STACK_SIZE];
     
    int[] depthStack = new int[DEPTH_STACK_SIZE];
    int stackPointer = 0;
    int depthPointer = 0;
    int depth = 0;
    stack[stackPointer] = begin;
    stack[stackPointer + 1] = end;
    stackPointer += 2;
    depthStack[depthPointer] = depth;
    depthPointer++;
    //@ loop_invariant 0 <= stackPointer && stackPointer < STACK_SIZE;
    //@ loop_invariant 0 <= depth && depth <= depthLimit;
    //@ loop_invariant originalBegin <= begin && begin <= end && end <= originalEnd;
    //@ loop_invariant (\forall int i; originalBegin <= i < min(begin, (\min int j; 0 <= j < stackPointer; stack[j])); array[i] <= array[i + 1]);
    //@ loop_invariant (\forall int i; max(end, (\max int j; 0 <= j < stackPointer; stack[j])) <= i < originalEnd; array[i] <= array[i + 1]);
    //@ loop_invariant (\forall int i; originalBegin <= i < originalEnd; (\num_of int k; originalBegin <= k < originalEnd; array[i] == array[k]) == (\num_of int k; originalBegin <= k < originalEnd; array[i] == \old(array[k])));
    //@ loop_modifies stackPointer, depth, stack[0 .. STACK_SIZE - 1], array[originalBegin .. originalEnd - 1];
    //@ loop_decreases (\sum int i; originalBegin <= i < originalEnd; (\num_of int j; i <= j < originalEnd; array[j] < array[i]));
    while (stackPointer > 0) {
      if (depth < depthLimit && (end - begin > IS_THRESH)) {
        int pivot = partition(array, begin, end);
        if (pivot - begin > end - pivot - 1) {
          stack[stackPointer] = begin;
          stack[stackPointer + 1] = pivot;
          begin = pivot + 1;
        } else {
          stack[stackPointer] = pivot + 1;
          stack[stackPointer + 1] = end;
          end = pivot;
        }
        stackPointer += 2;
        depth++;
        depthStack[depthPointer] = depth;
        depthPointer++;
      } else {
        insertionSort(array, begin, end);
        stackPointer -= 2;
        begin = stack[stackPointer];
        end = stack[stackPointer + 1];
        depthPointer--;
        depth = depthStack[depthPointer];
      }
    }
  }
  
  public static void quickSortRecVerf( 
  int[] array, int begin, int end) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= begin && begin < end && end <= array.length);
    }
    int old28 = array.length;
    int[] old29 = array;
    try {
      int depth = 0;
      int depthLimit = 2 * log2(end - begin) + 3;
      quickSortRecImpl(array, begin, end, depth, depthLimit);
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old28;
    }
    {
      int quantVar15i = CProver.nondetInt();
      assert !(begin <= quantVar15i && quantVar15i < end - 1) || array[quantVar15i] <= array[quantVar15i + 1];
    }
    {
      assert permutation(array, old29, begin, end);
    }
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= begin && begin < end && end <= array.length; 
      ensures array.length == \old(array.length); 
      ensures (\forall int i; begin <= i < end - 1; array[i] <= array[i + 1]); 
      ensures permutation(array, \old(array), begin, end); 
      assignable array[begin .. end - 1]; 
   */

  public static void quickSortRec( 
  int[] array, int begin, int end) {
    int depth = 0;
    int depthLimit = 2 * log2(end - begin) + 3;
    quickSortRecImpl(array, begin, end, depth, depthLimit);
  }
  
  public static void quickSortRecImplVerf( 
  int[] array, int begin, int end, int depth, int depthLimit) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= begin && begin <= end && end <= array.length);
    }
    {
      CProver.assume(0 <= depth && depth <= depthLimit && depthLimit < Integer.MAX_VALUE);
    }
    int old30 = array.length;
    int[] old31 = array;
    try {
      if (end - begin <= IS_THRESH || depth >= depthLimit) {
        insertionSort(array, begin, end);
        {
          throw new BlockQuickSort.ReturnException();
        }
      }
      int pivot = partition(array, begin, end);
      quickSortRecImpl(array, begin, pivot, depth + 1, depthLimit);
      quickSortRecImpl(array, pivot, end, depth + 1, depthLimit);
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old30;
    }
    {
      int quantVar16i = CProver.nondetInt();
      assert !(begin <= quantVar16i && quantVar16i < end - 1) || array[quantVar16i] <= array[quantVar16i + 1];
    }
    {
      assert permutation(array, old31, begin, end);
    }
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= begin && begin <= end && end <= array.length; 
      requires 0 <= depth && depth <= depthLimit && depthLimit < Integer.MAX_VALUE; 
      ensures array.length == \old(array.length); 
      ensures (\forall int i; begin <= i < end - 1; array[i] <= array[i + 1]); 
      ensures permutation(array, \old(array), begin, end); 
      assignable array[begin .. end - 1]; 
   */

  public static void quickSortRecImpl( 
  int[] array, int begin, int end, int depth, int depthLimit) {
    if (end - begin <= IS_THRESH || depth >= depthLimit) {
      insertionSort(array, begin, end);
      return;
    }
    int pivot = partition(array, begin, end);
    quickSortRecImpl(array, begin, pivot, depth + 1, depthLimit);
    quickSortRecImpl(array, pivot, end, depth + 1, depthLimit);
  }
  
  public static void insertionSortVerf( 
  int[] array, int begin, int end) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= begin && begin <= end && end <= array.length);
    }
    int old32 = array.length;
    int[] old33 = array;
    try {
      for (int i = begin; i < end; ) {
        int j = i;
        while (j > begin && array[j - 1] > array[j]) {
          swap(array, j, j - 1);
          j--;
        }
        i++;
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old32;
    }
    {
      int quantVar17i = CProver.nondetInt();
      assert !(begin <= quantVar17i && quantVar17i < end - 1) || array[quantVar17i] <= array[quantVar17i + 1];
    }
    {
      assert permutation(array, old33, begin, end);
    }
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= begin && begin <= end && end <= array.length; 
      ensures array.length == \old(array.length); 
      ensures (\forall int i; begin <= i < end - 1; array[i] <= array[i + 1]); 
      ensures permutation(array, \old(array), begin, end); 
      assignable array[begin .. end - 1]; 
   */

  public static void insertionSort( 
  int[] array, int begin, int end) {
    for (int i = begin; i < end; i++) {
      int j = i;
      while (j > begin && array[j - 1] > array[j]) {
        swap(array, j, j - 1);
        j--;
      }
    }
  }
  
  public static void swapVerf( 
  int[] array, int i, int j) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= i && i < array.length);
    }
    {
      CProver.assume(0 <= j && j < array.length);
    }
    int old34 = array.length;
    int old35 = array[j];
    int old36 = array[i];
    int[] old37 = array;
    int old38 = i;
    int old39 = j;
    try {
      int temp = array[i];
      assert !(true && (old37 != array || i > old38 || i < old38) && (array != array || i > old39 || i < old39)) : "Illegal assignment to array[i] = array[j] conflicting with assignables array[i], array[j]";
      array[i] = array[j];
      assert !(true && (old37 != array || j > old38 || j < old38) && (array != array || j > old39 || j < old39)) : "Illegal assignment to array[j] = temp conflicting with assignables array[i], array[j]";
      array[j] = temp;
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old34;
    }
    {
      {
        assert array[i] == old35;
        assert array[j] == old36;
      }
    }
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= i < array.length; 
      requires 0 <= j < array.length; 
      ensures array.length == \old(array.length); 
      ensures array[i] == \old(array[j]) && array[j] == \old(array[i]); 
      assignable array[i], array[j]; 
   */

  public static void swap( 
  int[] array, int i, int j) {
    int temp = array[i];
    array[i] = array[j];
    array[j] = temp;
  }
  
  public static void sortPairVerf(int i1, int i2,  
  int[] array) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= i1 && i1 < array.length);
    }
    {
      CProver.assume(0 <= i2 && i2 < array.length);
    }
    int old40 = array.length;
    int old41 = array[i1];
    int old42 = array[i2];
    int old43 = array[i1];
    int old44 = array[i2];
    int old45 = array[i2];
    int old46 = array[i1];
    try {
      if (array[i1] > array[i2]) {
        swap(array, i1, i2);
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old40;
    }
    {
      assert (old41 <= old42) ? (array[i1] == old43 && array[i2] == old44) : (array[i1] == old45 && array[i2] == old46);
    }
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= i1 && i1 < array.length; 
      requires 0 <= i2 && i2 < array.length; 
      ensures array.length == \old(array.length); 
      ensures (\old(array[i1]) <= \old(array[i2])) ? (array[i1] == \old(array[i1]) && array[i2] == \old(array[i2])) : (array[i1] == \old(array[i2]) && array[i2] == \old(array[i1])); 
      assignable array[i1], array[i2]; 
   */

  public static void sortPair(int i1, int i2,  
  int[] array) {
    if (array[i1] > array[i2]) {
      swap(array, i1, i2);
    }
  }
  
  public static int medianOf3Verf( 
  int[] array, int begin, int end) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= begin && begin < end && end <= array.length);
    }
    {
      CProver.assume(end - begin >= 3);
    }
    int old47 = array.length;
    int[] old48 = array;
    int returnVar = 0;
    try {
      int mid = begin + ((end - begin) / 2);
      sortPair(begin, mid, array);
      sortPair(mid, end - 1, array);
      sortPair(begin, mid, array);
      {
        returnVar = mid;
        throw new BlockQuickSort.ReturnException();
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old47;
    }
    {
      assert returnVar == begin + ((end - begin) / 2);
    }
    {
      {
        assert array[begin] <= array[returnVar];
        assert array[returnVar] <= array[end - 1];
      }
    }
    {
      assert permutation(array, old48, begin, end);
    }
    return returnVar;
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= begin && begin < end && end <= array.length; 
      requires end - begin >= 3; 
      ensures array.length == \old(array.length); 
      ensures \result == begin + ((end - begin) / 2); 
      ensures array[begin] <= array[\result] && array[\result] <= array[end - 1]; 
      ensures permutation(array, \old(array), begin, end); 
      assignable array[begin], array[begin + ((end - begin) / 2)], array[end - 1]; 
   */

  public static int medianOf3( 
  int[] array, int begin, int end) {
    int mid = begin + ((end - begin) / 2);
    sortPair(begin, mid, array);
    sortPair(mid, end - 1, array);
    sortPair(begin, mid, array);
    return mid;
  }
  
  public static int partitionVerf( 
  int[] array, int begin, int end) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= begin && begin < end && end <= array.length);
    }
    {
      CProver.assume(end - begin >= 3);
    }
    int old49 = array.length;
    int[] old50 = array;
    int returnVar = 0;
    try {
      int mid = medianOf3(array, begin, end);
      {
        returnVar = hoareBlockPartition(array, begin + 1, end - 1, mid);
        throw new BlockQuickSort.ReturnException();
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old49;
    }
    {
      {
        assert begin <= returnVar;
        assert returnVar < end;
      }
    }
    {
      int quantVar18i = CProver.nondetInt();
      assert !(begin <= quantVar18i && quantVar18i <= returnVar) || array[quantVar18i] <= array[returnVar];
    }
    {
      int quantVar19i = CProver.nondetInt();
      assert !(returnVar <= quantVar19i && quantVar19i < end) || array[returnVar] <= array[quantVar19i];
    }
    {
      assert permutation(array, old50, begin, end);
    }
    return returnVar;
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= begin && begin < end && end <= array.length; 
      requires end - begin >= 3; 
      ensures array.length == \old(array.length); 
      ensures begin <= \result && \result < end; 
      ensures (\forall int i; begin <= i <= \result; array[i] <= array[\result]); 
      ensures (\forall int i; \result <= i < end; array[\result] <= array[i]); 
      ensures permutation(array, \old(array), begin, end); 
      assignable array[begin .. end - 1]; 
   */

  public static int partition( 
  int[] array, int begin, int end) {
    int mid = medianOf3(array, begin, end);
    return hoareBlockPartition(array, begin + 1, end - 1, mid);
  }
  
   
  public static int log2Verf(int n) {
    {
      CProver.assume(n > 0);
    }
    int returnVar = 0;
    try {
      int log2Value = 0;
      while (n > 1) {
        n /= 2;
        log2Value++;
      }
      {
        returnVar = log2Value;
        throw new BlockQuickSort.ReturnException();
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      {
        assert 0 <= returnVar;
        assert (1 << (returnVar - 1)) < n;
        assert n <= (1 << returnVar);
        assert returnVar <= 31;
      }
    }
    return returnVar;
  }
    /*@
    public normal_behavior
      requires n > 0; 
      ensures 0 <= \result && (1 << (\result - 1)) < n && n <= (1 << \result) && \result <= 31; 
   */

   
  public static int log2(int n) {
    int log2Value = 0;
    while (n > 1) {
      n /= 2;
      log2Value++;
    }
    return log2Value;
  }
  
  public static int minVerf(int a, int b) {
    int returnVar = 0;
    try {
      {
        returnVar = a < b ? a : b;
        throw new BlockQuickSort.ReturnException();
      }
    } catch (BlockQuickSort.ReturnException ex) {
    } catch (java.lang.RuntimeException e) {
      CProver.assume(false);
    }
    return returnVar;
  }
    /*@
    public behavior
      signals_only java.lang.RuntimeException; 
   */

  public static int min(int a, int b) {
    return a < b ? a : b;
  }
  
  public static int maxVerf(int a, int b) {
    int returnVar = 0;
    try {
      {
        returnVar = a > b ? a : b;
        throw new BlockQuickSort.ReturnException();
      }
    } catch (BlockQuickSort.ReturnException ex) {
    } catch (java.lang.RuntimeException e) {
      CProver.assume(false);
    }
    return returnVar;
  }
    /*@
    public behavior
      signals_only java.lang.RuntimeException; 
   */

  public static int max(int a, int b) {
    return a > b ? a : b;
  }
  
   
  public static boolean permutationVerf( 
  int[] array1,  
  int[] array2, int begin, int end) {
    {
      CProver.assume(array1 != null);
    }
    {
      CProver.assume(array2 != null);
    }
    {
      CProver.assume(0 <= begin && begin <= end && end <= array1.length);
    }
    {
      CProver.assume(array1.length == array2.length);
    }
    int old51 = array1.length;
    int old52 = array2.length;
    boolean returnVar = true;
    try {
      for (int i = begin; i < end; ) {
        int count1 = 0;
        int count2 = 0;
        for (int j = begin; j < end; ) {
          if (array1[i] == array1[j]) {
            count1++;
          }
          if (array1[i] == array2[j]) {
            count2++;
          }
          j++;
        }
        if (count1 != count2) {
          {
            returnVar = false;
            throw new BlockQuickSort.ReturnException();
          }
        }
        i++;
      }
      {
        returnVar = true;
        throw new BlockQuickSort.ReturnException();
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array1.length == old51;
    }
    {
      assert array2.length == old52;
    }
    {
      int quantVar20i = CProver.nondetInt();
      int sum_4 = 0;
      int sum_5 = 0;
      boolean b_7 = false;
      int sum_6 = 0;
      int sum_7 = 0;
      if (!!returnVar) {
        if (!!(begin <= quantVar20i && quantVar20i < end)) {
          sum_4 = 0;
          for (int quantVar21j = begin; begin <= quantVar21j && end - 1 >= quantVar21j; ++quantVar21j) {
            sum_4 += array1[quantVar20i] == array1[quantVar21j] ? 1 : 0;
          }
          sum_5 = 0;
          for (int quantVar22j = begin; begin <= quantVar22j && end - 1 >= quantVar22j; ++quantVar22j) {
            sum_5 += array1[quantVar20i] == array2[quantVar22j] ? 1 : 0;
          }
        }
      }
      if (!returnVar || (!(begin <= quantVar20i && quantVar20i < end) || ((sum_4) == (sum_5)))) {
        b_7 = false;
        for (int quantVar23i = begin; begin <= quantVar23i && end - 1 >= quantVar23i; ++quantVar23i) {
          sum_6 = 0;
          for (int quantVar24j = begin; begin <= quantVar24j && end - 1 >= quantVar24j; ++quantVar24j) {
            sum_6 += array1[quantVar23i] == array1[quantVar24j] ? 1 : 0;
          }
          sum_7 = 0;
          for (int quantVar25j = begin; begin <= quantVar25j && end - 1 >= quantVar25j; ++quantVar25j) {
            sum_7 += array1[quantVar23i] == array2[quantVar25j] ? 1 : 0;
          }
          b_7 = b_7 || !((sum_6) == (sum_7));
        }
      }
      {
        assert !returnVar || (!(begin <= quantVar20i && quantVar20i < end) || ((sum_4) == (sum_5)));
        assert b_7 || returnVar;
      }
    }
    return returnVar;
  }
    /*@
    public normal_behavior
      requires array1 != null; 
      requires array2 != null; 
      requires 0 <= begin && begin <= end && end <= array1.length; 
      requires array1.length == array2.length; 
      ensures array1.length == \old(array1.length); 
      ensures array2.length == \old(array2.length); 
      ensures \result == (\forall int i; begin <= i < end; ((\num_of int j; begin <= j < end; array1[i] == array1[j]) == (\num_of int j; begin <= j < end; array1[i] == array2[j]))); 
   */

   
  public static boolean permutation( 
  int[] array1,  
  int[] array2, int begin, int end) {
    //@ loop_invariant begin <= i <= end;
    //@ loop_invariant (\forall int j; begin <= j < i; (\num_of int k; begin <= k < end; array1[j] == array1[k]) == (\num_of int k; begin <= k < end; array1[j] == array2[k]));
    //@ loop_modifies i;
    //@ loop_decreases end - i;
    for (int i = begin; i < end; i++) {
      int count1 = 0;
      int count2 = 0;
      //@ loop_invariant begin <= j <= end;
      //@ loop_invariant count1 == (\num_of int k; begin <= k < j; array1[i] == array1[k]);
      //@ loop_invariant count2 == (\num_of int k; begin <= k < j; array1[i] == array2[k]);
      //@ loop_modifies j, count1, count2;
      //@ loop_decreases end - j;
      for (int j = begin; j < end; j++) {
        if (array1[i] == array1[j]) {
          count1++;
        }
        if (array1[i] == array2[j]) {
          count2++;
        }
      }
      if (count1 != count2) {
        return false;
      }
    }
    return true;
  }
  
  public static class ReturnException extends java.lang.RuntimeException {
  }
}