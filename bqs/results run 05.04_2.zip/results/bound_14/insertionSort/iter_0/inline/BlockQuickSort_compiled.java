
import org.cprover.CProver;

public class BlockQuickSort {
    /*@
    public behavior
      assignable \nothing; 
      signals () false; 
   */

  public static BlockQuickSort BlockQuickSortSymb() {
    return new BlockQuickSort();
  }
  
  public static int hoareBlockPartitionSymb( 
  int[] array, int originalBegin, int originalEnd, int pivotPosition) {
    assert array != null;
    assert 0 <= originalBegin;
    assert originalBegin < originalEnd;
    assert originalEnd <= array.length;
    assert (originalEnd - originalBegin) >= 1;
    assert originalBegin <= pivotPosition;
    assert pivotPosition < originalEnd;
    int returnVar = CProver.nondetInt();
    int old0 = array.length;
    int old1 = array[pivotPosition];
    int[] old2 = array;
    if (array != null) {
      for (int __tmpVar__0 = originalBegin; __tmpVar__0 <= originalEnd - 1; ++__tmpVar__0) {
        array[__tmpVar__0] = CProver.nondetInt();
      }
    }
    CProver.assume(array.length == old0);
    CProver.assume(originalBegin <= returnVar && returnVar < originalEnd);
    CProver.assume(array[returnVar] == old1);
    boolean b_0 = true;
    b_0 = false;
    for (int quantVar0i = originalBegin; originalBegin <= quantVar0i && returnVar >= quantVar0i; ++quantVar0i) {
      b_0 = b_0 && array[quantVar0i] <= array[returnVar];
    }
    CProver.assume((b_0));
    boolean b_1 = true;
    b_1 = false;
    for (int quantVar1i = returnVar; returnVar <= quantVar1i && originalEnd - 1 >= quantVar1i; ++quantVar1i) {
      b_1 = b_1 && array[returnVar] <= array[quantVar1i];
    }
    CProver.assume((b_1));
    int[] $$param0 = null;
    int[] $$param1 = null;
    int $$param2 = 0;
    int $$param3 = 0;
    $$param0 = array;
    $$param1 = old2;
    $$param2 = originalBegin;
    $$param3 = originalEnd;
    CProver.assume(permutationSymb($$param0, $$param1, $$param2, $$param3));
    return returnVar;
  }
  
  public static void quickSortRecImplSymb( 
  int[] array, int begin, int end, int depth, int depthLimit) {
    assert array != null;
    assert 0 <= begin;
    assert begin <= end;
    assert end <= array.length;
    assert 0 <= depth;
    assert depth <= depthLimit;
    assert depthLimit < Integer.MAX_VALUE;
    int old3 = array.length;
    int[] old4 = array;
    if (array != null) {
      for (int __tmpVar__0 = begin; __tmpVar__0 <= end - 1; ++__tmpVar__0) {
        array[__tmpVar__0] = CProver.nondetInt();
      }
    }
    CProver.assume(array.length == old3);
    boolean b_2 = true;
    b_2 = false;
    for (int quantVar2i = begin; begin <= quantVar2i && end - 1 - 1 >= quantVar2i; ++quantVar2i) {
      b_2 = b_2 && array[quantVar2i] <= array[quantVar2i + 1];
    }
    CProver.assume((b_2));
    int[] $$param4 = null;
    int[] $$param5 = null;
    int $$param6 = 0;
    int $$param7 = 0;
    $$param4 = array;
    $$param5 = old4;
    $$param6 = begin;
    $$param7 = end;
    CProver.assume(permutationSymb($$param4, $$param5, $$param6, $$param7));
  }
  
  public static void insertionSortSymb( 
  int[] array, int begin, int end) {
    assert array != null;
    assert 0 <= begin;
    assert begin <= end;
    assert end <= array.length;
    int old5 = array.length;
    int[] old6 = array;
    if (array != null) {
      for (int __tmpVar__0 = begin; __tmpVar__0 <= end - 1; ++__tmpVar__0) {
        array[__tmpVar__0] = CProver.nondetInt();
      }
    }
    CProver.assume(array.length == old5);
    boolean b_3 = true;
    b_3 = false;
    for (int quantVar3i = begin; begin <= quantVar3i && end - 1 - 1 >= quantVar3i; ++quantVar3i) {
      b_3 = b_3 && array[quantVar3i] <= array[quantVar3i + 1];
    }
    CProver.assume((b_3));
    int[] $$param8 = null;
    int[] $$param9 = null;
    int $$param10 = 0;
    int $$param11 = 0;
    $$param8 = array;
    $$param9 = old6;
    $$param10 = begin;
    $$param11 = end;
    CProver.assume(permutationSymb($$param8, $$param9, $$param10, $$param11));
  }
  
  public static void swapSymb( 
  int[] array, int i, int j) {
    assert array != null;
    assert 0 <= i;
    assert i < array.length;
    assert 0 <= j;
    assert j < array.length;
    int old7 = array.length;
    int old8 = array[j];
    int old9 = array[i];
    array[i] = CProver.nondetInt();
    array[j] = CProver.nondetInt();
    CProver.assume(array.length == old7);
    CProver.assume(array[i] == old8 && array[j] == old9);
  }
  
  public static void sortPairSymb(int i1, int i2,  
  int[] array) {
    assert array != null;
    assert 0 <= i1;
    assert i1 < array.length;
    assert 0 <= i2;
    assert i2 < array.length;
    int old10 = array.length;
    int old11 = array[i1];
    int old12 = array[i2];
    int old13 = array[i1];
    int old14 = array[i2];
    int old15 = array[i2];
    int old16 = array[i1];
    array[i1] = CProver.nondetInt();
    array[i2] = CProver.nondetInt();
    CProver.assume(array.length == old10);
    CProver.assume((old11 <= old12) ? (array[i1] == old13 && array[i2] == old14) : (array[i1] == old15 && array[i2] == old16));
  }
  
  public static int medianOf3Symb( 
  int[] array, int begin, int end) {
    assert array != null;
    assert 0 <= begin;
    assert begin < end;
    assert end <= array.length;
    assert end - begin >= 3;
    int returnVar = CProver.nondetInt();
    int old17 = array.length;
    int[] old18 = array;
    array[begin] = CProver.nondetInt();
    array[begin + ((end - begin) / 2)] = CProver.nondetInt();
    array[end - 1] = CProver.nondetInt();
    CProver.assume(array.length == old17);
    CProver.assume(returnVar == begin + ((end - begin) / 2));
    CProver.assume(array[begin] <= array[returnVar] && array[returnVar] <= array[end - 1]);
    int[] $$param12 = null;
    int[] $$param13 = null;
    int $$param14 = 0;
    int $$param15 = 0;
    $$param12 = array;
    $$param13 = old18;
    $$param14 = begin;
    $$param15 = end;
    CProver.assume(permutationSymb($$param12, $$param13, $$param14, $$param15));
    return returnVar;
  }
  
  public static int partitionSymb( 
  int[] array, int begin, int end) {
    assert array != null;
    assert 0 <= begin;
    assert begin < end;
    assert end <= array.length;
    assert end - begin >= 3;
    int returnVar = CProver.nondetInt();
    int old19 = array.length;
    int[] old20 = array;
    if (array != null) {
      for (int __tmpVar__0 = begin; __tmpVar__0 <= end - 1; ++__tmpVar__0) {
        array[__tmpVar__0] = CProver.nondetInt();
      }
    }
    CProver.assume(array.length == old19);
    CProver.assume(begin <= returnVar && returnVar < end);
    boolean b_4 = true;
    b_4 = false;
    for (int quantVar4i = begin; begin <= quantVar4i && returnVar >= quantVar4i; ++quantVar4i) {
      b_4 = b_4 && array[quantVar4i] <= array[returnVar];
    }
    CProver.assume((b_4));
    boolean b_5 = true;
    b_5 = false;
    for (int quantVar5i = returnVar; returnVar <= quantVar5i && end - 1 >= quantVar5i; ++quantVar5i) {
      b_5 = b_5 && array[returnVar] <= array[quantVar5i];
    }
    CProver.assume((b_5));
    int[] $$param16 = null;
    int[] $$param17 = null;
    int $$param18 = 0;
    int $$param19 = 0;
    $$param16 = array;
    $$param17 = old20;
    $$param18 = begin;
    $$param19 = end;
    CProver.assume(permutationSymb($$param16, $$param17, $$param18, $$param19));
    return returnVar;
  }
  
  public static int log2Symb(int n) {
    assert n > 0;
    int returnVar = CProver.nondetInt();
    CProver.assume(0 <= returnVar && (1 << (returnVar - 1)) < n && n <= (1 << returnVar) && returnVar <= 31);
    return returnVar;
  }
  
  public static boolean permutationSymb( 
  int[] array1,  
  int[] array2, int begin, int end) {
    assert array1 != null;
    assert array2 != null;
    assert 0 <= begin;
    assert begin <= end;
    assert end <= array1.length;
    assert array1.length == array2.length;
    boolean returnVar = CProver.nondetBoolean();
    int old21 = array1.length;
    int old22 = array2.length;
    CProver.assume(array1.length == old21);
    CProver.assume(array2.length == old22);
    boolean b_6 = true;
    int sum_0 = 0;
    int sum_1 = 0;
    int quantVar9i = CProver.nondetInt();
    int sum_2 = 0;
    int sum_3 = 0;
    if (!!returnVar) {
      b_6 = false;
      for (int quantVar6i = begin; begin <= quantVar6i && end - 1 >= quantVar6i; ++quantVar6i) {
        sum_0 = 0;
        for (int quantVar7j = begin; begin <= quantVar7j && end - 1 >= quantVar7j; ++quantVar7j) {
          sum_0 += array1[quantVar6i] == array1[quantVar7j] ? 1 : 0;
        }
        sum_1 = 0;
        for (int quantVar8j = begin; begin <= quantVar8j && end - 1 >= quantVar8j; ++quantVar8j) {
          sum_1 += array1[quantVar6i] == array2[quantVar8j] ? 1 : 0;
        }
        b_6 = b_6 && ((sum_0) == (sum_1));
      }
    }
    if (!returnVar || (b_6)) {
      if (begin <= quantVar9i && quantVar9i < end) {
        sum_2 = 0;
        for (int quantVar10j = begin; begin <= quantVar10j && end - 1 >= quantVar10j; ++quantVar10j) {
          sum_2 += array1[quantVar9i] == array1[quantVar10j] ? 1 : 0;
        }
        sum_3 = 0;
        for (int quantVar11j = begin; begin <= quantVar11j && end - 1 >= quantVar11j; ++quantVar11j) {
          sum_3 += array1[quantVar9i] == array2[quantVar11j] ? 1 : 0;
        }
      }
    }
    CProver.assume((!returnVar || (b_6)) && (begin <= quantVar9i && quantVar9i < end && !((sum_2) == (sum_3)) || returnVar));
    return returnVar;
  }
  
  public BlockQuickSort() {
    {
    }
  }
  private static final int BLOCKSIZE = 2;
  private static final int IS_THRESH = 3;
  private static final int STACK_SIZE = 10;
  private static final int DEPTH_STACK_SIZE = 10;
  
  public static int hoareBlockPartitionVerf( 
  int[] array, int originalBegin, int originalEnd, int pivotPosition) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= originalBegin && originalBegin < originalEnd && originalEnd <= array.length);
    }
    {
      CProver.assume((originalEnd - originalBegin) >= 1);
    }
    {
      CProver.assume(originalBegin <= pivotPosition && pivotPosition < originalEnd);
    }
    int old23 = array.length;
    int old24 = array[pivotPosition];
    int[] old25 = array;
    int[] old26 = array;
    int old27 = originalEnd - 1;
    int old28 = originalBegin;
    int returnVar = 0;
    try {
      int[] $$param24 = null;
      int $$param25 = 0;
      int $$param26 = 0;
      int[] $$param43 = null;
      int $$param44 = 0;
      int $$param45 = 0;
      int[] $$param62 = null;
      int $$param63 = 0;
      int $$param64 = 0;
      int[] $$param77 = null;
      int $$param78 = 0;
      int $$param79 = 0;
      int[] $$param84 = null;
      int $$param85 = 0;
      int $$param86 = 0;
      int[] $$param95 = null;
      int $$param96 = 0;
      int $$param97 = 0;
      int[] $$param102 = null;
      int $$param103 = 0;
      int $$param104 = 0;
      int[] $$param105 = null;
      int $$param106 = 0;
      int $$param107 = 0;
       
      int[] indexL = new int[BLOCKSIZE];
       
      int[] indexR = new int[BLOCKSIZE];
      int begin = originalBegin;
      int end = originalEnd;
      int last = end - 1;
      int pivot = array[pivotPosition];
      $$param24 = array;
      $$param25 = pivotPosition;
      $$param26 = last;
      assert !(true && (old26 != $$param24 || $$param25 > old27 || $$param25 < old28)) : "Illegal assignment to array[i] conflicting with assignables array[originalBegin .. originalEnd - 1]";
      assert !(true && (old26 != $$param24 || $$param26 > old27 || $$param26 < old28)) : "Illegal assignment to array[j] conflicting with assignables array[originalBegin .. originalEnd - 1]";
      swapSymb($$param24, $$param25, $$param26);
      assert !false : "Illegal assignment to pivotPosition = last conflicting with assignables array[originalBegin .. originalEnd - 1]";
      pivotPosition = last;
      last--;
      int numLeft = 0;
      int numRight = 0;
      int startLeft = 0;
      int startRight = 0;
      int num = 0;
      if (last - begin + 1 > 2 * BLOCKSIZE) {
        int old29 = array[pivotPosition];
        int[] old30 = array;
        int[] old31 = array;
        int old32 = originalEnd - 1;
        int old33 = originalBegin;
        int old34 = array[pivotPosition];
        int[] old35 = array;
        int old53 = array[pivotPosition];
        int[] old54 = array;
        {
          boolean b_7 = false;
          boolean b_8 = false;
          int quantVar16i = CProver.nondetInt();
          int quantVar17i = CProver.nondetInt();
          int quantVar18i = CProver.nondetInt();
          int sum_4 = 0;
          int quantVar20i = CProver.nondetInt();
          int quantVar21i = CProver.nondetInt();
          int quantVar22i = CProver.nondetInt();
          int sum_5 = 0;
          int quantVar24i = CProver.nondetInt();
          int quantVar25i = CProver.nondetInt();
          int quantVar26i = CProver.nondetInt();
          int quantVar27i = CProver.nondetInt();
          int[] $$param27 = null;
          int[] $$param28 = null;
          int $$param29 = 0;
          int $$param30 = 0;
          {
            assert originalBegin <= begin;
            assert begin <= last;
            assert last < originalEnd - 1;
          }
          {
            assert 0 <= numLeft;
            assert numLeft <= BLOCKSIZE;
          }
          {
            assert 0 <= numRight;
            assert numRight <= BLOCKSIZE;
          }
          {
            assert 0 <= startLeft;
            assert startLeft <= BLOCKSIZE;
            assert startLeft + numLeft <= BLOCKSIZE;
          }
          {
            assert 0 <= startRight;
            assert startRight <= BLOCKSIZE;
            assert startRight + numRight <= BLOCKSIZE;
          }
          {
            assert 0 <= num;
            assert num <= BLOCKSIZE;
          }
          assert numRight == 0 || numLeft == 0;
          assert array[originalEnd - 1] == old29;
          b_7 = false;
          for (int quantVar14i = 0; 0 <= quantVar14i && (originalEnd - originalBegin) - 1 >= quantVar14i; ++quantVar14i) {
            b_7 = b_7 || begin == originalBegin + quantVar14i * BLOCKSIZE;
          }
          assert b_7;
          b_8 = false;
          for (int quantVar15i = 0; 0 <= quantVar15i && (originalEnd - originalBegin) - 1 >= quantVar15i; ++quantVar15i) {
            b_8 = b_8 || last == originalEnd - 2 - quantVar15i * BLOCKSIZE;
          }
          assert b_8;
          assert !(0 <= quantVar16i && quantVar16i < BLOCKSIZE) || 0 <= indexL[quantVar16i] && indexL[quantVar16i] < BLOCKSIZE;
          assert !(0 <= quantVar17i && quantVar17i < numLeft) || indexL[startLeft + quantVar17i] < last - begin && pivot <= array[begin + indexL[startLeft + quantVar17i]];
          assert !(0 <= quantVar18i && quantVar18i < startLeft + numLeft - 1) || indexL[quantVar18i] < indexL[quantVar18i + 1];
          if (!!(numLeft != 0)) {
            sum_4 = 0;
            for (int quantVar19i = startLeft; startLeft <= quantVar19i && BLOCKSIZE - 1 >= quantVar19i; ++quantVar19i) {
              sum_4 += pivot <= array[begin + quantVar19i] ? 1 : 0;
            }
          }
          assert !(numLeft != 0) || numLeft == (sum_4);
          assert !(0 <= quantVar20i && quantVar20i < BLOCKSIZE) || 0 <= indexR[quantVar20i] && indexR[quantVar20i] < BLOCKSIZE;
          assert !(0 <= quantVar21i && quantVar21i < numRight) || indexR[startRight + quantVar21i] < last - begin && array[last - indexR[startRight + quantVar21i]] <= pivot;
          assert !(0 <= quantVar22i && quantVar22i < startRight + numRight - 1) || indexR[quantVar22i] < indexR[quantVar22i + 1];
          if (!!(numRight != 0)) {
            sum_5 = 0;
            for (int quantVar23i = startRight; startRight <= quantVar23i && BLOCKSIZE - 1 >= quantVar23i; ++quantVar23i) {
              sum_5 += array[last - quantVar23i] <= pivot ? 1 : 0;
            }
          }
          assert !(numRight != 0) || numRight == (sum_5);
          assert !(numLeft == 0) || (!(originalBegin <= quantVar24i && quantVar24i < begin) || array[quantVar24i] <= pivot);
          assert !(numLeft != 0) || (!(originalBegin <= quantVar25i && quantVar25i < begin + indexL[startLeft]) || array[quantVar25i] <= pivot);
          assert !(numRight == 0) || (!(last < quantVar26i && quantVar26i < originalEnd) || pivot <= array[quantVar26i]);
          assert !(numRight != 0) || (!(last - indexR[startRight] < quantVar27i && quantVar27i < originalEnd) || pivot <= array[quantVar27i]);
          $$param27 = array;
          $$param28 = old30;
          $$param29 = originalBegin;
          $$param30 = originalEnd;
          assert permutationSymb($$param27, $$param28, $$param29, $$param30);
        }
        assert !(true && (old31 != array || min(begin + BLOCKSIZE - 1, originalEnd - 2) > old32 || max(begin, originalBegin) < old33)) : "Illegal assignment to array[max(begin, originalBegin) .. min(begin + BLOCKSIZE - 1, originalEnd - 2)] conflicting with assiganbles + array[originalBegin .. originalEnd - 1]";
        assert !(true && (old31 != array || min(last, originalEnd - 2) > old32 || max(last - BLOCKSIZE - 1, originalBegin) < old33)) : "Illegal assignment to array[max(last - BLOCKSIZE - 1, originalBegin) .. min(last, originalEnd - 2)] conflicting with assiganbles + array[originalBegin .. originalEnd - 1]";
        num = CProver.nondetInt();
        startRight = CProver.nondetInt();
        startLeft = CProver.nondetInt();
        numRight = CProver.nondetInt();
        numLeft = CProver.nondetInt();
        begin = CProver.nondetInt();
        last = CProver.nondetInt();
        if (indexR != null) {
          for (int __tmpVar__0 = 0; __tmpVar__0 <= BLOCKSIZE - 1; ++__tmpVar__0) {
            indexR[__tmpVar__0] = CProver.nondetInt();
          }
        }
        if (indexL != null) {
          for (int __tmpVar__0 = 0; __tmpVar__0 <= BLOCKSIZE - 1; ++__tmpVar__0) {
            indexL[__tmpVar__0] = CProver.nondetInt();
          }
        }
        if (array != null) {
          for (int __tmpVar__0 = max(last - BLOCKSIZE - 1, originalBegin); __tmpVar__0 <= min(last, originalEnd - 2); ++__tmpVar__0) {
            array[__tmpVar__0] = CProver.nondetInt();
          }
        }
        if (array != null) {
          for (int __tmpVar__0 = max(begin, originalBegin); __tmpVar__0 <= min(begin + BLOCKSIZE - 1, originalEnd - 2); ++__tmpVar__0) {
            array[__tmpVar__0] = CProver.nondetInt();
          }
        }
        int oldDecreasesClauseValue0 = last - begin;
        {
          int quantVar28i = CProver.nondetInt();
          int quantVar29i = CProver.nondetInt();
          boolean b_9 = true;
          boolean b_10 = true;
          boolean b_11 = true;
          int sum_6 = 0;
          boolean b_12 = true;
          boolean b_13 = true;
          boolean b_14 = true;
          int sum_7 = 0;
          boolean b_15 = true;
          boolean b_16 = true;
          boolean b_17 = true;
          boolean b_18 = true;
          int[] $$param31 = null;
          int[] $$param32 = null;
          int $$param33 = 0;
          int $$param34 = 0;
          CProver.assume(originalBegin <= begin && begin <= last && last < originalEnd - 1);
          CProver.assume(0 <= numLeft && numLeft <= BLOCKSIZE);
          CProver.assume(0 <= numRight && numRight <= BLOCKSIZE);
          CProver.assume(0 <= startLeft && startLeft <= BLOCKSIZE && startLeft + numLeft <= BLOCKSIZE);
          CProver.assume(0 <= startRight && startRight <= BLOCKSIZE && startRight + numRight <= BLOCKSIZE);
          CProver.assume(0 <= num && num <= BLOCKSIZE);
          CProver.assume(numRight == 0 || numLeft == 0);
          CProver.assume(array[originalEnd - 1] == old34);
          CProver.assume((0 <= quantVar28i && quantVar28i < (originalEnd - originalBegin) && begin == originalBegin + quantVar28i * BLOCKSIZE));
          CProver.assume((0 <= quantVar29i && quantVar29i < (originalEnd - originalBegin) && last == originalEnd - 2 - quantVar29i * BLOCKSIZE));
          b_9 = false;
          for (int quantVar30i = 0; 0 <= quantVar30i && BLOCKSIZE - 1 >= quantVar30i; ++quantVar30i) {
            b_9 = b_9 && (0 <= indexL[quantVar30i] && indexL[quantVar30i] < BLOCKSIZE);
          }
          CProver.assume((b_9));
          b_10 = false;
          for (int quantVar31i = 0; 0 <= quantVar31i && numLeft - 1 >= quantVar31i; ++quantVar31i) {
            b_10 = b_10 && (indexL[startLeft + quantVar31i] < last - begin && pivot <= array[begin + indexL[startLeft + quantVar31i]]);
          }
          CProver.assume((b_10));
          b_11 = false;
          for (int quantVar32i = 0; 0 <= quantVar32i && startLeft + numLeft - 1 - 1 >= quantVar32i; ++quantVar32i) {
            b_11 = b_11 && indexL[quantVar32i] < indexL[quantVar32i + 1];
          }
          CProver.assume((b_11));
          if (!!(numLeft != 0)) {
            sum_6 = 0;
            for (int quantVar33i = startLeft; startLeft <= quantVar33i && BLOCKSIZE - 1 >= quantVar33i; ++quantVar33i) {
              sum_6 += pivot <= array[begin + quantVar33i] ? 1 : 0;
            }
          }
          CProver.assume(!(numLeft != 0) || numLeft == (sum_6));
          b_12 = false;
          for (int quantVar34i = 0; 0 <= quantVar34i && BLOCKSIZE - 1 >= quantVar34i; ++quantVar34i) {
            b_12 = b_12 && (0 <= indexR[quantVar34i] && indexR[quantVar34i] < BLOCKSIZE);
          }
          CProver.assume((b_12));
          b_13 = false;
          for (int quantVar35i = 0; 0 <= quantVar35i && numRight - 1 >= quantVar35i; ++quantVar35i) {
            b_13 = b_13 && (indexR[startRight + quantVar35i] < last - begin && array[last - indexR[startRight + quantVar35i]] <= pivot);
          }
          CProver.assume((b_13));
          b_14 = false;
          for (int quantVar36i = 0; 0 <= quantVar36i && startRight + numRight - 1 - 1 >= quantVar36i; ++quantVar36i) {
            b_14 = b_14 && indexR[quantVar36i] < indexR[quantVar36i + 1];
          }
          CProver.assume((b_14));
          if (!!(numRight != 0)) {
            sum_7 = 0;
            for (int quantVar37i = startRight; startRight <= quantVar37i && BLOCKSIZE - 1 >= quantVar37i; ++quantVar37i) {
              sum_7 += array[last - quantVar37i] <= pivot ? 1 : 0;
            }
          }
          CProver.assume(!(numRight != 0) || numRight == (sum_7));
          if (!!(numLeft == 0)) {
            b_15 = false;
            for (int quantVar38i = originalBegin; originalBegin <= quantVar38i && begin - 1 >= quantVar38i; ++quantVar38i) {
              b_15 = b_15 && array[quantVar38i] <= pivot;
            }
          }
          CProver.assume(!(numLeft == 0) || (b_15));
          if (!!(numLeft != 0)) {
            b_16 = false;
            for (int quantVar39i = originalBegin; originalBegin <= quantVar39i && begin + indexL[startLeft] - 1 >= quantVar39i; ++quantVar39i) {
              b_16 = b_16 && array[quantVar39i] <= pivot;
            }
          }
          CProver.assume(!(numLeft != 0) || (b_16));
          if (!!(numRight == 0)) {
            b_17 = false;
            for (int quantVar40i = last + 1; last + 1 <= quantVar40i && originalEnd - 1 >= quantVar40i; ++quantVar40i) {
              b_17 = b_17 && pivot <= array[quantVar40i];
            }
          }
          CProver.assume(!(numRight == 0) || (b_17));
          if (!!(numRight != 0)) {
            b_18 = false;
            for (int quantVar41i = last - indexR[startRight] + 1; last - indexR[startRight] + 1 <= quantVar41i && originalEnd - 1 >= quantVar41i; ++quantVar41i) {
              b_18 = b_18 && pivot <= array[quantVar41i];
            }
          }
          CProver.assume(!(numRight != 0) || (b_18));
          $$param31 = array;
          $$param32 = old35;
          $$param33 = originalBegin;
          $$param34 = originalEnd;
          CProver.assume(permutationSymb($$param31, $$param32, $$param33, $$param34));
        }
        if (last - begin + 1 > 2 * BLOCKSIZE) {
          if (numLeft == 0) {
            assert !false : "Illegal assignment to startLeft = 0 conflicting with assignables array[max(begin, originalBegin) .. min(begin + BLOCKSIZE - 1, originalEnd - 2)], array[max(last - BLOCKSIZE - 1, originalBegin) .. min(last, originalEnd - 2)], indexL[0 .. BLOCKSIZE - 1], indexR[0 .. BLOCKSIZE - 1], last, begin, numLeft, numRight, startLeft, startRight, num";
            startLeft = 0;
            {
              int j = 0;
              {
                int sum_8 = 0;
                int quantVar43k = CProver.nondetInt();
                int quantVar44k = CProver.nondetInt();
                int quantVar45k = CProver.nondetInt();
                {
                  assert 0 <= j;
                  assert j <= BLOCKSIZE;
                }
                sum_8 = 0;
                for (int quantVar42k = 0; 0 <= quantVar42k && j - 1 >= quantVar42k; ++quantVar42k) {
                  sum_8 += pivot <= array[begin + quantVar42k] ? 1 : 0;
                }
                assert numLeft == (sum_8);
                assert !(0 <= quantVar43k && quantVar43k < numLeft) || 0 <= indexL[quantVar43k] && indexL[quantVar43k] < j && pivot <= array[begin + indexL[quantVar43k]];
                assert !(0 <= quantVar44k && quantVar44k < BLOCKSIZE) || 0 <= indexL[quantVar44k] && indexL[quantVar44k] < BLOCKSIZE;
                assert !(0 <= quantVar45k && quantVar45k < numLeft - 1) || indexL[quantVar45k] < indexL[quantVar45k + 1];
              }
              j = CProver.nondetInt();
              numLeft = CProver.nondetInt();
              if (indexL != null) {
                for (int __tmpVar__0 = 0; __tmpVar__0 <= BLOCKSIZE - 1; ++__tmpVar__0) {
                  indexL[__tmpVar__0] = CProver.nondetInt();
                }
              }
              int oldDecreasesClauseValue1 = BLOCKSIZE - j;
              {
                int sum_9 = 0;
                boolean b_19 = true;
                boolean b_20 = true;
                boolean b_21 = true;
                CProver.assume(0 <= j && j <= BLOCKSIZE);
                sum_9 = 0;
                for (int quantVar46k = 0; 0 <= quantVar46k && j - 1 >= quantVar46k; ++quantVar46k) {
                  sum_9 += pivot <= array[begin + quantVar46k] ? 1 : 0;
                }
                CProver.assume(numLeft == (sum_9));
                b_19 = false;
                for (int quantVar47k = 0; 0 <= quantVar47k && numLeft - 1 >= quantVar47k; ++quantVar47k) {
                  b_19 = b_19 && (0 <= indexL[quantVar47k] && indexL[quantVar47k] < j && pivot <= array[begin + indexL[quantVar47k]]);
                }
                CProver.assume((b_19));
                b_20 = false;
                for (int quantVar48k = 0; 0 <= quantVar48k && BLOCKSIZE - 1 >= quantVar48k; ++quantVar48k) {
                  b_20 = b_20 && (0 <= indexL[quantVar48k] && indexL[quantVar48k] < BLOCKSIZE);
                }
                CProver.assume((b_20));
                b_21 = false;
                for (int quantVar49k = 0; 0 <= quantVar49k && numLeft - 1 - 1 >= quantVar49k; ++quantVar49k) {
                  b_21 = b_21 && indexL[quantVar49k] < indexL[quantVar49k + 1];
                }
                CProver.assume((b_21));
              }
              if (j < BLOCKSIZE) {
                assert !false : "Illegal assignment to indexL[numLeft] = j conflicting with assignables indexL[0 .. BLOCKSIZE - 1], numLeft, j, j";
                indexL[numLeft] = j;
                numLeft += array[begin + j] >= pivot ? 1 : 0;
                j++;
                {
                  int sum_10 = 0;
                  int quantVar51k = CProver.nondetInt();
                  int quantVar52k = CProver.nondetInt();
                  int quantVar53k = CProver.nondetInt();
                  {
                    assert 0 <= j;
                    assert j <= BLOCKSIZE;
                  }
                  sum_10 = 0;
                  for (int quantVar50k = 0; 0 <= quantVar50k && j - 1 >= quantVar50k; ++quantVar50k) {
                    sum_10 += pivot <= array[begin + quantVar50k] ? 1 : 0;
                  }
                  assert numLeft == (sum_10);
                  assert !(0 <= quantVar51k && quantVar51k < numLeft) || 0 <= indexL[quantVar51k] && indexL[quantVar51k] < j && pivot <= array[begin + indexL[quantVar51k]];
                  assert !(0 <= quantVar52k && quantVar52k < BLOCKSIZE) || 0 <= indexL[quantVar52k] && indexL[quantVar52k] < BLOCKSIZE;
                  assert !(0 <= quantVar53k && quantVar53k < numLeft - 1) || indexL[quantVar53k] < indexL[quantVar53k + 1];
                }
                {
                  assert BLOCKSIZE - j >= 0;
                  assert BLOCKSIZE - j < oldDecreasesClauseValue1;
                }
                CProver.assume(false);
              }
            }
          }
          if (numRight == 0) {
            assert !false : "Illegal assignment to startRight = 0 conflicting with assignables array[max(begin, originalBegin) .. min(begin + BLOCKSIZE - 1, originalEnd - 2)], array[max(last - BLOCKSIZE - 1, originalBegin) .. min(last, originalEnd - 2)], indexL[0 .. BLOCKSIZE - 1], indexR[0 .. BLOCKSIZE - 1], last, begin, numLeft, numRight, startLeft, startRight, num";
            startRight = 0;
            {
              int j = 0;
              {
                int sum_11 = 0;
                int quantVar55k = CProver.nondetInt();
                int quantVar56k = CProver.nondetInt();
                int quantVar57k = CProver.nondetInt();
                {
                  assert 0 <= j;
                  assert j <= BLOCKSIZE;
                }
                sum_11 = 0;
                for (int quantVar54k = 0; 0 <= quantVar54k && j - 1 >= quantVar54k; ++quantVar54k) {
                  sum_11 += array[last - quantVar54k] <= pivot ? 1 : 0;
                }
                assert numRight == (sum_11);
                assert !(0 <= quantVar55k && quantVar55k < numRight) || 0 <= indexR[quantVar55k] && indexR[quantVar55k] < j && array[last - indexR[quantVar55k]] <= pivot;
                assert !(0 <= quantVar56k && quantVar56k < BLOCKSIZE) || 0 <= indexR[quantVar56k] && indexR[quantVar56k] < BLOCKSIZE;
                assert !(0 <= quantVar57k && quantVar57k < numRight - 1) || indexR[quantVar57k] < indexR[quantVar57k + 1];
              }
              j = CProver.nondetInt();
              numRight = CProver.nondetInt();
              if (indexR != null) {
                for (int __tmpVar__0 = 0; __tmpVar__0 <= BLOCKSIZE - 1; ++__tmpVar__0) {
                  indexR[__tmpVar__0] = CProver.nondetInt();
                }
              }
              int oldDecreasesClauseValue2 = BLOCKSIZE - j;
              {
                int sum_12 = 0;
                boolean b_22 = true;
                boolean b_23 = true;
                boolean b_24 = true;
                CProver.assume(0 <= j && j <= BLOCKSIZE);
                sum_12 = 0;
                for (int quantVar58k = 0; 0 <= quantVar58k && j - 1 >= quantVar58k; ++quantVar58k) {
                  sum_12 += array[last - quantVar58k] <= pivot ? 1 : 0;
                }
                CProver.assume(numRight == (sum_12));
                b_22 = false;
                for (int quantVar59k = 0; 0 <= quantVar59k && numRight - 1 >= quantVar59k; ++quantVar59k) {
                  b_22 = b_22 && (0 <= indexR[quantVar59k] && indexR[quantVar59k] < j && array[last - indexR[quantVar59k]] <= pivot);
                }
                CProver.assume((b_22));
                b_23 = false;
                for (int quantVar60k = 0; 0 <= quantVar60k && BLOCKSIZE - 1 >= quantVar60k; ++quantVar60k) {
                  b_23 = b_23 && (0 <= indexR[quantVar60k] && indexR[quantVar60k] < BLOCKSIZE);
                }
                CProver.assume((b_23));
                b_24 = false;
                for (int quantVar61k = 0; 0 <= quantVar61k && numRight - 1 - 1 >= quantVar61k; ++quantVar61k) {
                  b_24 = b_24 && indexR[quantVar61k] < indexR[quantVar61k + 1];
                }
                CProver.assume((b_24));
              }
              if (j < BLOCKSIZE) {
                assert !false : "Illegal assignment to indexR[numRight] = j conflicting with assignables indexR[0 .. BLOCKSIZE - 1], numRight, j, j";
                indexR[numRight] = j;
                numRight += pivot >= array[last - j] ? 1 : 0;
                j++;
                {
                  int sum_13 = 0;
                  int quantVar63k = CProver.nondetInt();
                  int quantVar64k = CProver.nondetInt();
                  int quantVar65k = CProver.nondetInt();
                  {
                    assert 0 <= j;
                    assert j <= BLOCKSIZE;
                  }
                  sum_13 = 0;
                  for (int quantVar62k = 0; 0 <= quantVar62k && j - 1 >= quantVar62k; ++quantVar62k) {
                    sum_13 += array[last - quantVar62k] <= pivot ? 1 : 0;
                  }
                  assert numRight == (sum_13);
                  assert !(0 <= quantVar63k && quantVar63k < numRight) || 0 <= indexR[quantVar63k] && indexR[quantVar63k] < j && array[last - indexR[quantVar63k]] <= pivot;
                  assert !(0 <= quantVar64k && quantVar64k < BLOCKSIZE) || 0 <= indexR[quantVar64k] && indexR[quantVar64k] < BLOCKSIZE;
                  assert !(0 <= quantVar65k && quantVar65k < numRight - 1) || indexR[quantVar65k] < indexR[quantVar65k + 1];
                }
                {
                  assert BLOCKSIZE - j >= 0;
                  assert BLOCKSIZE - j < oldDecreasesClauseValue2;
                }
                CProver.assume(false);
              }
            }
          }
          assert !false : "Illegal assignment to num = min(numLeft, numRight) conflicting with assignables array[max(begin, originalBegin) .. min(begin + BLOCKSIZE - 1, originalEnd - 2)], array[max(last - BLOCKSIZE - 1, originalBegin) .. min(last, originalEnd - 2)], indexL[0 .. BLOCKSIZE - 1], indexR[0 .. BLOCKSIZE - 1], last, begin, numLeft, numRight, startLeft, startRight, num";
          num = min(numLeft, numRight);
          if (num > 0) {
            {
              int j = 0;
              int[] old36 = array;
              int[] old37 = array;
              int old38 = min(begin + BLOCKSIZE - 1, originalEnd - 2);
              int old39 = max(begin, originalBegin);
              int old40 = min(last, originalEnd - 2);
              int old41 = max(last - BLOCKSIZE - 1, originalBegin);
              int old42 = BLOCKSIZE - 1;
              int old43 = 0;
              int old44 = BLOCKSIZE - 1;
              int old45 = 0;
              int[] old46 = array;
              int[] old47 = array;
              int old48 = begin + indexL[startLeft + num - 1];
              int old49 = begin + indexL[startLeft];
              int old50 = last - indexR[startRight];
              int old51 = last - indexR[startRight + num - 1];
              int[] old52 = array;
              {
                int quantVar66i = CProver.nondetInt();
                int quantVar67i = CProver.nondetInt();
                int quantVar68i = CProver.nondetInt();
                int quantVar69i = CProver.nondetInt();
                int quantVar70i = CProver.nondetInt();
                int quantVar71i = CProver.nondetInt();
                int[] $$param35 = null;
                int[] $$param36 = null;
                int $$param37 = 0;
                int $$param38 = 0;
                {
                  assert 0 <= j;
                  assert j <= num;
                }
                assert !(originalBegin <= quantVar66i && quantVar66i < begin + indexL[startLeft]) || array[quantVar66i] <= pivot;
                assert !(j > 0) || (!(originalBegin <= quantVar67i && quantVar67i <= begin + indexL[startLeft + j - 1]) || array[quantVar67i] <= pivot);
                assert !(last - indexR[startRight] < quantVar68i && quantVar68i < originalEnd) || pivot <= array[quantVar68i];
                assert !(j > 0) || (!(last - indexR[startRight + j - 1] <= quantVar69i && quantVar69i < originalEnd) || pivot <= array[quantVar69i]);
                assert !(startLeft + j <= quantVar70i && quantVar70i < startLeft + numLeft) || pivot <= array[begin + indexL[quantVar70i]];
                assert !(startRight + j <= quantVar71i && quantVar71i < startRight + numRight) || array[last - indexR[quantVar71i]] <= pivot;
                $$param35 = array;
                $$param36 = old36;
                $$param37 = begin;
                $$param38 = last + 1;
                assert permutationSymb($$param35, $$param36, $$param37, $$param38);
              }
              assert !(true && (old37 != array || begin + indexL[startLeft + num - 1] > old38 || begin + indexL[startLeft] < old39) && (array != array || begin + indexL[startLeft + num - 1] > old40 || begin + indexL[startLeft] < old41) && (indexL != array || begin + indexL[startLeft + num - 1] > old42 || begin + indexL[startLeft] < old43) && (indexR != array || begin + indexL[startLeft + num - 1] > old44 || begin + indexL[startLeft] < old45)) : "Illegal assignment to array[begin + indexL[startLeft] .. begin + indexL[startLeft + num - 1]] conflicting with assiganbles + array[max(begin, originalBegin) .. min(begin + BLOCKSIZE - 1, originalEnd - 2)], array[max(last - BLOCKSIZE - 1, originalBegin) .. min(last, originalEnd - 2)], indexL[0 .. BLOCKSIZE - 1], indexR[0 .. BLOCKSIZE - 1], last, begin, numLeft, numRight, startLeft, startRight, num";
              assert !(true && (old37 != array || last - indexR[startRight] > old38 || last - indexR[startRight + num - 1] < old39) && (array != array || last - indexR[startRight] > old40 || last - indexR[startRight + num - 1] < old41) && (indexL != array || last - indexR[startRight] > old42 || last - indexR[startRight + num - 1] < old43) && (indexR != array || last - indexR[startRight] > old44 || last - indexR[startRight + num - 1] < old45)) : "Illegal assignment to array[last - indexR[startRight + num - 1] .. last - indexR[startRight]] conflicting with assiganbles + array[max(begin, originalBegin) .. min(begin + BLOCKSIZE - 1, originalEnd - 2)], array[max(last - BLOCKSIZE - 1, originalBegin) .. min(last, originalEnd - 2)], indexL[0 .. BLOCKSIZE - 1], indexR[0 .. BLOCKSIZE - 1], last, begin, numLeft, numRight, startLeft, startRight, num";
              j = CProver.nondetInt();
              if (array != null) {
                for (int __tmpVar__0 = last - indexR[startRight + num - 1]; __tmpVar__0 <= last - indexR[startRight]; ++__tmpVar__0) {
                  array[__tmpVar__0] = CProver.nondetInt();
                }
              }
              if (array != null) {
                for (int __tmpVar__0 = begin + indexL[startLeft]; __tmpVar__0 <= begin + indexL[startLeft + num - 1]; ++__tmpVar__0) {
                  array[__tmpVar__0] = CProver.nondetInt();
                }
              }
              int oldDecreasesClauseValue3 = num - j;
              {
                boolean b_25 = true;
                boolean b_26 = true;
                boolean b_27 = true;
                boolean b_28 = true;
                boolean b_29 = true;
                boolean b_30 = true;
                int[] $$param39 = null;
                int[] $$param40 = null;
                int $$param41 = 0;
                int $$param42 = 0;
                CProver.assume(0 <= j && j <= num);
                b_25 = false;
                for (int quantVar72i = originalBegin; originalBegin <= quantVar72i && begin + indexL[startLeft] - 1 >= quantVar72i; ++quantVar72i) {
                  b_25 = b_25 && array[quantVar72i] <= pivot;
                }
                CProver.assume((b_25));
                if (!!(j > 0)) {
                  b_26 = false;
                  for (int quantVar73i = originalBegin; originalBegin <= quantVar73i && begin + indexL[startLeft + j - 1] >= quantVar73i; ++quantVar73i) {
                    b_26 = b_26 && array[quantVar73i] <= pivot;
                  }
                }
                CProver.assume(!(j > 0) || (b_26));
                b_27 = false;
                for (int quantVar74i = last - indexR[startRight] + 1; last - indexR[startRight] + 1 <= quantVar74i && originalEnd - 1 >= quantVar74i; ++quantVar74i) {
                  b_27 = b_27 && pivot <= array[quantVar74i];
                }
                CProver.assume((b_27));
                if (!!(j > 0)) {
                  b_28 = false;
                  for (int quantVar75i = last - indexR[startRight + j - 1]; last - indexR[startRight + j - 1] <= quantVar75i && originalEnd - 1 >= quantVar75i; ++quantVar75i) {
                    b_28 = b_28 && pivot <= array[quantVar75i];
                  }
                }
                CProver.assume(!(j > 0) || (b_28));
                b_29 = false;
                for (int quantVar76i = startLeft + j; startLeft + j <= quantVar76i && startLeft + numLeft - 1 >= quantVar76i; ++quantVar76i) {
                  b_29 = b_29 && pivot <= array[begin + indexL[quantVar76i]];
                }
                CProver.assume((b_29));
                b_30 = false;
                for (int quantVar77i = startRight + j; startRight + j <= quantVar77i && startRight + numRight - 1 >= quantVar77i; ++quantVar77i) {
                  b_30 = b_30 && array[last - indexR[quantVar77i]] <= pivot;
                }
                CProver.assume((b_30));
                $$param39 = array;
                $$param40 = old46;
                $$param41 = begin;
                $$param42 = last + 1;
                CProver.assume(permutationSymb($$param39, $$param40, $$param41, $$param42));
              }
              if (j < num) {
                $$param43 = array;
                $$param44 = begin + indexL[startLeft + j];
                $$param45 = last - indexR[startRight + j];
                assert !(true && (old47 != $$param43 || $$param44 > old48 || $$param44 < old49) && ($$param43 != $$param43 || $$param44 > old50 || $$param44 < old51)) : "Illegal assignment to array[i] conflicting with assignables array[begin + indexL[startLeft] .. begin + indexL[startLeft + num - 1]], array[last - indexR[startRight + num - 1] .. last - indexR[startRight]], j, j";
                assert !(true && (old47 != $$param43 || $$param45 > old48 || $$param45 < old49) && ($$param43 != $$param43 || $$param45 > old50 || $$param45 < old51)) : "Illegal assignment to array[j] conflicting with assignables array[begin + indexL[startLeft] .. begin + indexL[startLeft + num - 1]], array[last - indexR[startRight + num - 1] .. last - indexR[startRight]], j, j";
                swapSymb($$param43, $$param44, $$param45);
                j++;
                {
                  int quantVar78i = CProver.nondetInt();
                  int quantVar79i = CProver.nondetInt();
                  int quantVar80i = CProver.nondetInt();
                  int quantVar81i = CProver.nondetInt();
                  int quantVar82i = CProver.nondetInt();
                  int quantVar83i = CProver.nondetInt();
                  int[] $$param46 = null;
                  int[] $$param47 = null;
                  int $$param48 = 0;
                  int $$param49 = 0;
                  {
                    assert 0 <= j;
                    assert j <= num;
                  }
                  assert !(originalBegin <= quantVar78i && quantVar78i < begin + indexL[startLeft]) || array[quantVar78i] <= pivot;
                  assert !(j > 0) || (!(originalBegin <= quantVar79i && quantVar79i <= begin + indexL[startLeft + j - 1]) || array[quantVar79i] <= pivot);
                  assert !(last - indexR[startRight] < quantVar80i && quantVar80i < originalEnd) || pivot <= array[quantVar80i];
                  assert !(j > 0) || (!(last - indexR[startRight + j - 1] <= quantVar81i && quantVar81i < originalEnd) || pivot <= array[quantVar81i]);
                  assert !(startLeft + j <= quantVar82i && quantVar82i < startLeft + numLeft) || pivot <= array[begin + indexL[quantVar82i]];
                  assert !(startRight + j <= quantVar83i && quantVar83i < startRight + numRight) || array[last - indexR[quantVar83i]] <= pivot;
                  $$param46 = array;
                  $$param47 = old52;
                  $$param48 = begin;
                  $$param49 = last + 1;
                  assert permutationSymb($$param46, $$param47, $$param48, $$param49);
                }
                {
                  assert num - j >= 0;
                  assert num - j < oldDecreasesClauseValue3;
                }
                CProver.assume(false);
              }
            }
          }
          numLeft -= num;
          numRight -= num;
          startLeft += num;
          startRight += num;
          begin += (numLeft == 0) ? BLOCKSIZE : 0;
          last -= (numRight == 0) ? BLOCKSIZE : 0;
          {
            boolean b_31 = false;
            boolean b_32 = false;
            int quantVar86i = CProver.nondetInt();
            int quantVar87i = CProver.nondetInt();
            int quantVar88i = CProver.nondetInt();
            int sum_14 = 0;
            int quantVar90i = CProver.nondetInt();
            int quantVar91i = CProver.nondetInt();
            int quantVar92i = CProver.nondetInt();
            int sum_15 = 0;
            int quantVar94i = CProver.nondetInt();
            int quantVar95i = CProver.nondetInt();
            int quantVar96i = CProver.nondetInt();
            int quantVar97i = CProver.nondetInt();
            int[] $$param50 = null;
            int[] $$param51 = null;
            int $$param52 = 0;
            int $$param53 = 0;
            {
              assert originalBegin <= begin;
              assert begin <= last;
              assert last < originalEnd - 1;
            }
            {
              assert 0 <= numLeft;
              assert numLeft <= BLOCKSIZE;
            }
            {
              assert 0 <= numRight;
              assert numRight <= BLOCKSIZE;
            }
            {
              assert 0 <= startLeft;
              assert startLeft <= BLOCKSIZE;
              assert startLeft + numLeft <= BLOCKSIZE;
            }
            {
              assert 0 <= startRight;
              assert startRight <= BLOCKSIZE;
              assert startRight + numRight <= BLOCKSIZE;
            }
            {
              assert 0 <= num;
              assert num <= BLOCKSIZE;
            }
            assert numRight == 0 || numLeft == 0;
            assert array[originalEnd - 1] == old53;
            b_31 = false;
            for (int quantVar84i = 0; 0 <= quantVar84i && (originalEnd - originalBegin) - 1 >= quantVar84i; ++quantVar84i) {
              b_31 = b_31 || begin == originalBegin + quantVar84i * BLOCKSIZE;
            }
            assert b_31;
            b_32 = false;
            for (int quantVar85i = 0; 0 <= quantVar85i && (originalEnd - originalBegin) - 1 >= quantVar85i; ++quantVar85i) {
              b_32 = b_32 || last == originalEnd - 2 - quantVar85i * BLOCKSIZE;
            }
            assert b_32;
            assert !(0 <= quantVar86i && quantVar86i < BLOCKSIZE) || 0 <= indexL[quantVar86i] && indexL[quantVar86i] < BLOCKSIZE;
            assert !(0 <= quantVar87i && quantVar87i < numLeft) || indexL[startLeft + quantVar87i] < last - begin && pivot <= array[begin + indexL[startLeft + quantVar87i]];
            assert !(0 <= quantVar88i && quantVar88i < startLeft + numLeft - 1) || indexL[quantVar88i] < indexL[quantVar88i + 1];
            if (!!(numLeft != 0)) {
              sum_14 = 0;
              for (int quantVar89i = startLeft; startLeft <= quantVar89i && BLOCKSIZE - 1 >= quantVar89i; ++quantVar89i) {
                sum_14 += pivot <= array[begin + quantVar89i] ? 1 : 0;
              }
            }
            assert !(numLeft != 0) || numLeft == (sum_14);
            assert !(0 <= quantVar90i && quantVar90i < BLOCKSIZE) || 0 <= indexR[quantVar90i] && indexR[quantVar90i] < BLOCKSIZE;
            assert !(0 <= quantVar91i && quantVar91i < numRight) || indexR[startRight + quantVar91i] < last - begin && array[last - indexR[startRight + quantVar91i]] <= pivot;
            assert !(0 <= quantVar92i && quantVar92i < startRight + numRight - 1) || indexR[quantVar92i] < indexR[quantVar92i + 1];
            if (!!(numRight != 0)) {
              sum_15 = 0;
              for (int quantVar93i = startRight; startRight <= quantVar93i && BLOCKSIZE - 1 >= quantVar93i; ++quantVar93i) {
                sum_15 += array[last - quantVar93i] <= pivot ? 1 : 0;
              }
            }
            assert !(numRight != 0) || numRight == (sum_15);
            assert !(numLeft == 0) || (!(originalBegin <= quantVar94i && quantVar94i < begin) || array[quantVar94i] <= pivot);
            assert !(numLeft != 0) || (!(originalBegin <= quantVar95i && quantVar95i < begin + indexL[startLeft]) || array[quantVar95i] <= pivot);
            assert !(numRight == 0) || (!(last < quantVar96i && quantVar96i < originalEnd) || pivot <= array[quantVar96i]);
            assert !(numRight != 0) || (!(last - indexR[startRight] < quantVar97i && quantVar97i < originalEnd) || pivot <= array[quantVar97i]);
            $$param50 = array;
            $$param51 = old54;
            $$param52 = originalBegin;
            $$param53 = originalEnd;
            assert permutationSymb($$param50, $$param51, $$param52, $$param53);
          }
          {
            assert last - begin >= 0;
            assert last - begin < oldDecreasesClauseValue0;
          }
          CProver.assume(false);
        }
      }
      int shiftR = 0;
      int shiftL = 0;
      if (numRight == 0 && numLeft == 0) {
        assert !false : "Illegal assignment to shiftL = ((last - begin) + 1) / 2 conflicting with assignables array[originalBegin .. originalEnd - 1]";
        shiftL = ((last - begin) + 1) / 2;
        assert !false : "Illegal assignment to shiftR = (last - begin) + 1 - shiftL conflicting with assignables array[originalBegin .. originalEnd - 1]";
        shiftR = (last - begin) + 1 - shiftL;
        assert !false : "Illegal assignment to startLeft = 0 conflicting with assignables array[originalBegin .. originalEnd - 1]";
        startLeft = 0;
        assert !false : "Illegal assignment to startRight = 0 conflicting with assignables array[originalBegin .. originalEnd - 1]";
        startRight = 0;
        {
          int j = 0;
          {
            int sum_16 = 0;
            int sum_17 = 0;
            int quantVar100k = CProver.nondetInt();
            int quantVar101k = CProver.nondetInt();
            int quantVar102k = CProver.nondetInt();
            int quantVar103k = CProver.nondetInt();
            int quantVar104k = CProver.nondetInt();
            int quantVar105k = CProver.nondetInt();
            {
              assert 0 <= j;
              assert j <= shiftL;
            }
            {
              assert 0 <= numLeft;
              assert numLeft <= j;
            }
            {
              assert 0 <= numRight;
              assert numRight <= j;
            }
            sum_16 = 0;
            for (int quantVar98k = 0; 0 <= quantVar98k && j - 1 >= quantVar98k; ++quantVar98k) {
              sum_16 += pivot <= array[begin + quantVar98k] ? 1 : 0;
            }
            assert numLeft == (sum_16);
            sum_17 = 0;
            for (int quantVar99k = 0; 0 <= quantVar99k && j - 1 >= quantVar99k; ++quantVar99k) {
              sum_17 += array[last - quantVar99k] <= pivot ? 1 : 0;
            }
            assert numRight == (sum_17);
            assert !(0 <= quantVar100k && quantVar100k < numLeft) || 0 <= indexL[quantVar100k] && indexL[quantVar100k] < j && pivot <= array[begin + indexL[quantVar100k]];
            assert !(0 <= quantVar101k && quantVar101k < BLOCKSIZE) || 0 <= indexL[quantVar101k] && indexL[quantVar101k] < BLOCKSIZE;
            assert !(0 <= quantVar102k && quantVar102k < numRight) || 0 <= indexR[quantVar102k] && indexR[quantVar102k] < j && array[last - indexR[quantVar102k]] <= pivot;
            assert !(0 <= quantVar103k && quantVar103k < BLOCKSIZE) || 0 <= indexR[quantVar103k] && indexR[quantVar103k] < BLOCKSIZE;
            assert !(0 <= quantVar104k && quantVar104k < numLeft - 1) || indexL[quantVar104k] < indexL[quantVar104k + 1];
            assert !(0 <= quantVar105k && quantVar105k < numRight - 1) || indexR[quantVar105k] < indexR[quantVar105k + 1];
          }
          j = CProver.nondetInt();
          numRight = CProver.nondetInt();
          numLeft = CProver.nondetInt();
          if (indexR != null) {
            for (int __tmpVar__0 = 0; __tmpVar__0 <= shiftL - 1; ++__tmpVar__0) {
              indexR[__tmpVar__0] = CProver.nondetInt();
            }
          }
          if (indexL != null) {
            for (int __tmpVar__0 = 0; __tmpVar__0 <= shiftL - 1; ++__tmpVar__0) {
              indexL[__tmpVar__0] = CProver.nondetInt();
            }
          }
          int oldDecreasesClauseValue4 = shiftL - j;
          {
            int sum_18 = 0;
            int sum_19 = 0;
            boolean b_33 = true;
            boolean b_34 = true;
            boolean b_35 = true;
            boolean b_36 = true;
            boolean b_37 = true;
            boolean b_38 = true;
            CProver.assume(0 <= j && j <= shiftL);
            CProver.assume(0 <= numLeft && numLeft <= j);
            CProver.assume(0 <= numRight && numRight <= j);
            sum_18 = 0;
            for (int quantVar106k = 0; 0 <= quantVar106k && j - 1 >= quantVar106k; ++quantVar106k) {
              sum_18 += pivot <= array[begin + quantVar106k] ? 1 : 0;
            }
            CProver.assume(numLeft == (sum_18));
            sum_19 = 0;
            for (int quantVar107k = 0; 0 <= quantVar107k && j - 1 >= quantVar107k; ++quantVar107k) {
              sum_19 += array[last - quantVar107k] <= pivot ? 1 : 0;
            }
            CProver.assume(numRight == (sum_19));
            b_33 = false;
            for (int quantVar108k = 0; 0 <= quantVar108k && numLeft - 1 >= quantVar108k; ++quantVar108k) {
              b_33 = b_33 && (0 <= indexL[quantVar108k] && indexL[quantVar108k] < j && pivot <= array[begin + indexL[quantVar108k]]);
            }
            CProver.assume((b_33));
            b_34 = false;
            for (int quantVar109k = 0; 0 <= quantVar109k && BLOCKSIZE - 1 >= quantVar109k; ++quantVar109k) {
              b_34 = b_34 && (0 <= indexL[quantVar109k] && indexL[quantVar109k] < BLOCKSIZE);
            }
            CProver.assume((b_34));
            b_35 = false;
            for (int quantVar110k = 0; 0 <= quantVar110k && numRight - 1 >= quantVar110k; ++quantVar110k) {
              b_35 = b_35 && (0 <= indexR[quantVar110k] && indexR[quantVar110k] < j && array[last - indexR[quantVar110k]] <= pivot);
            }
            CProver.assume((b_35));
            b_36 = false;
            for (int quantVar111k = 0; 0 <= quantVar111k && BLOCKSIZE - 1 >= quantVar111k; ++quantVar111k) {
              b_36 = b_36 && (0 <= indexR[quantVar111k] && indexR[quantVar111k] < BLOCKSIZE);
            }
            CProver.assume((b_36));
            b_37 = false;
            for (int quantVar112k = 0; 0 <= quantVar112k && numLeft - 1 - 1 >= quantVar112k; ++quantVar112k) {
              b_37 = b_37 && indexL[quantVar112k] < indexL[quantVar112k + 1];
            }
            CProver.assume((b_37));
            b_38 = false;
            for (int quantVar113k = 0; 0 <= quantVar113k && numRight - 1 - 1 >= quantVar113k; ++quantVar113k) {
              b_38 = b_38 && indexR[quantVar113k] < indexR[quantVar113k + 1];
            }
            CProver.assume((b_38));
          }
          if (j < shiftL) {
            assert !false : "Illegal assignment to indexL[numLeft] = j conflicting with assignables indexL[0 .. shiftL - 1], indexR[0 .. shiftL - 1], numLeft, numRight, j, j";
            indexL[numLeft] = j;
            numLeft += array[begin + j] >= pivot ? 1 : 0;
            assert !false : "Illegal assignment to indexR[numRight] = j conflicting with assignables indexL[0 .. shiftL - 1], indexR[0 .. shiftL - 1], numLeft, numRight, j, j";
            indexR[numRight] = j;
            numRight += pivot >= array[last - j] ? 1 : 0;
            j++;
            {
              int sum_20 = 0;
              int sum_21 = 0;
              int quantVar116k = CProver.nondetInt();
              int quantVar117k = CProver.nondetInt();
              int quantVar118k = CProver.nondetInt();
              int quantVar119k = CProver.nondetInt();
              int quantVar120k = CProver.nondetInt();
              int quantVar121k = CProver.nondetInt();
              {
                assert 0 <= j;
                assert j <= shiftL;
              }
              {
                assert 0 <= numLeft;
                assert numLeft <= j;
              }
              {
                assert 0 <= numRight;
                assert numRight <= j;
              }
              sum_20 = 0;
              for (int quantVar114k = 0; 0 <= quantVar114k && j - 1 >= quantVar114k; ++quantVar114k) {
                sum_20 += pivot <= array[begin + quantVar114k] ? 1 : 0;
              }
              assert numLeft == (sum_20);
              sum_21 = 0;
              for (int quantVar115k = 0; 0 <= quantVar115k && j - 1 >= quantVar115k; ++quantVar115k) {
                sum_21 += array[last - quantVar115k] <= pivot ? 1 : 0;
              }
              assert numRight == (sum_21);
              assert !(0 <= quantVar116k && quantVar116k < numLeft) || 0 <= indexL[quantVar116k] && indexL[quantVar116k] < j && pivot <= array[begin + indexL[quantVar116k]];
              assert !(0 <= quantVar117k && quantVar117k < BLOCKSIZE) || 0 <= indexL[quantVar117k] && indexL[quantVar117k] < BLOCKSIZE;
              assert !(0 <= quantVar118k && quantVar118k < numRight) || 0 <= indexR[quantVar118k] && indexR[quantVar118k] < j && array[last - indexR[quantVar118k]] <= pivot;
              assert !(0 <= quantVar119k && quantVar119k < BLOCKSIZE) || 0 <= indexR[quantVar119k] && indexR[quantVar119k] < BLOCKSIZE;
              assert !(0 <= quantVar120k && quantVar120k < numLeft - 1) || indexL[quantVar120k] < indexL[quantVar120k + 1];
              assert !(0 <= quantVar121k && quantVar121k < numRight - 1) || indexR[quantVar121k] < indexR[quantVar121k + 1];
            }
            {
              assert shiftL - j >= 0;
              assert shiftL - j < oldDecreasesClauseValue4;
            }
            CProver.assume(false);
          }
        }
        if (shiftL < shiftR) {
          assert !false : "Illegal assignment to indexR[numRight] = shiftR - 1 conflicting with assignables array[originalBegin .. originalEnd - 1]";
          indexR[numRight] = shiftR - 1;
          numRight += pivot >= array[last - shiftR + 1] ? 1 : 0;
        }
      } else if (numRight != 0) {
        assert !false : "Illegal assignment to shiftL = (last - begin) - BLOCKSIZE + 1 conflicting with assignables array[originalBegin .. originalEnd - 1]";
        shiftL = (last - begin) - BLOCKSIZE + 1;
        assert !false : "Illegal assignment to shiftR = BLOCKSIZE conflicting with assignables array[originalBegin .. originalEnd - 1]";
        shiftR = BLOCKSIZE;
        assert !false : "Illegal assignment to startLeft = 0 conflicting with assignables array[originalBegin .. originalEnd - 1]";
        startLeft = 0;
        {
          int j = 0;
          {
            int sum_22 = 0;
            int quantVar123k = CProver.nondetInt();
            int quantVar124k = CProver.nondetInt();
            int quantVar125k = CProver.nondetInt();
            {
              assert 0 <= j;
              assert j <= shiftL;
            }
            sum_22 = 0;
            for (int quantVar122k = 0; 0 <= quantVar122k && j - 1 >= quantVar122k; ++quantVar122k) {
              sum_22 += pivot <= array[begin + quantVar122k] ? 1 : 0;
            }
            assert numLeft == (sum_22);
            assert !(0 <= quantVar123k && quantVar123k < numLeft) || 0 <= indexL[quantVar123k] && indexL[quantVar123k] < j && pivot <= array[begin + indexL[quantVar123k]];
            assert !(0 <= quantVar124k && quantVar124k < BLOCKSIZE) || 0 <= indexL[quantVar124k] && indexL[quantVar124k] < BLOCKSIZE;
            assert !(0 <= quantVar125k && quantVar125k < numLeft - 1) || indexL[quantVar125k] < indexL[quantVar125k + 1];
          }
          j = CProver.nondetInt();
          numLeft = CProver.nondetInt();
          if (indexL != null) {
            for (int __tmpVar__0 = 0; __tmpVar__0 <= shiftL - 1; ++__tmpVar__0) {
              indexL[__tmpVar__0] = CProver.nondetInt();
            }
          }
          int oldDecreasesClauseValue5 = shiftL - j;
          {
            int sum_23 = 0;
            boolean b_39 = true;
            boolean b_40 = true;
            boolean b_41 = true;
            CProver.assume(0 <= j && j <= shiftL);
            sum_23 = 0;
            for (int quantVar126k = 0; 0 <= quantVar126k && j - 1 >= quantVar126k; ++quantVar126k) {
              sum_23 += pivot <= array[begin + quantVar126k] ? 1 : 0;
            }
            CProver.assume(numLeft == (sum_23));
            b_39 = false;
            for (int quantVar127k = 0; 0 <= quantVar127k && numLeft - 1 >= quantVar127k; ++quantVar127k) {
              b_39 = b_39 && (0 <= indexL[quantVar127k] && indexL[quantVar127k] < j && pivot <= array[begin + indexL[quantVar127k]]);
            }
            CProver.assume((b_39));
            b_40 = false;
            for (int quantVar128k = 0; 0 <= quantVar128k && BLOCKSIZE - 1 >= quantVar128k; ++quantVar128k) {
              b_40 = b_40 && (0 <= indexL[quantVar128k] && indexL[quantVar128k] < BLOCKSIZE);
            }
            CProver.assume((b_40));
            b_41 = false;
            for (int quantVar129k = 0; 0 <= quantVar129k && numLeft - 1 - 1 >= quantVar129k; ++quantVar129k) {
              b_41 = b_41 && indexL[quantVar129k] < indexL[quantVar129k + 1];
            }
            CProver.assume((b_41));
          }
          if (j < shiftL) {
            assert !false : "Illegal assignment to indexL[numLeft] = j conflicting with assignables indexL[0 .. shiftL - 1], numLeft, j, j";
            indexL[numLeft] = j;
            numLeft += array[begin + j] >= pivot ? 1 : 0;
            j++;
            {
              int sum_24 = 0;
              int quantVar131k = CProver.nondetInt();
              int quantVar132k = CProver.nondetInt();
              int quantVar133k = CProver.nondetInt();
              {
                assert 0 <= j;
                assert j <= shiftL;
              }
              sum_24 = 0;
              for (int quantVar130k = 0; 0 <= quantVar130k && j - 1 >= quantVar130k; ++quantVar130k) {
                sum_24 += pivot <= array[begin + quantVar130k] ? 1 : 0;
              }
              assert numLeft == (sum_24);
              assert !(0 <= quantVar131k && quantVar131k < numLeft) || 0 <= indexL[quantVar131k] && indexL[quantVar131k] < j && pivot <= array[begin + indexL[quantVar131k]];
              assert !(0 <= quantVar132k && quantVar132k < BLOCKSIZE) || 0 <= indexL[quantVar132k] && indexL[quantVar132k] < BLOCKSIZE;
              assert !(0 <= quantVar133k && quantVar133k < numLeft - 1) || indexL[quantVar133k] < indexL[quantVar133k + 1];
            }
            {
              assert shiftL - j >= 0;
              assert shiftL - j < oldDecreasesClauseValue5;
            }
            CProver.assume(false);
          }
        }
      } else {
        assert !false : "Illegal assignment to shiftL = BLOCKSIZE conflicting with assignables array[originalBegin .. originalEnd - 1]";
        shiftL = BLOCKSIZE;
        assert !false : "Illegal assignment to shiftR = (last - begin) - BLOCKSIZE + 1 conflicting with assignables array[originalBegin .. originalEnd - 1]";
        shiftR = (last - begin) - BLOCKSIZE + 1;
        assert !false : "Illegal assignment to startRight = 0 conflicting with assignables array[originalBegin .. originalEnd - 1]";
        startRight = 0;
        {
          int j = 0;
          {
            int sum_25 = 0;
            int quantVar135k = CProver.nondetInt();
            int quantVar136k = CProver.nondetInt();
            int quantVar137k = CProver.nondetInt();
            {
              assert 0 <= j;
              assert j <= shiftR;
            }
            sum_25 = 0;
            for (int quantVar134k = 0; 0 <= quantVar134k && j - 1 >= quantVar134k; ++quantVar134k) {
              sum_25 += array[last - quantVar134k] <= pivot ? 1 : 0;
            }
            assert numRight == (sum_25);
            assert !(0 <= quantVar135k && quantVar135k < numRight) || 0 <= indexR[quantVar135k] && indexR[quantVar135k] < j && array[last - indexR[quantVar135k]] <= pivot;
            assert !(0 <= quantVar136k && quantVar136k < BLOCKSIZE) || 0 <= indexR[quantVar136k] && indexR[quantVar136k] < BLOCKSIZE;
            assert !(0 <= quantVar137k && quantVar137k < numRight - 1) || indexR[quantVar137k] < indexR[quantVar137k + 1];
          }
          j = CProver.nondetInt();
          numRight = CProver.nondetInt();
          if (indexR != null) {
            for (int __tmpVar__0 = 0; __tmpVar__0 <= shiftR - 1; ++__tmpVar__0) {
              indexR[__tmpVar__0] = CProver.nondetInt();
            }
          }
          int oldDecreasesClauseValue6 = shiftR - j;
          {
            int sum_26 = 0;
            boolean b_42 = true;
            boolean b_43 = true;
            boolean b_44 = true;
            CProver.assume(0 <= j && j <= shiftR);
            sum_26 = 0;
            for (int quantVar138k = 0; 0 <= quantVar138k && j - 1 >= quantVar138k; ++quantVar138k) {
              sum_26 += array[last - quantVar138k] <= pivot ? 1 : 0;
            }
            CProver.assume(numRight == (sum_26));
            b_42 = false;
            for (int quantVar139k = 0; 0 <= quantVar139k && numRight - 1 >= quantVar139k; ++quantVar139k) {
              b_42 = b_42 && (0 <= indexR[quantVar139k] && indexR[quantVar139k] < j && array[last - indexR[quantVar139k]] <= pivot);
            }
            CProver.assume((b_42));
            b_43 = false;
            for (int quantVar140k = 0; 0 <= quantVar140k && BLOCKSIZE - 1 >= quantVar140k; ++quantVar140k) {
              b_43 = b_43 && (0 <= indexR[quantVar140k] && indexR[quantVar140k] < BLOCKSIZE);
            }
            CProver.assume((b_43));
            b_44 = false;
            for (int quantVar141k = 0; 0 <= quantVar141k && numRight - 1 - 1 >= quantVar141k; ++quantVar141k) {
              b_44 = b_44 && indexR[quantVar141k] < indexR[quantVar141k + 1];
            }
            CProver.assume((b_44));
          }
          if (j < shiftR) {
            assert !false : "Illegal assignment to indexR[numRight] = j conflicting with assignables indexR[0 .. shiftR - 1], numRight, j, j";
            indexR[numRight] = j;
            numRight += pivot >= array[last - j] ? 1 : 0;
            j++;
            {
              int sum_27 = 0;
              int quantVar143k = CProver.nondetInt();
              int quantVar144k = CProver.nondetInt();
              int quantVar145k = CProver.nondetInt();
              {
                assert 0 <= j;
                assert j <= shiftR;
              }
              sum_27 = 0;
              for (int quantVar142k = 0; 0 <= quantVar142k && j - 1 >= quantVar142k; ++quantVar142k) {
                sum_27 += array[last - quantVar142k] <= pivot ? 1 : 0;
              }
              assert numRight == (sum_27);
              assert !(0 <= quantVar143k && quantVar143k < numRight) || 0 <= indexR[quantVar143k] && indexR[quantVar143k] < j && array[last - indexR[quantVar143k]] <= pivot;
              assert !(0 <= quantVar144k && quantVar144k < BLOCKSIZE) || 0 <= indexR[quantVar144k] && indexR[quantVar144k] < BLOCKSIZE;
              assert !(0 <= quantVar145k && quantVar145k < numRight - 1) || indexR[quantVar145k] < indexR[quantVar145k + 1];
            }
            {
              assert shiftR - j >= 0;
              assert shiftR - j < oldDecreasesClauseValue6;
            }
            CProver.assume(false);
          }
        }
      }
      assert !false : "Illegal assignment to num = min(numLeft, numRight) conflicting with assignables array[originalBegin .. originalEnd - 1]";
      num = min(numLeft, numRight);
      if (num > 0) {
        {
          int j = 0;
          int[] old55 = array;
          int[] old56 = array;
          int old57 = originalEnd - 1;
          int old58 = originalBegin;
          int[] old59 = array;
          int[] old60 = array;
          int old61 = begin + indexL[startLeft + num - 1];
          int old62 = begin + indexL[startLeft];
          int old63 = last - indexR[startRight];
          int old64 = last - indexR[startRight + num - 1];
          int[] old65 = array;
          {
            int quantVar146i = CProver.nondetInt();
            int quantVar147i = CProver.nondetInt();
            int quantVar148i = CProver.nondetInt();
            int quantVar149i = CProver.nondetInt();
            int quantVar150i = CProver.nondetInt();
            int quantVar151i = CProver.nondetInt();
            int[] $$param54 = null;
            int[] $$param55 = null;
            int $$param56 = 0;
            int $$param57 = 0;
            {
              assert 0 <= j;
              assert j <= num;
            }
            assert !(originalBegin <= quantVar146i && quantVar146i < begin + indexL[startLeft]) || array[quantVar146i] <= pivot;
            assert !(j > 0) || (!(originalBegin <= quantVar147i && quantVar147i <= begin + indexL[startLeft + j - 1]) || array[quantVar147i] <= pivot);
            assert !(last - indexR[startRight] < quantVar148i && quantVar148i < originalEnd) || pivot <= array[quantVar148i];
            assert !(j > 0) || (!(last - indexR[startRight + j - 1] <= quantVar149i && quantVar149i < originalEnd) || pivot <= array[quantVar149i]);
            assert !(startLeft + j <= quantVar150i && quantVar150i < startLeft + numLeft) || pivot <= array[begin + indexL[quantVar150i]];
            assert !(startRight + j <= quantVar151i && quantVar151i < startRight + numRight) || array[last - indexR[quantVar151i]] <= pivot;
            $$param54 = array;
            $$param55 = old55;
            $$param56 = begin;
            $$param57 = last + 1;
            assert permutationSymb($$param54, $$param55, $$param56, $$param57);
          }
          assert !(true && (old56 != array || begin + indexL[startLeft + num - 1] > old57 || begin + indexL[startLeft] < old58)) : "Illegal assignment to array[begin + indexL[startLeft] .. begin + indexL[startLeft + num - 1]] conflicting with assiganbles + array[originalBegin .. originalEnd - 1]";
          assert !(true && (old56 != array || last - indexR[startRight] > old57 || last - indexR[startRight + num - 1] < old58)) : "Illegal assignment to array[last - indexR[startRight + num - 1] .. last - indexR[startRight]] conflicting with assiganbles + array[originalBegin .. originalEnd - 1]";
          j = CProver.nondetInt();
          if (array != null) {
            for (int __tmpVar__0 = last - indexR[startRight + num - 1]; __tmpVar__0 <= last - indexR[startRight]; ++__tmpVar__0) {
              array[__tmpVar__0] = CProver.nondetInt();
            }
          }
          if (array != null) {
            for (int __tmpVar__0 = begin + indexL[startLeft]; __tmpVar__0 <= begin + indexL[startLeft + num - 1]; ++__tmpVar__0) {
              array[__tmpVar__0] = CProver.nondetInt();
            }
          }
          int oldDecreasesClauseValue7 = num - j;
          {
            boolean b_45 = true;
            boolean b_46 = true;
            boolean b_47 = true;
            boolean b_48 = true;
            boolean b_49 = true;
            boolean b_50 = true;
            int[] $$param58 = null;
            int[] $$param59 = null;
            int $$param60 = 0;
            int $$param61 = 0;
            CProver.assume(0 <= j && j <= num);
            b_45 = false;
            for (int quantVar152i = originalBegin; originalBegin <= quantVar152i && begin + indexL[startLeft] - 1 >= quantVar152i; ++quantVar152i) {
              b_45 = b_45 && array[quantVar152i] <= pivot;
            }
            CProver.assume((b_45));
            if (!!(j > 0)) {
              b_46 = false;
              for (int quantVar153i = originalBegin; originalBegin <= quantVar153i && begin + indexL[startLeft + j - 1] >= quantVar153i; ++quantVar153i) {
                b_46 = b_46 && array[quantVar153i] <= pivot;
              }
            }
            CProver.assume(!(j > 0) || (b_46));
            b_47 = false;
            for (int quantVar154i = last - indexR[startRight] + 1; last - indexR[startRight] + 1 <= quantVar154i && originalEnd - 1 >= quantVar154i; ++quantVar154i) {
              b_47 = b_47 && pivot <= array[quantVar154i];
            }
            CProver.assume((b_47));
            if (!!(j > 0)) {
              b_48 = false;
              for (int quantVar155i = last - indexR[startRight + j - 1]; last - indexR[startRight + j - 1] <= quantVar155i && originalEnd - 1 >= quantVar155i; ++quantVar155i) {
                b_48 = b_48 && pivot <= array[quantVar155i];
              }
            }
            CProver.assume(!(j > 0) || (b_48));
            b_49 = false;
            for (int quantVar156i = startLeft + j; startLeft + j <= quantVar156i && startLeft + numLeft - 1 >= quantVar156i; ++quantVar156i) {
              b_49 = b_49 && pivot <= array[begin + indexL[quantVar156i]];
            }
            CProver.assume((b_49));
            b_50 = false;
            for (int quantVar157i = startRight + j; startRight + j <= quantVar157i && startRight + numRight - 1 >= quantVar157i; ++quantVar157i) {
              b_50 = b_50 && array[last - indexR[quantVar157i]] <= pivot;
            }
            CProver.assume((b_50));
            $$param58 = array;
            $$param59 = old59;
            $$param60 = begin;
            $$param61 = last + 1;
            CProver.assume(permutationSymb($$param58, $$param59, $$param60, $$param61));
          }
          if (j < num) {
            $$param62 = array;
            $$param63 = begin + indexL[startLeft + j];
            $$param64 = last - indexR[startRight + j];
            assert !(true && (old60 != $$param62 || $$param63 > old61 || $$param63 < old62) && ($$param62 != $$param62 || $$param63 > old63 || $$param63 < old64)) : "Illegal assignment to array[i] conflicting with assignables array[begin + indexL[startLeft] .. begin + indexL[startLeft + num - 1]], array[last - indexR[startRight + num - 1] .. last - indexR[startRight]], j, j";
            assert !(true && (old60 != $$param62 || $$param64 > old61 || $$param64 < old62) && ($$param62 != $$param62 || $$param64 > old63 || $$param64 < old64)) : "Illegal assignment to array[j] conflicting with assignables array[begin + indexL[startLeft] .. begin + indexL[startLeft + num - 1]], array[last - indexR[startRight + num - 1] .. last - indexR[startRight]], j, j";
            swapSymb($$param62, $$param63, $$param64);
            j++;
            {
              int quantVar158i = CProver.nondetInt();
              int quantVar159i = CProver.nondetInt();
              int quantVar160i = CProver.nondetInt();
              int quantVar161i = CProver.nondetInt();
              int quantVar162i = CProver.nondetInt();
              int quantVar163i = CProver.nondetInt();
              int[] $$param65 = null;
              int[] $$param66 = null;
              int $$param67 = 0;
              int $$param68 = 0;
              {
                assert 0 <= j;
                assert j <= num;
              }
              assert !(originalBegin <= quantVar158i && quantVar158i < begin + indexL[startLeft]) || array[quantVar158i] <= pivot;
              assert !(j > 0) || (!(originalBegin <= quantVar159i && quantVar159i <= begin + indexL[startLeft + j - 1]) || array[quantVar159i] <= pivot);
              assert !(last - indexR[startRight] < quantVar160i && quantVar160i < originalEnd) || pivot <= array[quantVar160i];
              assert !(j > 0) || (!(last - indexR[startRight + j - 1] <= quantVar161i && quantVar161i < originalEnd) || pivot <= array[quantVar161i]);
              assert !(startLeft + j <= quantVar162i && quantVar162i < startLeft + numLeft) || pivot <= array[begin + indexL[quantVar162i]];
              assert !(startRight + j <= quantVar163i && quantVar163i < startRight + numRight) || array[last - indexR[quantVar163i]] <= pivot;
              $$param65 = array;
              $$param66 = old65;
              $$param67 = begin;
              $$param68 = last + 1;
              assert permutationSymb($$param65, $$param66, $$param67, $$param68);
            }
            {
              assert num - j >= 0;
              assert num - j < oldDecreasesClauseValue7;
            }
            CProver.assume(false);
          }
        }
      }
      numLeft -= num;
      numRight -= num;
      startLeft += num;
      startRight += num;
      begin += (numLeft == 0) ? shiftL : 0;
      last -= (numRight == 0) ? shiftR : 0;
      if (numLeft != 0) {
        int lowerI = startLeft + numLeft - 1;
        int upper = last - begin;
        {
          int quantVar164i = CProver.nondetInt();
          int quantVar165i = CProver.nondetInt();
          int quantVar166i = CProver.nondetInt();
          {
            assert 0 <= startLeft;
            assert startLeft - 1 <= lowerI;
            assert lowerI < startLeft + numLeft;
            assert startLeft + numLeft <= BLOCKSIZE;
          }
          assert upper == last - begin - (startLeft + numLeft - 1 - lowerI);
          assert !(lowerI < quantVar164i && quantVar164i < startLeft + numLeft - 1) || indexL[quantVar164i] == upper + (quantVar164i - lowerI);
          assert !(begin <= quantVar165i && quantVar165i < begin + indexL[startLeft]) || array[quantVar165i] <= pivot;
          assert !(begin + upper < quantVar166i && quantVar166i <= last) || pivot <= array[quantVar166i];
        }
        upper = CProver.nondetInt();
        lowerI = CProver.nondetInt();
        int oldDecreasesClauseValue8 = lowerI + 1;
        {
          boolean b_51 = true;
          boolean b_52 = true;
          boolean b_53 = true;
          CProver.assume(0 <= startLeft && startLeft - 1 <= lowerI && lowerI < startLeft + numLeft && startLeft + numLeft <= BLOCKSIZE);
          CProver.assume(upper == last - begin - (startLeft + numLeft - 1 - lowerI));
          b_51 = false;
          for (int quantVar167i = lowerI + 1; lowerI + 1 <= quantVar167i && startLeft + numLeft - 1 - 1 >= quantVar167i; ++quantVar167i) {
            b_51 = b_51 && indexL[quantVar167i] == upper + (quantVar167i - lowerI);
          }
          CProver.assume((b_51));
          b_52 = false;
          for (int quantVar168i = begin; begin <= quantVar168i && begin + indexL[startLeft] - 1 >= quantVar168i; ++quantVar168i) {
            b_52 = b_52 && array[quantVar168i] <= pivot;
          }
          CProver.assume((b_52));
          b_53 = false;
          for (int quantVar169i = begin + upper + 1; begin + upper + 1 <= quantVar169i && last >= quantVar169i; ++quantVar169i) {
            b_53 = b_53 && pivot <= array[quantVar169i];
          }
          CProver.assume((b_53));
        }
        if (lowerI >= startLeft && indexL[lowerI] == upper) {
          upper--;
          lowerI--;
          {
            int quantVar170i = CProver.nondetInt();
            int quantVar171i = CProver.nondetInt();
            int quantVar172i = CProver.nondetInt();
            {
              assert 0 <= startLeft;
              assert startLeft - 1 <= lowerI;
              assert lowerI < startLeft + numLeft;
              assert startLeft + numLeft <= BLOCKSIZE;
            }
            assert upper == last - begin - (startLeft + numLeft - 1 - lowerI);
            assert !(lowerI < quantVar170i && quantVar170i < startLeft + numLeft - 1) || indexL[quantVar170i] == upper + (quantVar170i - lowerI);
            assert !(begin <= quantVar171i && quantVar171i < begin + indexL[startLeft]) || array[quantVar171i] <= pivot;
            assert !(begin + upper < quantVar172i && quantVar172i <= last) || pivot <= array[quantVar172i];
          }
          {
            assert lowerI + 1 >= 0;
            assert lowerI + 1 < oldDecreasesClauseValue8;
          }
          CProver.assume(false);
        }
        int[] old66 = array;
        int[] old67 = array;
        int old68 = originalEnd - 1;
        int old69 = originalBegin;
        int[] old70 = array;
        int[] old71 = array;
        int old72 = last;
        int old73 = begin + indexL[startLeft];
        int[] old74 = array;
        {
          int quantVar173i = CProver.nondetInt();
          int quantVar174i = CProver.nondetInt();
          int quantVar175i = CProver.nondetInt();
          int[] $$param69 = null;
          int[] $$param70 = null;
          int $$param71 = 0;
          int $$param72 = 0;
          {
            assert 0 <= startLeft;
            assert startLeft - 1 <= lowerI;
            assert lowerI < startLeft + numLeft;
            assert startLeft + numLeft <= BLOCKSIZE;
          }
          assert upper == last - begin - (startLeft + numLeft - 1 - lowerI);
          assert !(startLeft <= quantVar173i && quantVar173i < lowerI) || indexL[quantVar173i] == indexL[quantVar173i + 1] - 1;
          assert !(begin + indexL[startLeft] <= quantVar174i && quantVar174i < begin + upper) || pivot <= array[quantVar174i];
          assert !(begin + upper < quantVar175i && quantVar175i <= last) || pivot <= array[quantVar175i];
          assert !(lowerI >= startLeft) || (indexL[lowerI] == upper || array[begin + upper] <= pivot);
          assert !(lowerI < startLeft) || !(upper >= 0) || array[begin + upper] <= pivot;
          $$param69 = array;
          $$param70 = old66;
          $$param71 = begin;
          $$param72 = last + 1;
          assert permutationSymb($$param69, $$param70, $$param71, $$param72);
        }
        assert !(true && (old67 != array || last > old68 || begin + indexL[startLeft] < old69)) : "Illegal assignment to array[begin + indexL[startLeft] .. last] conflicting with assiganbles + array[originalBegin .. originalEnd - 1]";
        lowerI = CProver.nondetInt();
        upper = CProver.nondetInt();
        if (array != null) {
          for (int __tmpVar__0 = begin + indexL[startLeft]; __tmpVar__0 <= last; ++__tmpVar__0) {
            array[__tmpVar__0] = CProver.nondetInt();
          }
        }
        int oldDecreasesClauseValue9 = lowerI + 1;
        {
          boolean b_54 = true;
          boolean b_55 = true;
          boolean b_56 = true;
          int[] $$param73 = null;
          int[] $$param74 = null;
          int $$param75 = 0;
          int $$param76 = 0;
          CProver.assume(0 <= startLeft && startLeft - 1 <= lowerI && lowerI < startLeft + numLeft && startLeft + numLeft <= BLOCKSIZE);
          CProver.assume(upper == last - begin - (startLeft + numLeft - 1 - lowerI));
          b_54 = false;
          for (int quantVar176i = startLeft; startLeft <= quantVar176i && lowerI - 1 >= quantVar176i; ++quantVar176i) {
            b_54 = b_54 && indexL[quantVar176i] == indexL[quantVar176i + 1] - 1;
          }
          CProver.assume((b_54));
          b_55 = false;
          for (int quantVar177i = begin + indexL[startLeft]; begin + indexL[startLeft] <= quantVar177i && begin + upper - 1 >= quantVar177i; ++quantVar177i) {
            b_55 = b_55 && pivot <= array[quantVar177i];
          }
          CProver.assume((b_55));
          b_56 = false;
          for (int quantVar178i = begin + upper + 1; begin + upper + 1 <= quantVar178i && last >= quantVar178i; ++quantVar178i) {
            b_56 = b_56 && pivot <= array[quantVar178i];
          }
          CProver.assume((b_56));
          CProver.assume(!(lowerI >= startLeft) || (indexL[lowerI] == upper || array[begin + upper] <= pivot));
          CProver.assume(!(lowerI < startLeft) || !(upper >= 0) || array[begin + upper] <= pivot);
          $$param73 = array;
          $$param74 = old70;
          $$param75 = begin;
          $$param76 = last + 1;
          CProver.assume(permutationSymb($$param73, $$param74, $$param75, $$param76));
        }
        if (lowerI >= startLeft) {
          $$param77 = array;
          $$param78 = begin + upper;
          $$param79 = begin + indexL[lowerI];
          assert !(true && (old71 != $$param77 || $$param78 > old72 || $$param78 < old73)) : "Illegal assignment to array[i] conflicting with assignables array[begin + indexL[startLeft] .. last], upper, lowerI";
          assert !(true && (old71 != $$param77 || $$param79 > old72 || $$param79 < old73)) : "Illegal assignment to array[j] conflicting with assignables array[begin + indexL[startLeft] .. last], upper, lowerI";
          swapSymb($$param77, $$param78, $$param79);
          upper--;
          lowerI--;
          {
            int quantVar179i = CProver.nondetInt();
            int quantVar180i = CProver.nondetInt();
            int quantVar181i = CProver.nondetInt();
            int[] $$param80 = null;
            int[] $$param81 = null;
            int $$param82 = 0;
            int $$param83 = 0;
            {
              assert 0 <= startLeft;
              assert startLeft - 1 <= lowerI;
              assert lowerI < startLeft + numLeft;
              assert startLeft + numLeft <= BLOCKSIZE;
            }
            assert upper == last - begin - (startLeft + numLeft - 1 - lowerI);
            assert !(startLeft <= quantVar179i && quantVar179i < lowerI) || indexL[quantVar179i] == indexL[quantVar179i + 1] - 1;
            assert !(begin + indexL[startLeft] <= quantVar180i && quantVar180i < begin + upper) || pivot <= array[quantVar180i];
            assert !(begin + upper < quantVar181i && quantVar181i <= last) || pivot <= array[quantVar181i];
            assert !(lowerI >= startLeft) || (indexL[lowerI] == upper || array[begin + upper] <= pivot);
            assert !(lowerI < startLeft) || !(upper >= 0) || array[begin + upper] <= pivot;
            $$param80 = array;
            $$param81 = old74;
            $$param82 = begin;
            $$param83 = last + 1;
            assert permutationSymb($$param80, $$param81, $$param82, $$param83);
          }
          {
            assert lowerI + 1 >= 0;
            assert lowerI + 1 < oldDecreasesClauseValue9;
          }
          CProver.assume(false);
        }
        $$param84 = array;
        $$param85 = pivotPosition;
        $$param86 = begin + upper + 1;
        assert !(true && (old26 != $$param84 || $$param85 > old27 || $$param85 < old28)) : "Illegal assignment to array[i] conflicting with assignables array[originalBegin .. originalEnd - 1]";
        assert !(true && (old26 != $$param84 || $$param86 > old27 || $$param86 < old28)) : "Illegal assignment to array[j] conflicting with assignables array[originalBegin .. originalEnd - 1]";
        swapSymb($$param84, $$param85, $$param86);
        {
          returnVar = begin + upper + 1;
          throw new BlockQuickSort.ReturnException();
        }
      } else if (numRight != 0) {
        int lowerI = startRight + numRight - 1;
        int upper = last - begin;
        {
          int quantVar182i = CProver.nondetInt();
          int quantVar183i = CProver.nondetInt();
          int quantVar184i = CProver.nondetInt();
          {
            assert 0 <= startRight;
            assert startRight - 1 <= lowerI;
            assert lowerI < startRight + numRight;
            assert startRight + numRight <= BLOCKSIZE;
          }
          assert upper == last - begin - (startRight + numRight - 1 - lowerI);
          assert !(lowerI < quantVar182i && quantVar182i < startRight + numRight - 1) || indexR[quantVar182i] == upper + (quantVar182i - lowerI);
          assert !(last - indexR[startRight] < quantVar183i && quantVar183i <= last) || pivot <= array[quantVar183i];
          assert !(begin <= quantVar184i && quantVar184i < last - upper) || array[quantVar184i] <= pivot;
        }
        upper = CProver.nondetInt();
        lowerI = CProver.nondetInt();
        int oldDecreasesClauseValue10 = lowerI + 1;
        {
          boolean b_57 = true;
          boolean b_58 = true;
          boolean b_59 = true;
          CProver.assume(0 <= startRight && startRight - 1 <= lowerI && lowerI < startRight + numRight && startRight + numRight <= BLOCKSIZE);
          CProver.assume(upper == last - begin - (startRight + numRight - 1 - lowerI));
          b_57 = false;
          for (int quantVar185i = lowerI + 1; lowerI + 1 <= quantVar185i && startRight + numRight - 1 - 1 >= quantVar185i; ++quantVar185i) {
            b_57 = b_57 && indexR[quantVar185i] == upper + (quantVar185i - lowerI);
          }
          CProver.assume((b_57));
          b_58 = false;
          for (int quantVar186i = last - indexR[startRight] + 1; last - indexR[startRight] + 1 <= quantVar186i && last >= quantVar186i; ++quantVar186i) {
            b_58 = b_58 && pivot <= array[quantVar186i];
          }
          CProver.assume((b_58));
          b_59 = false;
          for (int quantVar187i = begin; begin <= quantVar187i && last - upper - 1 >= quantVar187i; ++quantVar187i) {
            b_59 = b_59 && array[quantVar187i] <= pivot;
          }
          CProver.assume((b_59));
        }
        if (lowerI >= startRight && indexR[lowerI] == upper) {
          upper--;
          lowerI--;
          {
            int quantVar188i = CProver.nondetInt();
            int quantVar189i = CProver.nondetInt();
            int quantVar190i = CProver.nondetInt();
            {
              assert 0 <= startRight;
              assert startRight - 1 <= lowerI;
              assert lowerI < startRight + numRight;
              assert startRight + numRight <= BLOCKSIZE;
            }
            assert upper == last - begin - (startRight + numRight - 1 - lowerI);
            assert !(lowerI < quantVar188i && quantVar188i < startRight + numRight - 1) || indexR[quantVar188i] == upper + (quantVar188i - lowerI);
            assert !(last - indexR[startRight] < quantVar189i && quantVar189i <= last) || pivot <= array[quantVar189i];
            assert !(begin <= quantVar190i && quantVar190i < last - upper) || array[quantVar190i] <= pivot;
          }
          {
            assert lowerI + 1 >= 0;
            assert lowerI + 1 < oldDecreasesClauseValue10;
          }
          CProver.assume(false);
        }
        int[] old75 = array;
        int[] old76 = array;
        int old77 = originalEnd - 1;
        int old78 = originalBegin;
        int[] old79 = array;
        int[] old80 = array;
        int old81 = last - indexR[startRight];
        int old82 = begin;
        int[] old83 = array;
        {
          int quantVar191i = CProver.nondetInt();
          int quantVar192i = CProver.nondetInt();
          int quantVar193i = CProver.nondetInt();
          int[] $$param87 = null;
          int[] $$param88 = null;
          int $$param89 = 0;
          int $$param90 = 0;
          {
            assert 0 <= startRight;
            assert startRight - 1 <= lowerI;
            assert lowerI < startRight + numRight;
            assert startRight + numRight <= BLOCKSIZE;
          }
          assert upper == last - begin - (startRight + numRight - 1 - lowerI);
          assert !(startRight <= quantVar191i && quantVar191i < lowerI) || indexR[quantVar191i] == indexR[quantVar191i + 1] - 1;
          assert !(begin <= quantVar192i && quantVar192i < last - upper) || array[quantVar192i] <= pivot;
          assert !(last - upper < quantVar193i && quantVar193i <= last - indexR[startRight]) || array[quantVar193i] <= pivot;
          assert !(lowerI >= startRight) || (indexR[lowerI] == upper || pivot <= array[last - upper]);
          assert !(lowerI < startRight) || !(upper >= 0) || pivot <= array[last - upper];
          $$param87 = array;
          $$param88 = old75;
          $$param89 = begin;
          $$param90 = last + 1;
          assert permutationSymb($$param87, $$param88, $$param89, $$param90);
        }
        assert !(true && (old76 != array || last - indexR[startRight] > old77 || begin < old78)) : "Illegal assignment to array[begin .. last - indexR[startRight]] conflicting with assiganbles + array[originalBegin .. originalEnd - 1]";
        lowerI = CProver.nondetInt();
        upper = CProver.nondetInt();
        if (array != null) {
          for (int __tmpVar__0 = begin; __tmpVar__0 <= last - indexR[startRight]; ++__tmpVar__0) {
            array[__tmpVar__0] = CProver.nondetInt();
          }
        }
        int oldDecreasesClauseValue11 = lowerI + 1;
        {
          boolean b_60 = true;
          boolean b_61 = true;
          boolean b_62 = true;
          int[] $$param91 = null;
          int[] $$param92 = null;
          int $$param93 = 0;
          int $$param94 = 0;
          CProver.assume(0 <= startRight && startRight - 1 <= lowerI && lowerI < startRight + numRight && startRight + numRight <= BLOCKSIZE);
          CProver.assume(upper == last - begin - (startRight + numRight - 1 - lowerI));
          b_60 = false;
          for (int quantVar194i = startRight; startRight <= quantVar194i && lowerI - 1 >= quantVar194i; ++quantVar194i) {
            b_60 = b_60 && indexR[quantVar194i] == indexR[quantVar194i + 1] - 1;
          }
          CProver.assume((b_60));
          b_61 = false;
          for (int quantVar195i = begin; begin <= quantVar195i && last - upper - 1 >= quantVar195i; ++quantVar195i) {
            b_61 = b_61 && array[quantVar195i] <= pivot;
          }
          CProver.assume((b_61));
          b_62 = false;
          for (int quantVar196i = last - upper + 1; last - upper + 1 <= quantVar196i && last - indexR[startRight] >= quantVar196i; ++quantVar196i) {
            b_62 = b_62 && array[quantVar196i] <= pivot;
          }
          CProver.assume((b_62));
          CProver.assume(!(lowerI >= startRight) || (indexR[lowerI] == upper || pivot <= array[last - upper]));
          CProver.assume(!(lowerI < startRight) || !(upper >= 0) || pivot <= array[last - upper]);
          $$param91 = array;
          $$param92 = old79;
          $$param93 = begin;
          $$param94 = last + 1;
          CProver.assume(permutationSymb($$param91, $$param92, $$param93, $$param94));
        }
        if (lowerI >= startRight) {
          $$param95 = array;
          $$param96 = last - upper;
          $$param97 = last - indexR[lowerI];
          assert !(true && (old80 != $$param95 || $$param96 > old81 || $$param96 < old82)) : "Illegal assignment to array[i] conflicting with assignables array[begin .. last - indexR[startRight]], upper, lowerI";
          assert !(true && (old80 != $$param95 || $$param97 > old81 || $$param97 < old82)) : "Illegal assignment to array[j] conflicting with assignables array[begin .. last - indexR[startRight]], upper, lowerI";
          swapSymb($$param95, $$param96, $$param97);
          upper--;
          lowerI--;
          {
            int quantVar197i = CProver.nondetInt();
            int quantVar198i = CProver.nondetInt();
            int quantVar199i = CProver.nondetInt();
            int[] $$param98 = null;
            int[] $$param99 = null;
            int $$param100 = 0;
            int $$param101 = 0;
            {
              assert 0 <= startRight;
              assert startRight - 1 <= lowerI;
              assert lowerI < startRight + numRight;
              assert startRight + numRight <= BLOCKSIZE;
            }
            assert upper == last - begin - (startRight + numRight - 1 - lowerI);
            assert !(startRight <= quantVar197i && quantVar197i < lowerI) || indexR[quantVar197i] == indexR[quantVar197i + 1] - 1;
            assert !(begin <= quantVar198i && quantVar198i < last - upper) || array[quantVar198i] <= pivot;
            assert !(last - upper < quantVar199i && quantVar199i <= last - indexR[startRight]) || array[quantVar199i] <= pivot;
            assert !(lowerI >= startRight) || (indexR[lowerI] == upper || pivot <= array[last - upper]);
            assert !(lowerI < startRight) || !(upper >= 0) || pivot <= array[last - upper];
            $$param98 = array;
            $$param99 = old83;
            $$param100 = begin;
            $$param101 = last + 1;
            assert permutationSymb($$param98, $$param99, $$param100, $$param101);
          }
          {
            assert lowerI + 1 >= 0;
            assert lowerI + 1 < oldDecreasesClauseValue11;
          }
          CProver.assume(false);
        }
        $$param102 = array;
        $$param103 = pivotPosition;
        $$param104 = last - upper;
        assert !(true && (old26 != $$param102 || $$param103 > old27 || $$param103 < old28)) : "Illegal assignment to array[i] conflicting with assignables array[originalBegin .. originalEnd - 1]";
        assert !(true && (old26 != $$param102 || $$param104 > old27 || $$param104 < old28)) : "Illegal assignment to array[j] conflicting with assignables array[originalBegin .. originalEnd - 1]";
        swapSymb($$param102, $$param103, $$param104);
        {
          returnVar = last - upper;
          throw new BlockQuickSort.ReturnException();
        }
      } else {
        $$param105 = array;
        $$param106 = pivotPosition;
        $$param107 = begin;
        assert !(true && (old26 != $$param105 || $$param106 > old27 || $$param106 < old28)) : "Illegal assignment to array[i] conflicting with assignables array[originalBegin .. originalEnd - 1]";
        assert !(true && (old26 != $$param105 || $$param107 > old27 || $$param107 < old28)) : "Illegal assignment to array[j] conflicting with assignables array[originalBegin .. originalEnd - 1]";
        swapSymb($$param105, $$param106, $$param107);
        {
          returnVar = begin;
          throw new BlockQuickSort.ReturnException();
        }
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old23;
    }
    {
      {
        assert originalBegin <= returnVar;
        assert returnVar < originalEnd;
      }
    }
    {
      assert array[returnVar] == old24;
    }
    {
      int quantVar12i = CProver.nondetInt();
      assert !(originalBegin <= quantVar12i && quantVar12i <= returnVar) || array[quantVar12i] <= array[returnVar];
    }
    {
      int quantVar13i = CProver.nondetInt();
      assert !(returnVar <= quantVar13i && quantVar13i < originalEnd) || array[returnVar] <= array[quantVar13i];
    }
    {
      int[] $$param20 = null;
      int[] $$param21 = null;
      int $$param22 = 0;
      int $$param23 = 0;
      $$param20 = array;
      $$param21 = old25;
      $$param22 = originalBegin;
      $$param23 = originalEnd;
      assert permutationSymb($$param20, $$param21, $$param22, $$param23);
    }
    return returnVar;
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= originalBegin && originalBegin < originalEnd && originalEnd <= array.length; 
      requires (originalEnd - originalBegin) >= 1; 
      requires originalBegin <= pivotPosition && pivotPosition < originalEnd; 
      ensures array.length == \old(array.length); 
      ensures originalBegin <= \result && \result < originalEnd; 
      ensures array[\result] == \old(array[pivotPosition]); 
      ensures (\forall int i; originalBegin <= i <= \result; array[i] <= array[\result]); 
      ensures (\forall int i; \result <= i < originalEnd; array[\result] <= array[i]); 
      ensures permutation(array, \old(array), originalBegin, originalEnd); 
      assignable array[originalBegin .. originalEnd - 1]; 
   */

  public static int hoareBlockPartition( 
  int[] array, int originalBegin, int originalEnd, int pivotPosition) {
     
    int[] indexL = new int[BLOCKSIZE];
     
    int[] indexR = new int[BLOCKSIZE];
    int begin = originalBegin;
    int end = originalEnd;
    int last = end - 1;
    int pivot = array[pivotPosition];
    swap(array, pivotPosition, last);
    pivotPosition = last;
    last--;
    int numLeft = 0;
    int numRight = 0;
    int startLeft = 0;
    int startRight = 0;
    int num = 0;
    if (last - begin + 1 > 2 * BLOCKSIZE) {
      //@ loop_invariant originalBegin <= begin && begin <= last && last < originalEnd - 1;
      //@ loop_invariant 0 <= numLeft && numLeft <= BLOCKSIZE;
      //@ loop_invariant 0 <= numRight && numRight <= BLOCKSIZE;
      //@ loop_invariant 0 <= startLeft && startLeft <= BLOCKSIZE && startLeft + numLeft <= BLOCKSIZE;
      //@ loop_invariant 0 <= startRight && startRight <= BLOCKSIZE && startRight + numRight <= BLOCKSIZE;
      //@ loop_invariant 0 <= num && num <= BLOCKSIZE;
      //@ loop_invariant numRight == 0 || numLeft == 0;
      //@ loop_invariant array[originalEnd - 1] == \old(array[pivotPosition]);
      //@ loop_invariant (\exists int i; 0 <= i < (originalEnd - originalBegin); begin == originalBegin + i * BLOCKSIZE);
      //@ loop_invariant (\exists int i; 0 <= i < (originalEnd - originalBegin); last == originalEnd - 2 - i * BLOCKSIZE);
      //@ loop_invariant (\forall int i; 0 <= i < BLOCKSIZE; 0 <= indexL[i] && indexL[i] < BLOCKSIZE);
      //@ loop_invariant (\forall int i; 0 <= i < numLeft; indexL[startLeft + i] < last - begin && pivot <= array[begin + indexL[startLeft + i]]);
      //@ loop_invariant (\forall int i; 0 <= i < startLeft + numLeft - 1; indexL[i] < indexL[i + 1]);
      //@ loop_invariant (numLeft != 0) ==> numLeft == (\num_of int i; startLeft <= i < BLOCKSIZE; pivot <= array[begin + i]);
      //@ loop_invariant (\forall int i; 0 <= i < BLOCKSIZE; 0 <= indexR[i] && indexR[i] < BLOCKSIZE);
      //@ loop_invariant (\forall int i; 0 <= i < numRight; indexR[startRight + i] < last - begin && array[last - indexR[startRight + i]] <= pivot);
      //@ loop_invariant (\forall int i; 0 <= i < startRight + numRight - 1; indexR[i] < indexR[i + 1]);
      //@ loop_invariant (numRight != 0) ==> numRight == (\num_of int i; startRight <= i < BLOCKSIZE; array[last - i] <= pivot);
      //@ loop_invariant (numLeft == 0) ==> (\forall int i; originalBegin <= i < begin; array[i] <= pivot);
      //@ loop_invariant (numLeft != 0) ==> (\forall int i; originalBegin <= i < begin + indexL[startLeft]; array[i] <= pivot);
      //@ loop_invariant (numRight == 0) ==> (\forall int i; last < i < originalEnd; pivot <= array[i]);
      //@ loop_invariant (numRight != 0) ==> (\forall int i; last - indexR[startRight] < i < originalEnd; pivot <= array[i]);
      //@ loop_invariant permutation(array, \old(array), originalBegin, originalEnd);
      //@ loop_modifies array[max(begin, originalBegin) .. min(begin + BLOCKSIZE - 1, originalEnd - 2)], array[max(last - BLOCKSIZE - 1, originalBegin) .. min(last, originalEnd - 2)], last, begin, numLeft, numRight, startLeft, startRight, num, indexL[0 .. BLOCKSIZE - 1], indexR[0 .. BLOCKSIZE - 1];
      //@ loop_decreases last - begin;
      while (last - begin + 1 > 2 * BLOCKSIZE) {
        if (numLeft == 0) {
          startLeft = 0;
          //@ loop_invariant 0 <= j <= BLOCKSIZE;
          //@ loop_invariant numLeft == (\num_of int k; 0 <= k < j; pivot <= array[begin + k]);
          //@ loop_invariant (\forall int k; 0 <= k < numLeft; 0 <= indexL[k] && indexL[k] < j && pivot <= array[begin + indexL[k]]);
          //@ loop_invariant (\forall int k; 0 <= k < BLOCKSIZE; 0 <= indexL[k] && indexL[k] < BLOCKSIZE);
          //@ loop_invariant (\forall int k; 0 <= k < numLeft - 1; indexL[k] < indexL[k + 1]);
          //@ loop_modifies numLeft, indexL[0 .. BLOCKSIZE - 1], j;
          //@ loop_decreases BLOCKSIZE - j;
          for (int j = 0; j < BLOCKSIZE; j++) {
            indexL[numLeft] = j;
            numLeft += array[begin + j] >= pivot ? 1 : 0;
            j++;
          }
        }
        if (numRight == 0) {
          startRight = 0;
          //@ loop_invariant 0 <= j <= BLOCKSIZE;
          //@ loop_invariant numRight == (\num_of int k; 0 <= k < j; array[last - k] <= pivot);
          //@ loop_invariant (\forall int k; 0 <= k < numRight; 0 <= indexR[k] && indexR[k] < j && array[last - indexR[k]] <= pivot);
          //@ loop_invariant (\forall int k; 0 <= k < BLOCKSIZE; 0 <= indexR[k] && indexR[k] < BLOCKSIZE);
          //@ loop_invariant (\forall int k; 0 <= k < numRight - 1; indexR[k] < indexR[k + 1]);
          //@ loop_modifies numRight, indexR[0 .. BLOCKSIZE - 1], j;
          //@ loop_decreases BLOCKSIZE - j;
          for (int j = 0; j < BLOCKSIZE; j++) {
            indexR[numRight] = j;
            numRight += pivot >= array[last - j] ? 1 : 0;
            j++;
          }
        }
        num = min(numLeft, numRight);
        if (num > 0) {
          //@ loop_invariant 0 <= j <= num;
          //@ loop_invariant (\forall int i; originalBegin <= i < begin + indexL[startLeft]; array[i] <= pivot);
          //@ loop_invariant j > 0 ==> (\forall int i; originalBegin <= i <= begin + indexL[startLeft + j - 1]; array[i] <= pivot);
          //@ loop_invariant (\forall int i; last - indexR[startRight] < i < originalEnd; pivot <= array[i]);
          //@ loop_invariant j > 0 ==> (\forall int i; last - indexR[startRight + j - 1] <= i < originalEnd; pivot <= array[i]);
          //@ loop_invariant (\forall int i; startLeft + j <= i < startLeft + numLeft; pivot <= array[begin + indexL[i]]);
          //@ loop_invariant (\forall int i; startRight + j <= i < startRight + numRight; array[last - indexR[i]] <= pivot);
          //@ loop_invariant permutation(array, \old(array), begin, last + 1);
          //@ loop_modifies array[begin + indexL[startLeft] .. begin + indexL[startLeft + num - 1]], array[last - indexR[startRight + num - 1] .. last - indexR[startRight]], j;
          //@ loop_decreases num - j;
          for (int j = 0; j < num; j++) {
            swap(array, begin + indexL[startLeft + j], last - indexR[startRight + j]);
            j++;
          }
        }
        numLeft -= num;
        numRight -= num;
        startLeft += num;
        startRight += num;
        begin += (numLeft == 0) ? BLOCKSIZE : 0;
        last -= (numRight == 0) ? BLOCKSIZE : 0;
      }
    }
    int shiftR = 0;
    int shiftL = 0;
    if (numRight == 0 && numLeft == 0) {
      shiftL = ((last - begin) + 1) / 2;
      shiftR = (last - begin) + 1 - shiftL;
      startLeft = 0;
      startRight = 0;
      //@ loop_invariant 0 <= j <= shiftL;
      //@ loop_invariant 0 <= numLeft && numLeft <= j;
      //@ loop_invariant 0 <= numRight && numRight <= j;
      //@ loop_invariant numLeft == (\num_of int k; 0 <= k < j; pivot <= array[begin + k]);
      //@ loop_invariant numRight == (\num_of int k; 0 <= k < j; array[last - k] <= pivot);
      //@ loop_invariant (\forall int k; 0 <= k < numLeft; 0 <= indexL[k] && indexL[k] < j && pivot <= array[begin + indexL[k]]);
      //@ loop_invariant (\forall int k; 0 <= k < BLOCKSIZE; 0 <= indexL[k] && indexL[k] < BLOCKSIZE);
      //@ loop_invariant (\forall int k; 0 <= k < numRight; 0 <= indexR[k] && indexR[k] < j && array[last - indexR[k]] <= pivot);
      //@ loop_invariant (\forall int k; 0 <= k < BLOCKSIZE; 0 <= indexR[k] && indexR[k] < BLOCKSIZE);
      //@ loop_invariant (\forall int k; 0 <= k < numLeft - 1; indexL[k] < indexL[k + 1]);
      //@ loop_invariant (\forall int k; 0 <= k < numRight - 1; indexR[k] < indexR[k + 1]);
      //@ loop_decreases shiftL - j;
      //@ loop_modifies indexL[0 .. shiftL - 1], numLeft, indexR[0 .. shiftL - 1], numRight, j;
      for (int j = 0; j < shiftL; j++) {
        indexL[numLeft] = j;
        numLeft += array[begin + j] >= pivot ? 1 : 0;
        indexR[numRight] = j;
        numRight += pivot >= array[last - j] ? 1 : 0;
        j++;
      }
      if (shiftL < shiftR) {
        indexR[numRight] = shiftR - 1;
        numRight += pivot >= array[last - shiftR + 1] ? 1 : 0;
      }
    } else if (numRight != 0) {
      shiftL = (last - begin) - BLOCKSIZE + 1;
      shiftR = BLOCKSIZE;
      startLeft = 0;
      //@ loop_invariant 0 <= j <= shiftL;
      //@ loop_invariant numLeft == (\num_of int k; 0 <= k < j; pivot <= array[begin + k]);
      //@ loop_invariant (\forall int k; 0 <= k < numLeft; 0 <= indexL[k] && indexL[k] < j && pivot <= array[begin + indexL[k]]);
      //@ loop_invariant (\forall int k; 0 <= k < BLOCKSIZE; 0 <= indexL[k] && indexL[k] < BLOCKSIZE);
      //@ loop_invariant (\forall int k; 0 <= k < numLeft - 1; indexL[k] < indexL[k + 1]);
      //@ loop_modifies numLeft, indexL[0 .. shiftL - 1], j;
      //@ loop_decreases shiftL - j;
      for (int j = 0; j < shiftL; j++) {
        indexL[numLeft] = j;
        numLeft += array[begin + j] >= pivot ? 1 : 0;
        j++;
      }
    } else {
      shiftL = BLOCKSIZE;
      shiftR = (last - begin) - BLOCKSIZE + 1;
      startRight = 0;
      //@ loop_invariant 0 <= j <= shiftR;
      //@ loop_invariant numRight == (\num_of int k; 0 <= k < j; array[last - k] <= pivot);
      //@ loop_invariant (\forall int k; 0 <= k < numRight; 0 <= indexR[k] && indexR[k] < j && array[last - indexR[k]] <= pivot);
      //@ loop_invariant (\forall int k; 0 <= k < BLOCKSIZE; 0 <= indexR[k] && indexR[k] < BLOCKSIZE);
      //@ loop_invariant (\forall int k; 0 <= k < numRight - 1; indexR[k] < indexR[k + 1]);
      //@ loop_modifies numRight, indexR[0 .. shiftR - 1], j;
      //@ loop_decreases shiftR - j;
      for (int j = 0; j < shiftR; j++) {
        indexR[numRight] = j;
        numRight += pivot >= array[last - j] ? 1 : 0;
        j++;
      }
    }
    num = min(numLeft, numRight);
    if (num > 0) {
      //@ loop_invariant 0 <= j <= num;
      //@ loop_invariant (\forall int i; originalBegin <= i < begin + indexL[startLeft]; array[i] <= pivot);
      //@ loop_invariant j > 0 ==> (\forall int i; originalBegin <= i <= begin + indexL[startLeft + j - 1]; array[i] <= pivot);
      //@ loop_invariant (\forall int i; last - indexR[startRight] < i < originalEnd; pivot <= array[i]);
      //@ loop_invariant j > 0 ==> (\forall int i; last - indexR[startRight + j - 1] <= i < originalEnd; pivot <= array[i]);
      //@ loop_invariant (\forall int i; startLeft + j <= i < startLeft + numLeft; pivot <= array[begin + indexL[i]]);
      //@ loop_invariant (\forall int i; startRight + j <= i < startRight + numRight; array[last - indexR[i]] <= pivot);
      //@ loop_invariant permutation(array, \old(array), begin, last + 1);
      //@ loop_modifies array[begin + indexL[startLeft] .. begin + indexL[startLeft + num - 1]], array[last - indexR[startRight + num - 1] .. last - indexR[startRight]], j;
      //@ loop_decreases num - j;
      for (int j = 0; j < num; j++) {
        swap(array, begin + indexL[startLeft + j], last - indexR[startRight + j]);
        j++;
      }
    }
    numLeft -= num;
    numRight -= num;
    startLeft += num;
    startRight += num;
    begin += (numLeft == 0) ? shiftL : 0;
    last -= (numRight == 0) ? shiftR : 0;
    if (numLeft != 0) {
      int lowerI = startLeft + numLeft - 1;
      int upper = last - begin;
      //@ loop_invariant 0 <= startLeft && startLeft - 1 <= lowerI && lowerI < startLeft + numLeft && startLeft + numLeft <= BLOCKSIZE;
      //@ loop_invariant upper == last - begin - (startLeft + numLeft - 1 - lowerI);
      //@ loop_invariant (\forall int i; lowerI < i < startLeft + numLeft - 1; indexL[i] == upper + (i - lowerI));
      //@ loop_invariant (\forall int i; begin <= i < begin + indexL[startLeft]; array[i] <= pivot);
      //@ loop_invariant (\forall int i; begin + upper < i <= last; pivot <= array[i]);
      //@ loop_modifies lowerI, upper;
      //@ loop_decreases lowerI + 1;
      while (lowerI >= startLeft && indexL[lowerI] == upper) {
        upper--;
        lowerI--;
      }
      //@ loop_invariant 0 <= startLeft && startLeft - 1 <= lowerI && lowerI < startLeft + numLeft && startLeft + numLeft <= BLOCKSIZE;
      //@ loop_invariant upper == last - begin - (startLeft + numLeft - 1 - lowerI);
      //@ loop_invariant (\forall int i; startLeft <= i < lowerI; indexL[i] == indexL[i + 1] - 1);
      //@ loop_invariant (\forall int i; begin + indexL[startLeft] <= i < begin + upper; pivot <= array[i]);
      //@ loop_invariant (\forall int i; begin + upper < i <= last; pivot <= array[i]);
      //@ loop_invariant lowerI >= startLeft ==> indexL[lowerI] == upper || array[begin + upper] <= pivot;
      //@ loop_invariant lowerI < startLeft && upper >= 0 ==> array[begin + upper] <= pivot;
      //@ loop_invariant permutation(array, \old(array), begin, last + 1);
      //@ loop_modifies upper, lowerI, array[begin + indexL[startLeft] .. last];
      //@ loop_decreases lowerI + 1;
      while (lowerI >= startLeft) {
        swap(array, begin + upper, begin + indexL[lowerI]);
        upper--;
        lowerI--;
      }
      swap(array, pivotPosition, begin + upper + 1);
      return begin + upper + 1;
    } else if (numRight != 0) {
      int lowerI = startRight + numRight - 1;
      int upper = last - begin;
      //@ loop_invariant 0 <= startRight && startRight - 1 <= lowerI && lowerI < startRight + numRight && startRight + numRight <= BLOCKSIZE;
      //@ loop_invariant upper == last - begin - (startRight + numRight - 1 - lowerI);
      //@ loop_invariant (\forall int i; lowerI < i < startRight + numRight - 1; indexR[i] == upper + (i - lowerI));
      //@ loop_invariant (\forall int i; last - indexR[startRight] < i <= last; pivot <= array[i]);
      //@ loop_invariant (\forall int i; begin <= i < last - upper; array[i] <= pivot);
      //@ loop_modifies lowerI, upper;
      //@ loop_decreases lowerI + 1;
      while (lowerI >= startRight && indexR[lowerI] == upper) {
        upper--;
        lowerI--;
      }
      //@ loop_invariant 0 <= startRight && startRight - 1 <= lowerI && lowerI < startRight + numRight && startRight + numRight <= BLOCKSIZE;
      //@ loop_invariant upper == last - begin - (startRight + numRight - 1 - lowerI);
      //@ loop_invariant (\forall int i; startRight <= i < lowerI; indexR[i] == indexR[i + 1] - 1);
      //@ loop_invariant (\forall int i; begin <= i < last - upper; array[i] <= pivot);
      //@ loop_invariant (\forall int i; last - upper < i <= last - indexR[startRight]; array[i] <= pivot);
      //@ loop_invariant lowerI >= startRight ==> indexR[lowerI] == upper || pivot <= array[last - upper];
      //@ loop_invariant lowerI < startRight && upper >= 0 ==> pivot <= array[last - upper];
      //@ loop_invariant permutation(array, \old(array), begin, last + 1);
      //@ loop_modifies upper, lowerI, array[begin .. last - indexR[startRight]];
      //@ loop_decreases lowerI + 1;
      while (lowerI >= startRight) {
        swap(array, last - upper, last - indexR[lowerI]);
        upper--;
        lowerI--;
      }
      swap(array, pivotPosition, last - upper);
      return last - upper;
    } else {
      swap(array, pivotPosition, begin);
      return begin;
    }
  }
  
  public static void quickSortVerf( 
  int[] array, int originalBegin, int originalEnd) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= originalBegin && originalBegin < originalEnd && originalEnd <= array.length);
    }
    int old84 = array.length;
    int[] old85 = array;
    try {
      int $$param112 = 0;
      int sum_32 = 0;
      int sum_33 = 0;
      int[] $$param113 = null;
      int $$param114 = 0;
      int $$param115 = 0;
      int[] $$param116 = null;
      int $$param117 = 0;
      int $$param118 = 0;
      int begin = originalBegin;
      int end = originalEnd;
      $$param112 = end - begin;
      int depthLimit = 2 * log2Symb($$param112) + 3;
       
      int[] stack = new int[STACK_SIZE];
       
      int[] depthStack = new int[DEPTH_STACK_SIZE];
      int stackPointer = 0;
      int depthPointer = 0;
      int depth = 0;
      assert !false : "Illegal assignment to stack[stackPointer] = begin conflicting with assignables array[originalBegin .. originalEnd - 1]";
      stack[stackPointer] = begin;
      assert !false : "Illegal assignment to stack[stackPointer + 1] = end conflicting with assignables array[originalBegin .. originalEnd - 1]";
      stack[stackPointer + 1] = end;
      stackPointer += 2;
      assert !false : "Illegal assignment to depthStack[depthPointer] = depth conflicting with assignables array[originalBegin .. originalEnd - 1]";
      depthStack[depthPointer] = depth;
      depthPointer++;
      sum_32 = 0;
      for (int quantVar215i = originalBegin; originalBegin <= quantVar215i && originalEnd - 1 >= quantVar215i; ++quantVar215i) {
        sum_33 = 0;
        for (int quantVar216j = quantVar215i; quantVar215i <= quantVar216j && originalEnd - 1 >= quantVar216j; ++quantVar216j) {
          sum_33 += array[quantVar216j] < array[quantVar215i] ? 1 : 0;
        }
        sum_32 += (sum_33);
      }
      int[] old86 = new int[14];
      int[] old87 = array;
      int old88 = originalEnd - 1;
      int old89 = originalBegin;
      int[] old90 = new int[14];
      int[] old91 = stack;
      int old92 = STACK_SIZE - 1;
      int old93 = 0;
      int old94 = originalEnd - 1;
      int old95 = originalBegin;
      int[] old96 = new int[14];
      for (int i = originalBegin; i <= originalEnd - 1; ++i) {
        for (int k = originalBegin; k <= originalEnd - 1; ++k) {
          try {
            old86[k % 14] = array[k];
          } catch (java.lang.RuntimeException e) {
          }
        }
      }
      for (int i = originalBegin; i <= originalEnd - 1; ++i) {
        for (int k = originalBegin; k <= originalEnd - 1; ++k) {
          try {
            old90[k % 14] = array[k];
          } catch (java.lang.RuntimeException e) {
          }
        }
      }
      for (int i = originalBegin; i <= originalEnd - 1; ++i) {
        for (int k = originalBegin; k <= originalEnd - 1; ++k) {
          try {
            old96[k % 14] = array[k];
          } catch (java.lang.RuntimeException e) {
          }
        }
      }
      {
        int min_0 = 2147483647;
        int quantVar201i = CProver.nondetInt();
        int max_1 = -2147483648;
        int quantVar203i = CProver.nondetInt();
        int quantVar205i = CProver.nondetInt();
        int sum_28 = 0;
        int sum_29 = 0;
        {
          assert 0 <= stackPointer;
          assert stackPointer < STACK_SIZE;
        }
        {
          assert 0 <= depth;
          assert depth <= depthLimit;
        }
        {
          assert originalBegin <= begin;
          assert begin <= end;
          assert end <= originalEnd;
        }
        min_0 = 2147483647;
        for (int quantVar202j = 0; 0 <= quantVar202j && stackPointer - 1 >= quantVar202j; ++quantVar202j) {
          min_0 = stack[quantVar202j] <= min_0 ? stack[quantVar202j] : min_0;
        }
        assert !(originalBegin <= quantVar201i && quantVar201i < min(begin, (min_0))) || array[quantVar201i] <= array[quantVar201i + 1];
        max_1 = -2147483648;
        for (int quantVar204j = 0; 0 <= quantVar204j && stackPointer - 1 >= quantVar204j; ++quantVar204j) {
          max_1 = stack[quantVar204j] >= max_1 ? stack[quantVar204j] : max_1;
        }
        assert !(max(end, (max_1)) <= quantVar203i && quantVar203i < originalEnd) || array[quantVar203i] <= array[quantVar203i + 1];
        if (!!(originalBegin <= quantVar205i && quantVar205i < originalEnd)) {
          sum_28 = 0;
          for (int quantVar206k = originalBegin; originalBegin <= quantVar206k && originalEnd - 1 >= quantVar206k; ++quantVar206k) {
            sum_28 += array[quantVar205i] == array[quantVar206k] ? 1 : 0;
          }
          sum_29 = 0;
          for (int quantVar207k = originalBegin; originalBegin <= quantVar207k && originalEnd - 1 >= quantVar207k; ++quantVar207k) {
            sum_29 += array[quantVar205i] == old86[quantVar207k % 14] ? 1 : 0;
          }
        }
        assert !(originalBegin <= quantVar205i && quantVar205i < originalEnd) || (sum_28) == (sum_29);
      }
      assert !(true && (old87 != array || originalEnd - 1 > old88 || originalBegin < old89)) : "Illegal assignment to array[originalBegin .. originalEnd - 1] conflicting with assiganbles + array[originalBegin .. originalEnd - 1]";
      depth = CProver.nondetInt();
      stackPointer = CProver.nondetInt();
      if (array != null) {
        for (int __tmpVar__0 = originalBegin; __tmpVar__0 <= originalEnd - 1; ++__tmpVar__0) {
          array[__tmpVar__0] = CProver.nondetInt();
        }
      }
      if (stack != null) {
        for (int __tmpVar__0 = 0; __tmpVar__0 <= STACK_SIZE - 1; ++__tmpVar__0) {
          stack[__tmpVar__0] = CProver.nondetInt();
        }
      }
      begin = CProver.nondetInt();
      end = CProver.nondetInt();
      depthPointer = CProver.nondetInt();
      int oldDecreasesClauseValue12 = (sum_32);
      {
        int min_2 = 2147483647;
        boolean b_63 = true;
        int max_3 = -2147483648;
        boolean b_64 = true;
        boolean b_65 = true;
        int sum_30 = 0;
        int sum_31 = 0;
        CProver.assume(0 <= stackPointer && stackPointer < STACK_SIZE);
        CProver.assume(0 <= depth && depth <= depthLimit);
        CProver.assume(originalBegin <= begin && begin <= end && end <= originalEnd);
        min_2 = 2147483647;
        for (int quantVar209j = 0; 0 <= quantVar209j && stackPointer - 1 >= quantVar209j; ++quantVar209j) {
          min_2 = stack[quantVar209j] <= min_2 ? stack[quantVar209j] : min_2;
        }
        b_63 = false;
        for (int quantVar208i = originalBegin; originalBegin <= quantVar208i && min(begin, (min_2)) - 1 >= quantVar208i; ++quantVar208i) {
          b_63 = b_63 && array[quantVar208i] <= array[quantVar208i + 1];
        }
        CProver.assume((b_63));
        max_3 = -2147483648;
        for (int quantVar211j = 0; 0 <= quantVar211j && stackPointer - 1 >= quantVar211j; ++quantVar211j) {
          max_3 = stack[quantVar211j] >= max_3 ? stack[quantVar211j] : max_3;
        }
        b_64 = false;
        for (int quantVar210i = max(end, (max_3)); max(end, (max_3)) <= quantVar210i && originalEnd - 1 >= quantVar210i; ++quantVar210i) {
          b_64 = b_64 && array[quantVar210i] <= array[quantVar210i + 1];
        }
        CProver.assume((b_64));
        b_65 = false;
        for (int quantVar212i = originalBegin; originalBegin <= quantVar212i && originalEnd - 1 >= quantVar212i; ++quantVar212i) {
          sum_30 = 0;
          for (int quantVar213k = originalBegin; originalBegin <= quantVar213k && originalEnd - 1 >= quantVar213k; ++quantVar213k) {
            sum_30 += array[quantVar212i] == array[quantVar213k] ? 1 : 0;
          }
          sum_31 = 0;
          for (int quantVar214k = originalBegin; originalBegin <= quantVar214k && originalEnd - 1 >= quantVar214k; ++quantVar214k) {
            sum_31 += array[quantVar212i] == old90[quantVar214k % 14] ? 1 : 0;
          }
          b_65 = b_65 && (sum_30) == (sum_31);
        }
        CProver.assume((b_65));
      }
      if (stackPointer > 0) {
        if (depth < depthLimit && (end - begin > IS_THRESH)) {
          $$param113 = array;
          $$param114 = begin;
          $$param115 = end;
          assert !(true && (old91 != $$param113 || $$param115 - 1 > old92 || $$param114 < old93) && ($$param113 != $$param113 || $$param115 - 1 > old94 || $$param114 < old95)) : "Illegal assignment to array[begin .. end - 1] conflicting with assignables stack[0 .. STACK_SIZE - 1], array[originalBegin .. originalEnd - 1], stackPointer, depth";
          int pivot = partitionSymb($$param113, $$param114, $$param115);
          if (pivot - begin > end - pivot - 1) {
            assert !false : "Illegal assignment to stack[stackPointer] = begin conflicting with assignables stack[0 .. STACK_SIZE - 1], array[originalBegin .. originalEnd - 1], stackPointer, depth";
            stack[stackPointer] = begin;
            assert !false : "Illegal assignment to stack[stackPointer + 1] = pivot conflicting with assignables stack[0 .. STACK_SIZE - 1], array[originalBegin .. originalEnd - 1], stackPointer, depth";
            stack[stackPointer + 1] = pivot;
            assert !false : "Illegal assignment to begin = pivot + 1 conflicting with assignables stack[0 .. STACK_SIZE - 1], array[originalBegin .. originalEnd - 1], stackPointer, depth";
            begin = pivot + 1;
          } else {
            assert !false : "Illegal assignment to stack[stackPointer] = pivot + 1 conflicting with assignables stack[0 .. STACK_SIZE - 1], array[originalBegin .. originalEnd - 1], stackPointer, depth";
            stack[stackPointer] = pivot + 1;
            assert !false : "Illegal assignment to stack[stackPointer + 1] = end conflicting with assignables stack[0 .. STACK_SIZE - 1], array[originalBegin .. originalEnd - 1], stackPointer, depth";
            stack[stackPointer + 1] = end;
            assert !false : "Illegal assignment to end = pivot conflicting with assignables stack[0 .. STACK_SIZE - 1], array[originalBegin .. originalEnd - 1], stackPointer, depth";
            end = pivot;
          }
          stackPointer += 2;
          depth++;
          assert !false : "Illegal assignment to depthStack[depthPointer] = depth conflicting with assignables stack[0 .. STACK_SIZE - 1], array[originalBegin .. originalEnd - 1], stackPointer, depth";
          depthStack[depthPointer] = depth;
          depthPointer++;
        } else {
          $$param116 = array;
          $$param117 = begin;
          $$param118 = end;
          assert !(true && (old91 != $$param116 || $$param118 - 1 > old92 || $$param117 < old93) && ($$param116 != $$param116 || $$param118 - 1 > old94 || $$param117 < old95)) : "Illegal assignment to array[begin .. end - 1] conflicting with assignables stack[0 .. STACK_SIZE - 1], array[originalBegin .. originalEnd - 1], stackPointer, depth";
          insertionSortSymb($$param116, $$param117, $$param118);
          stackPointer -= 2;
          assert !false : "Illegal assignment to begin = stack[stackPointer] conflicting with assignables stack[0 .. STACK_SIZE - 1], array[originalBegin .. originalEnd - 1], stackPointer, depth";
          begin = stack[stackPointer];
          assert !false : "Illegal assignment to end = stack[stackPointer + 1] conflicting with assignables stack[0 .. STACK_SIZE - 1], array[originalBegin .. originalEnd - 1], stackPointer, depth";
          end = stack[stackPointer + 1];
          depthPointer--;
          assert !false : "Illegal assignment to depth = depthStack[depthPointer] conflicting with assignables stack[0 .. STACK_SIZE - 1], array[originalBegin .. originalEnd - 1], stackPointer, depth";
          depth = depthStack[depthPointer];
        }
        {
          int min_4 = 2147483647;
          int quantVar217i = CProver.nondetInt();
          int max_5 = -2147483648;
          int quantVar219i = CProver.nondetInt();
          int quantVar221i = CProver.nondetInt();
          int sum_34 = 0;
          int sum_35 = 0;
          {
            assert 0 <= stackPointer;
            assert stackPointer < STACK_SIZE;
          }
          {
            assert 0 <= depth;
            assert depth <= depthLimit;
          }
          {
            assert originalBegin <= begin;
            assert begin <= end;
            assert end <= originalEnd;
          }
          min_4 = 2147483647;
          for (int quantVar218j = 0; 0 <= quantVar218j && stackPointer - 1 >= quantVar218j; ++quantVar218j) {
            min_4 = stack[quantVar218j] <= min_4 ? stack[quantVar218j] : min_4;
          }
          assert !(originalBegin <= quantVar217i && quantVar217i < min(begin, (min_4))) || array[quantVar217i] <= array[quantVar217i + 1];
          max_5 = -2147483648;
          for (int quantVar220j = 0; 0 <= quantVar220j && stackPointer - 1 >= quantVar220j; ++quantVar220j) {
            max_5 = stack[quantVar220j] >= max_5 ? stack[quantVar220j] : max_5;
          }
          assert !(max(end, (max_5)) <= quantVar219i && quantVar219i < originalEnd) || array[quantVar219i] <= array[quantVar219i + 1];
          if (!!(originalBegin <= quantVar221i && quantVar221i < originalEnd)) {
            sum_34 = 0;
            for (int quantVar222k = originalBegin; originalBegin <= quantVar222k && originalEnd - 1 >= quantVar222k; ++quantVar222k) {
              sum_34 += array[quantVar221i] == array[quantVar222k] ? 1 : 0;
            }
            sum_35 = 0;
            for (int quantVar223k = originalBegin; originalBegin <= quantVar223k && originalEnd - 1 >= quantVar223k; ++quantVar223k) {
              sum_35 += array[quantVar221i] == old96[quantVar223k % 14] ? 1 : 0;
            }
          }
          assert !(originalBegin <= quantVar221i && quantVar221i < originalEnd) || (sum_34) == (sum_35);
        }
        {
          assert (sum_32) >= 0;
          assert (sum_32) < oldDecreasesClauseValue12;
        }
        CProver.assume(false);
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old84;
    }
    {
      int quantVar200i = CProver.nondetInt();
      assert !(originalBegin <= quantVar200i && quantVar200i < originalEnd - 1) || array[quantVar200i] <= array[quantVar200i + 1];
    }
    {
      int[] $$param108 = null;
      int[] $$param109 = null;
      int $$param110 = 0;
      int $$param111 = 0;
      $$param108 = array;
      $$param109 = old85;
      $$param110 = originalBegin;
      $$param111 = originalEnd;
      assert permutationSymb($$param108, $$param109, $$param110, $$param111);
    }
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= originalBegin && originalBegin < originalEnd && originalEnd <= array.length; 
      ensures array.length == \old(array.length); 
      ensures (\forall int i; originalBegin <= i < originalEnd - 1; array[i] <= array[i + 1]); 
      ensures permutation(array, \old(array), originalBegin, originalEnd); 
      assignable array[originalBegin .. originalEnd - 1]; 
   */

  public static void quickSort( 
  int[] array, int originalBegin, int originalEnd) {
    int begin = originalBegin;
    int end = originalEnd;
    int depthLimit = 2 * log2(end - begin) + 3;
     
    int[] stack = new int[STACK_SIZE];
     
    int[] depthStack = new int[DEPTH_STACK_SIZE];
    int stackPointer = 0;
    int depthPointer = 0;
    int depth = 0;
    stack[stackPointer] = begin;
    stack[stackPointer + 1] = end;
    stackPointer += 2;
    depthStack[depthPointer] = depth;
    depthPointer++;
    //@ loop_invariant 0 <= stackPointer && stackPointer < STACK_SIZE;
    //@ loop_invariant 0 <= depth && depth <= depthLimit;
    //@ loop_invariant originalBegin <= begin && begin <= end && end <= originalEnd;
    //@ loop_invariant (\forall int i; originalBegin <= i < min(begin, (\min int j; 0 <= j < stackPointer; stack[j])); array[i] <= array[i + 1]);
    //@ loop_invariant (\forall int i; max(end, (\max int j; 0 <= j < stackPointer; stack[j])) <= i < originalEnd; array[i] <= array[i + 1]);
    //@ loop_invariant (\forall int i; originalBegin <= i < originalEnd; (\num_of int k; originalBegin <= k < originalEnd; array[i] == array[k]) == (\num_of int k; originalBegin <= k < originalEnd; array[i] == \old(array[k])));
    //@ loop_modifies stackPointer, depth, stack[0 .. STACK_SIZE - 1], array[originalBegin .. originalEnd - 1];
    //@ loop_decreases (\sum int i; originalBegin <= i < originalEnd; (\num_of int j; i <= j < originalEnd; array[j] < array[i]));
    while (stackPointer > 0) {
      if (depth < depthLimit && (end - begin > IS_THRESH)) {
        int pivot = partition(array, begin, end);
        if (pivot - begin > end - pivot - 1) {
          stack[stackPointer] = begin;
          stack[stackPointer + 1] = pivot;
          begin = pivot + 1;
        } else {
          stack[stackPointer] = pivot + 1;
          stack[stackPointer + 1] = end;
          end = pivot;
        }
        stackPointer += 2;
        depth++;
        depthStack[depthPointer] = depth;
        depthPointer++;
      } else {
        insertionSort(array, begin, end);
        stackPointer -= 2;
        begin = stack[stackPointer];
        end = stack[stackPointer + 1];
        depthPointer--;
        depth = depthStack[depthPointer];
      }
    }
  }
  
  public static void quickSortRecVerf( 
  int[] array, int begin, int end) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= begin && begin < end && end <= array.length);
    }
    int old97 = array.length;
    int[] old98 = array;
    int[] old99 = array;
    int old100 = end - 1;
    int old101 = begin;
    try {
      int $$param123 = 0;
      int[] $$param124 = null;
      int $$param125 = 0;
      int $$param126 = 0;
      int $$param127 = 0;
      int $$param128 = 0;
      int depth = 0;
      $$param123 = end - begin;
      int depthLimit = 2 * log2Symb($$param123) + 3;
      $$param124 = array;
      $$param125 = begin;
      $$param126 = end;
      $$param127 = depth;
      $$param128 = depthLimit;
      assert !(true && (old99 != $$param124 || $$param126 - 1 > old100 || $$param125 < old101)) : "Illegal assignment to array[begin .. end - 1] conflicting with assignables array[begin .. end - 1]";
      quickSortRecImplSymb($$param124, $$param125, $$param126, $$param127, $$param128);
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old97;
    }
    {
      int quantVar224i = CProver.nondetInt();
      assert !(begin <= quantVar224i && quantVar224i < end - 1) || array[quantVar224i] <= array[quantVar224i + 1];
    }
    {
      int[] $$param119 = null;
      int[] $$param120 = null;
      int $$param121 = 0;
      int $$param122 = 0;
      $$param119 = array;
      $$param120 = old98;
      $$param121 = begin;
      $$param122 = end;
      assert permutationSymb($$param119, $$param120, $$param121, $$param122);
    }
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= begin && begin < end && end <= array.length; 
      ensures array.length == \old(array.length); 
      ensures (\forall int i; begin <= i < end - 1; array[i] <= array[i + 1]); 
      ensures permutation(array, \old(array), begin, end); 
      assignable array[begin .. end - 1]; 
   */

  public static void quickSortRec( 
  int[] array, int begin, int end) {
    int depth = 0;
    int depthLimit = 2 * log2(end - begin) + 3;
    quickSortRecImpl(array, begin, end, depth, depthLimit);
  }
  
  public static void quickSortRecImplVerf( 
  int[] array, int begin, int end, int depth, int depthLimit) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= begin && begin <= end && end <= array.length);
    }
    {
      CProver.assume(0 <= depth && depth <= depthLimit && depthLimit < Integer.MAX_VALUE);
    }
    int old102 = array.length;
    int[] old103 = array;
    int[] old104 = array;
    int old105 = end - 1;
    int old106 = begin;
    try {
      int[] $$param133 = null;
      int $$param134 = 0;
      int $$param135 = 0;
      int[] $$param136 = null;
      int $$param137 = 0;
      int $$param138 = 0;
      int[] $$param139 = null;
      int $$param140 = 0;
      int $$param141 = 0;
      int $$param142 = 0;
      int $$param143 = 0;
      int[] $$param144 = null;
      int $$param145 = 0;
      int $$param146 = 0;
      int $$param147 = 0;
      int $$param148 = 0;
      if (end - begin <= IS_THRESH || depth >= depthLimit) {
        $$param133 = array;
        $$param134 = begin;
        $$param135 = end;
        assert !(true && (old104 != $$param133 || $$param135 - 1 > old105 || $$param134 < old106)) : "Illegal assignment to array[begin .. end - 1] conflicting with assignables array[begin .. end - 1]";
        insertionSortSymb($$param133, $$param134, $$param135);
        {
          throw new BlockQuickSort.ReturnException();
        }
      }
      $$param136 = array;
      $$param137 = begin;
      $$param138 = end;
      assert !(true && (old104 != $$param136 || $$param138 - 1 > old105 || $$param137 < old106)) : "Illegal assignment to array[begin .. end - 1] conflicting with assignables array[begin .. end - 1]";
      int pivot = partitionSymb($$param136, $$param137, $$param138);
      $$param139 = array;
      $$param140 = begin;
      $$param141 = pivot;
      $$param142 = depth + 1;
      $$param143 = depthLimit;
      assert !(true && (old104 != $$param139 || $$param141 - 1 > old105 || $$param140 < old106)) : "Illegal assignment to array[begin .. end - 1] conflicting with assignables array[begin .. end - 1]";
      quickSortRecImplSymb($$param139, $$param140, $$param141, $$param142, $$param143);
      $$param144 = array;
      $$param145 = pivot;
      $$param146 = end;
      $$param147 = depth + 1;
      $$param148 = depthLimit;
      assert !(true && (old104 != $$param144 || $$param146 - 1 > old105 || $$param145 < old106)) : "Illegal assignment to array[begin .. end - 1] conflicting with assignables array[begin .. end - 1]";
      quickSortRecImplSymb($$param144, $$param145, $$param146, $$param147, $$param148);
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old102;
    }
    {
      int quantVar225i = CProver.nondetInt();
      assert !(begin <= quantVar225i && quantVar225i < end - 1) || array[quantVar225i] <= array[quantVar225i + 1];
    }
    {
      int[] $$param129 = null;
      int[] $$param130 = null;
      int $$param131 = 0;
      int $$param132 = 0;
      $$param129 = array;
      $$param130 = old103;
      $$param131 = begin;
      $$param132 = end;
      assert permutationSymb($$param129, $$param130, $$param131, $$param132);
    }
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= begin && begin <= end && end <= array.length; 
      requires 0 <= depth && depth <= depthLimit && depthLimit < Integer.MAX_VALUE; 
      ensures array.length == \old(array.length); 
      ensures (\forall int i; begin <= i < end - 1; array[i] <= array[i + 1]); 
      ensures permutation(array, \old(array), begin, end); 
      assignable array[begin .. end - 1]; 
   */

  public static void quickSortRecImpl( 
  int[] array, int begin, int end, int depth, int depthLimit) {
    if (end - begin <= IS_THRESH || depth >= depthLimit) {
      insertionSort(array, begin, end);
      return;
    }
    int pivot = partition(array, begin, end);
    quickSortRecImpl(array, begin, pivot, depth + 1, depthLimit);
    quickSortRecImpl(array, pivot, end, depth + 1, depthLimit);
  }
  
  public static void insertionSortVerf( 
  int[] array, int begin, int end) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= begin && begin <= end && end <= array.length);
    }
    int old107 = array.length;
    int[] old108 = array;
    int[] old109 = array;
    int old110 = end - 1;
    int old111 = begin;
    try {
      int[] $$param153 = null;
      int $$param154 = 0;
      int $$param155 = 0;
      for (int i = begin; i < end; ) {
        int j = i;
        while (j > begin && array[j - 1] > array[j]) {
          $$param153 = array;
          $$param154 = j;
          $$param155 = j - 1;
          assert !(true && (old109 != $$param153 || $$param154 > old110 || $$param154 < old111)) : "Illegal assignment to array[i] conflicting with assignables array[begin .. end - 1]";
          assert !(true && (old109 != $$param153 || $$param155 > old110 || $$param155 < old111)) : "Illegal assignment to array[j] conflicting with assignables array[begin .. end - 1]";
          swapSymb($$param153, $$param154, $$param155);
          j--;
        }
        i++;
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old107;
    }
    {
      int quantVar226i = CProver.nondetInt();
      assert !(begin <= quantVar226i && quantVar226i < end - 1) || array[quantVar226i] <= array[quantVar226i + 1];
    }
    {
      int[] $$param149 = null;
      int[] $$param150 = null;
      int $$param151 = 0;
      int $$param152 = 0;
      $$param149 = array;
      $$param150 = old108;
      $$param151 = begin;
      $$param152 = end;
      assert permutationSymb($$param149, $$param150, $$param151, $$param152);
    }
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= begin && begin <= end && end <= array.length; 
      ensures array.length == \old(array.length); 
      ensures (\forall int i; begin <= i < end - 1; array[i] <= array[i + 1]); 
      ensures permutation(array, \old(array), begin, end); 
      assignable array[begin .. end - 1]; 
   */

  public static void insertionSort( 
  int[] array, int begin, int end) {
    for (int i = begin; i < end; i++) {
      int j = i;
      while (j > begin && array[j - 1] > array[j]) {
        swap(array, j, j - 1);
        j--;
      }
    }
  }
  
  public static void swapVerf( 
  int[] array, int i, int j) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= i && i < array.length);
    }
    {
      CProver.assume(0 <= j && j < array.length);
    }
    int old112 = array.length;
    int old113 = array[j];
    int old114 = array[i];
    int[] old115 = array;
    int old116 = i;
    int old117 = j;
    try {
      int temp = array[i];
      assert !(true && (old115 != array || i > old116 || i < old116) && (array != array || i > old117 || i < old117)) : "Illegal assignment to array[i] = array[j] conflicting with assignables array[i], array[j]";
      array[i] = array[j];
      assert !(true && (old115 != array || j > old116 || j < old116) && (array != array || j > old117 || j < old117)) : "Illegal assignment to array[j] = temp conflicting with assignables array[i], array[j]";
      array[j] = temp;
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old112;
    }
    {
      {
        assert array[i] == old113;
        assert array[j] == old114;
      }
    }
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= i < array.length; 
      requires 0 <= j < array.length; 
      ensures array.length == \old(array.length); 
      ensures array[i] == \old(array[j]) && array[j] == \old(array[i]); 
      assignable array[i], array[j]; 
   */

  public static void swap( 
  int[] array, int i, int j) {
    int temp = array[i];
    array[i] = array[j];
    array[j] = temp;
  }
  
  public static void sortPairVerf(int i1, int i2,  
  int[] array) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= i1 && i1 < array.length);
    }
    {
      CProver.assume(0 <= i2 && i2 < array.length);
    }
    int old118 = array.length;
    int old119 = array[i1];
    int old120 = array[i2];
    int old121 = array[i1];
    int old122 = array[i2];
    int old123 = array[i2];
    int old124 = array[i1];
    int[] old125 = array;
    int old126 = i1;
    int old127 = i2;
    try {
      int[] $$param156 = null;
      int $$param157 = 0;
      int $$param158 = 0;
      if (array[i1] > array[i2]) {
        $$param156 = array;
        $$param157 = i1;
        $$param158 = i2;
        assert !(true && (old125 != $$param156 || $$param157 > old126 || $$param157 < old126) && ($$param156 != $$param156 || $$param157 > old127 || $$param157 < old127)) : "Illegal assignment to array[i] conflicting with assignables array[i1], array[i2]";
        assert !(true && (old125 != $$param156 || $$param158 > old126 || $$param158 < old126) && ($$param156 != $$param156 || $$param158 > old127 || $$param158 < old127)) : "Illegal assignment to array[j] conflicting with assignables array[i1], array[i2]";
        swapSymb($$param156, $$param157, $$param158);
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old118;
    }
    {
      assert (old119 <= old120) ? (array[i1] == old121 && array[i2] == old122) : (array[i1] == old123 && array[i2] == old124);
    }
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= i1 && i1 < array.length; 
      requires 0 <= i2 && i2 < array.length; 
      ensures array.length == \old(array.length); 
      ensures (\old(array[i1]) <= \old(array[i2])) ? (array[i1] == \old(array[i1]) && array[i2] == \old(array[i2])) : (array[i1] == \old(array[i2]) && array[i2] == \old(array[i1])); 
      assignable array[i1], array[i2]; 
   */

  public static void sortPair(int i1, int i2,  
  int[] array) {
    if (array[i1] > array[i2]) {
      swap(array, i1, i2);
    }
  }
  
  public static int medianOf3Verf( 
  int[] array, int begin, int end) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= begin && begin < end && end <= array.length);
    }
    {
      CProver.assume(end - begin >= 3);
    }
    int old128 = array.length;
    int[] old129 = array;
    int[] old130 = array;
    int old131 = begin;
    int old132 = begin + ((end - begin) / 2);
    int old133 = end - 1;
    int returnVar = 0;
    try {
      int $$param163 = 0;
      int $$param164 = 0;
      int[] $$param165 = null;
      int $$param166 = 0;
      int $$param167 = 0;
      int[] $$param168 = null;
      int $$param169 = 0;
      int $$param170 = 0;
      int[] $$param171 = null;
      int mid = begin + ((end - begin) / 2);
      $$param163 = begin;
      $$param164 = mid;
      $$param165 = array;
      assert !(true && (old130 != $$param165 || $$param163 > old131 || $$param163 < old131) && ($$param165 != $$param165 || $$param163 > old132 || $$param163 < old132) && ($$param165 != $$param165 || $$param163 > old133 || $$param163 < old133)) : "Illegal assignment to array[i1] conflicting with assignables array[begin], array[begin + ((end - begin) / 2)], array[end - 1]";
      assert !(true && (old130 != $$param165 || $$param164 > old131 || $$param164 < old131) && ($$param165 != $$param165 || $$param164 > old132 || $$param164 < old132) && ($$param165 != $$param165 || $$param164 > old133 || $$param164 < old133)) : "Illegal assignment to array[i2] conflicting with assignables array[begin], array[begin + ((end - begin) / 2)], array[end - 1]";
      sortPairSymb($$param163, $$param164, $$param165);
      $$param166 = mid;
      $$param167 = end - 1;
      $$param168 = array;
      assert !(true && (old130 != $$param168 || $$param166 > old131 || $$param166 < old131) && ($$param168 != $$param168 || $$param166 > old132 || $$param166 < old132) && ($$param168 != $$param168 || $$param166 > old133 || $$param166 < old133)) : "Illegal assignment to array[i1] conflicting with assignables array[begin], array[begin + ((end - begin) / 2)], array[end - 1]";
      assert !(true && (old130 != $$param168 || $$param167 > old131 || $$param167 < old131) && ($$param168 != $$param168 || $$param167 > old132 || $$param167 < old132) && ($$param168 != $$param168 || $$param167 > old133 || $$param167 < old133)) : "Illegal assignment to array[i2] conflicting with assignables array[begin], array[begin + ((end - begin) / 2)], array[end - 1]";
      sortPairSymb($$param166, $$param167, $$param168);
      $$param169 = begin;
      $$param170 = mid;
      $$param171 = array;
      assert !(true && (old130 != $$param171 || $$param169 > old131 || $$param169 < old131) && ($$param171 != $$param171 || $$param169 > old132 || $$param169 < old132) && ($$param171 != $$param171 || $$param169 > old133 || $$param169 < old133)) : "Illegal assignment to array[i1] conflicting with assignables array[begin], array[begin + ((end - begin) / 2)], array[end - 1]";
      assert !(true && (old130 != $$param171 || $$param170 > old131 || $$param170 < old131) && ($$param171 != $$param171 || $$param170 > old132 || $$param170 < old132) && ($$param171 != $$param171 || $$param170 > old133 || $$param170 < old133)) : "Illegal assignment to array[i2] conflicting with assignables array[begin], array[begin + ((end - begin) / 2)], array[end - 1]";
      sortPairSymb($$param169, $$param170, $$param171);
      {
        returnVar = mid;
        throw new BlockQuickSort.ReturnException();
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old128;
    }
    {
      assert returnVar == begin + ((end - begin) / 2);
    }
    {
      {
        assert array[begin] <= array[returnVar];
        assert array[returnVar] <= array[end - 1];
      }
    }
    {
      int[] $$param159 = null;
      int[] $$param160 = null;
      int $$param161 = 0;
      int $$param162 = 0;
      $$param159 = array;
      $$param160 = old129;
      $$param161 = begin;
      $$param162 = end;
      assert permutationSymb($$param159, $$param160, $$param161, $$param162);
    }
    return returnVar;
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= begin && begin < end && end <= array.length; 
      requires end - begin >= 3; 
      ensures array.length == \old(array.length); 
      ensures \result == begin + ((end - begin) / 2); 
      ensures array[begin] <= array[\result] && array[\result] <= array[end - 1]; 
      ensures permutation(array, \old(array), begin, end); 
      assignable array[begin], array[begin + ((end - begin) / 2)], array[end - 1]; 
   */

  public static int medianOf3( 
  int[] array, int begin, int end) {
    int mid = begin + ((end - begin) / 2);
    sortPair(begin, mid, array);
    sortPair(mid, end - 1, array);
    sortPair(begin, mid, array);
    return mid;
  }
  
  public static int partitionVerf( 
  int[] array, int begin, int end) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= begin && begin < end && end <= array.length);
    }
    {
      CProver.assume(end - begin >= 3);
    }
    int old134 = array.length;
    int[] old135 = array;
    int[] old136 = array;
    int old137 = end - 1;
    int old138 = begin;
    int returnVar = 0;
    try {
      int[] $$param176 = null;
      int $$param177 = 0;
      int $$param178 = 0;
      int[] $$param179 = null;
      int $$param180 = 0;
      int $$param181 = 0;
      int $$param182 = 0;
      $$param176 = array;
      $$param177 = begin;
      $$param178 = end;
      assert !(true && (old136 != $$param176 || $$param177 > old137 || $$param177 < old138)) : "Illegal assignment to array[begin] conflicting with assignables array[begin .. end - 1]";
      assert !(true && (old136 != $$param176 || $$param177 + (($$param178 - $$param177) / 2) > old137 || $$param177 + (($$param178 - $$param177) / 2) < old138)) : "Illegal assignment to array[begin + ((end - begin) / 2)] conflicting with assignables array[begin .. end - 1]";
      assert !(true && (old136 != $$param176 || $$param178 - 1 > old137 || $$param178 - 1 < old138)) : "Illegal assignment to array[end - 1] conflicting with assignables array[begin .. end - 1]";
      int mid = medianOf3Symb($$param176, $$param177, $$param178);
      $$param179 = array;
      $$param180 = begin + 1;
      $$param181 = end - 1;
      $$param182 = mid;
      assert !(true && (old136 != $$param179 || $$param181 - 1 > old137 || $$param180 < old138)) : "Illegal assignment to array[originalBegin .. originalEnd - 1] conflicting with assignables array[begin .. end - 1]";
      {
        returnVar = hoareBlockPartitionSymb($$param179, $$param180, $$param181, $$param182);
        throw new BlockQuickSort.ReturnException();
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old134;
    }
    {
      {
        assert begin <= returnVar;
        assert returnVar < end;
      }
    }
    {
      int quantVar227i = CProver.nondetInt();
      assert !(begin <= quantVar227i && quantVar227i <= returnVar) || array[quantVar227i] <= array[returnVar];
    }
    {
      int quantVar228i = CProver.nondetInt();
      assert !(returnVar <= quantVar228i && quantVar228i < end) || array[returnVar] <= array[quantVar228i];
    }
    {
      int[] $$param172 = null;
      int[] $$param173 = null;
      int $$param174 = 0;
      int $$param175 = 0;
      $$param172 = array;
      $$param173 = old135;
      $$param174 = begin;
      $$param175 = end;
      assert permutationSymb($$param172, $$param173, $$param174, $$param175);
    }
    return returnVar;
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= begin && begin < end && end <= array.length; 
      requires end - begin >= 3; 
      ensures array.length == \old(array.length); 
      ensures begin <= \result && \result < end; 
      ensures (\forall int i; begin <= i <= \result; array[i] <= array[\result]); 
      ensures (\forall int i; \result <= i < end; array[\result] <= array[i]); 
      ensures permutation(array, \old(array), begin, end); 
      assignable array[begin .. end - 1]; 
   */

  public static int partition( 
  int[] array, int begin, int end) {
    int mid = medianOf3(array, begin, end);
    return hoareBlockPartition(array, begin + 1, end - 1, mid);
  }
  
   
  public static int log2Verf(int n) {
    {
      CProver.assume(n > 0);
    }
    int returnVar = 0;
    try {
      int log2Value = 0;
      while (n > 1) {
        n /= 2;
        log2Value++;
      }
      {
        returnVar = log2Value;
        throw new BlockQuickSort.ReturnException();
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      {
        assert 0 <= returnVar;
        assert (1 << (returnVar - 1)) < n;
        assert n <= (1 << returnVar);
        assert returnVar <= 31;
      }
    }
    return returnVar;
  }
    /*@
    public normal_behavior
      requires n > 0; 
      ensures 0 <= \result && (1 << (\result - 1)) < n && n <= (1 << \result) && \result <= 31; 
   */

   
  public static int log2(int n) {
    int log2Value = 0;
    while (n > 1) {
      n /= 2;
      log2Value++;
    }
    return log2Value;
  }
  
  public static int minVerf(int a, int b) {
    int returnVar = 0;
    try {
      {
        returnVar = a < b ? a : b;
        throw new BlockQuickSort.ReturnException();
      }
    } catch (BlockQuickSort.ReturnException ex) {
    } catch (java.lang.RuntimeException e) {
      CProver.assume(false);
    }
    return returnVar;
  }
    /*@
    public behavior
      signals_only java.lang.RuntimeException; 
   */

  public static int min(int a, int b) {
    return a < b ? a : b;
  }
  
  public static int maxVerf(int a, int b) {
    int returnVar = 0;
    try {
      {
        returnVar = a > b ? a : b;
        throw new BlockQuickSort.ReturnException();
      }
    } catch (BlockQuickSort.ReturnException ex) {
    } catch (java.lang.RuntimeException e) {
      CProver.assume(false);
    }
    return returnVar;
  }
    /*@
    public behavior
      signals_only java.lang.RuntimeException; 
   */

  public static int max(int a, int b) {
    return a > b ? a : b;
  }
  
   
  public static boolean permutationVerf( 
  int[] array1,  
  int[] array2, int begin, int end) {
    {
      CProver.assume(array1 != null);
    }
    {
      CProver.assume(array2 != null);
    }
    {
      CProver.assume(0 <= begin && begin <= end && end <= array1.length);
    }
    {
      CProver.assume(array1.length == array2.length);
    }
    int old139 = array1.length;
    int old140 = array2.length;
    boolean returnVar = true;
    try {
      {
        int i = begin;
        {
          int quantVar235j = CProver.nondetInt();
          int sum_40 = 0;
          int sum_41 = 0;
          {
            assert begin <= i;
            assert i <= end;
          }
          if (!!(begin <= quantVar235j && quantVar235j < i)) {
            sum_40 = 0;
            for (int quantVar236k = begin; begin <= quantVar236k && end - 1 >= quantVar236k; ++quantVar236k) {
              sum_40 += array1[quantVar235j] == array1[quantVar236k] ? 1 : 0;
            }
            sum_41 = 0;
            for (int quantVar237k = begin; begin <= quantVar237k && end - 1 >= quantVar237k; ++quantVar237k) {
              sum_41 += array1[quantVar235j] == array2[quantVar237k] ? 1 : 0;
            }
          }
          assert !(begin <= quantVar235j && quantVar235j < i) || (sum_40) == (sum_41);
        }
        i = CProver.nondetInt();
        int oldDecreasesClauseValue13 = end - i;
        {
          boolean b_67 = true;
          int sum_42 = 0;
          int sum_43 = 0;
          CProver.assume(begin <= i && i <= end);
          b_67 = false;
          for (int quantVar238j = begin; begin <= quantVar238j && i - 1 >= quantVar238j; ++quantVar238j) {
            sum_42 = 0;
            for (int quantVar239k = begin; begin <= quantVar239k && end - 1 >= quantVar239k; ++quantVar239k) {
              sum_42 += array1[quantVar238j] == array1[quantVar239k] ? 1 : 0;
            }
            sum_43 = 0;
            for (int quantVar240k = begin; begin <= quantVar240k && end - 1 >= quantVar240k; ++quantVar240k) {
              sum_43 += array1[quantVar238j] == array2[quantVar240k] ? 1 : 0;
            }
            b_67 = b_67 && (sum_42) == (sum_43);
          }
          CProver.assume((b_67));
        }
        if (i < end) {
          int count1 = 0;
          int count2 = 0;
          {
            int j = begin;
            {
              int sum_44 = 0;
              int sum_45 = 0;
              {
                assert begin <= j;
                assert j <= end;
              }
              sum_44 = 0;
              for (int quantVar241k = begin; begin <= quantVar241k && j - 1 >= quantVar241k; ++quantVar241k) {
                sum_44 += array1[i] == array1[quantVar241k] ? 1 : 0;
              }
              assert count1 == (sum_44);
              sum_45 = 0;
              for (int quantVar242k = begin; begin <= quantVar242k && j - 1 >= quantVar242k; ++quantVar242k) {
                sum_45 += array1[i] == array2[quantVar242k] ? 1 : 0;
              }
              assert count2 == (sum_45);
            }
            j = CProver.nondetInt();
            count2 = CProver.nondetInt();
            count1 = CProver.nondetInt();
            int oldDecreasesClauseValue14 = end - j;
            {
              int sum_46 = 0;
              int sum_47 = 0;
              CProver.assume(begin <= j && j <= end);
              sum_46 = 0;
              for (int quantVar243k = begin; begin <= quantVar243k && j - 1 >= quantVar243k; ++quantVar243k) {
                sum_46 += array1[i] == array1[quantVar243k] ? 1 : 0;
              }
              CProver.assume(count1 == (sum_46));
              sum_47 = 0;
              for (int quantVar244k = begin; begin <= quantVar244k && j - 1 >= quantVar244k; ++quantVar244k) {
                sum_47 += array1[i] == array2[quantVar244k] ? 1 : 0;
              }
              CProver.assume(count2 == (sum_47));
            }
            if (j < end) {
              if (array1[i] == array1[j]) {
                count1++;
              }
              if (array1[i] == array2[j]) {
                count2++;
              }
              j++;
              {
                int sum_48 = 0;
                int sum_49 = 0;
                {
                  assert begin <= j;
                  assert j <= end;
                }
                sum_48 = 0;
                for (int quantVar245k = begin; begin <= quantVar245k && j - 1 >= quantVar245k; ++quantVar245k) {
                  sum_48 += array1[i] == array1[quantVar245k] ? 1 : 0;
                }
                assert count1 == (sum_48);
                sum_49 = 0;
                for (int quantVar246k = begin; begin <= quantVar246k && j - 1 >= quantVar246k; ++quantVar246k) {
                  sum_49 += array1[i] == array2[quantVar246k] ? 1 : 0;
                }
                assert count2 == (sum_49);
              }
              {
                assert end - j >= 0;
                assert end - j < oldDecreasesClauseValue14;
              }
              CProver.assume(false);
            }
          }
          if (count1 != count2) {
            {
              returnVar = false;
              throw new BlockQuickSort.ReturnException();
            }
          }
          i++;
          {
            int quantVar247j = CProver.nondetInt();
            int sum_50 = 0;
            int sum_51 = 0;
            {
              assert begin <= i;
              assert i <= end;
            }
            if (!!(begin <= quantVar247j && quantVar247j < i)) {
              sum_50 = 0;
              for (int quantVar248k = begin; begin <= quantVar248k && end - 1 >= quantVar248k; ++quantVar248k) {
                sum_50 += array1[quantVar247j] == array1[quantVar248k] ? 1 : 0;
              }
              sum_51 = 0;
              for (int quantVar249k = begin; begin <= quantVar249k && end - 1 >= quantVar249k; ++quantVar249k) {
                sum_51 += array1[quantVar247j] == array2[quantVar249k] ? 1 : 0;
              }
            }
            assert !(begin <= quantVar247j && quantVar247j < i) || (sum_50) == (sum_51);
          }
          {
            assert end - i >= 0;
            assert end - i < oldDecreasesClauseValue13;
          }
          CProver.assume(false);
        }
      }
      {
        returnVar = true;
        throw new BlockQuickSort.ReturnException();
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array1.length == old139;
    }
    {
      assert array2.length == old140;
    }
    {
      int quantVar229i = CProver.nondetInt();
      int sum_36 = 0;
      int sum_37 = 0;
      boolean b_66 = false;
      int sum_38 = 0;
      int sum_39 = 0;
      if (!!returnVar) {
        if (!!(begin <= quantVar229i && quantVar229i < end)) {
          sum_36 = 0;
          for (int quantVar230j = begin; begin <= quantVar230j && end - 1 >= quantVar230j; ++quantVar230j) {
            sum_36 += array1[quantVar229i] == array1[quantVar230j] ? 1 : 0;
          }
          sum_37 = 0;
          for (int quantVar231j = begin; begin <= quantVar231j && end - 1 >= quantVar231j; ++quantVar231j) {
            sum_37 += array1[quantVar229i] == array2[quantVar231j] ? 1 : 0;
          }
        }
      }
      if (!returnVar || (!(begin <= quantVar229i && quantVar229i < end) || ((sum_36) == (sum_37)))) {
        b_66 = false;
        for (int quantVar232i = begin; begin <= quantVar232i && end - 1 >= quantVar232i; ++quantVar232i) {
          sum_38 = 0;
          for (int quantVar233j = begin; begin <= quantVar233j && end - 1 >= quantVar233j; ++quantVar233j) {
            sum_38 += array1[quantVar232i] == array1[quantVar233j] ? 1 : 0;
          }
          sum_39 = 0;
          for (int quantVar234j = begin; begin <= quantVar234j && end - 1 >= quantVar234j; ++quantVar234j) {
            sum_39 += array1[quantVar232i] == array2[quantVar234j] ? 1 : 0;
          }
          b_66 = b_66 || !((sum_38) == (sum_39));
        }
      }
      {
        assert !returnVar || (!(begin <= quantVar229i && quantVar229i < end) || ((sum_36) == (sum_37)));
        assert b_66 || returnVar;
      }
    }
    return returnVar;
  }
    /*@
    public normal_behavior
      requires array1 != null; 
      requires array2 != null; 
      requires 0 <= begin && begin <= end && end <= array1.length; 
      requires array1.length == array2.length; 
      ensures array1.length == \old(array1.length); 
      ensures array2.length == \old(array2.length); 
      ensures \result == (\forall int i; begin <= i < end; ((\num_of int j; begin <= j < end; array1[i] == array1[j]) == (\num_of int j; begin <= j < end; array1[i] == array2[j]))); 
   */

   
  public static boolean permutation( 
  int[] array1,  
  int[] array2, int begin, int end) {
    //@ loop_invariant begin <= i <= end;
    //@ loop_invariant (\forall int j; begin <= j < i; (\num_of int k; begin <= k < end; array1[j] == array1[k]) == (\num_of int k; begin <= k < end; array1[j] == array2[k]));
    //@ loop_modifies i;
    //@ loop_decreases end - i;
    for (int i = begin; i < end; i++) {
      int count1 = 0;
      int count2 = 0;
      //@ loop_invariant begin <= j <= end;
      //@ loop_invariant count1 == (\num_of int k; begin <= k < j; array1[i] == array1[k]);
      //@ loop_invariant count2 == (\num_of int k; begin <= k < j; array1[i] == array2[k]);
      //@ loop_modifies j, count1, count2;
      //@ loop_decreases end - j;
      for (int j = begin; j < end; j++) {
        if (array1[i] == array1[j]) {
          count1++;
        }
        if (array1[i] == array2[j]) {
          count2++;
        }
        j++;
      }
      if (count1 != count2) {
        return false;
      }
      i++;
    }
    return true;
  }
  
  public static class ReturnException extends java.lang.RuntimeException {
  }
}