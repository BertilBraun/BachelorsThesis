
import org.cprover.CProver;

public class BlockQuickSort {
    /*@
    public behavior
      assignable \nothing; 
      signals () false; 
   */

  public static BlockQuickSort BlockQuickSortSymb() {
    return new BlockQuickSort();
  }
  
  public static int hoareBlockPartitionSymb( 
  int[] array, int originalBegin, int originalEnd, int pivotPosition) {
    assert array != null;
    assert 0 <= originalBegin;
    assert originalBegin < originalEnd;
    assert originalEnd <= array.length;
    assert (originalEnd - originalBegin) >= 1;
    assert originalBegin <= pivotPosition;
    assert pivotPosition < originalEnd;
    int returnVar = CProver.nondetInt();
    int old0 = array.length;
    int old1 = array[pivotPosition];
    int[] old2 = new int[4];
    for (int i = originalBegin; i <= originalEnd - 1; ++i) {
      for (int j = originalBegin; j <= originalEnd - 1; ++j) {
        try {
          old2[j % 4] = array[j];
        } catch (java.lang.RuntimeException e) {
        }
      }
    }
    if (array != null) {
      for (int __tmpVar__0 = originalBegin; __tmpVar__0 <= originalEnd - 1; ++__tmpVar__0) {
        array[__tmpVar__0] = CProver.nondetInt();
      }
    }
    CProver.assume(array.length == old0);
    CProver.assume(originalBegin <= returnVar && returnVar < originalEnd);
    CProver.assume(array[returnVar] == old1);
    boolean b_0 = true;
    for (int quantVar0i = originalBegin; originalBegin <= quantVar0i && returnVar >= quantVar0i; ++quantVar0i) {
      b_0 = b_0 && array[quantVar0i] <= array[returnVar];
    }
    CProver.assume((b_0));
    boolean b_1 = true;
    for (int quantVar1i = returnVar; returnVar <= quantVar1i && originalEnd - 1 >= quantVar1i; ++quantVar1i) {
      b_1 = b_1 && array[returnVar] <= array[quantVar1i];
    }
    CProver.assume((b_1));
    int sum_0 = 0;
    int sum_1 = 0;
    boolean b_2 = true;
    for (int quantVar2i = originalBegin; originalBegin <= quantVar2i && originalEnd - 1 >= quantVar2i; ++quantVar2i) {
      sum_0 = 0;
      for (int quantVar3j = originalBegin; originalBegin <= quantVar3j && originalEnd - 1 >= quantVar3j; ++quantVar3j) {
        sum_0 += array[quantVar2i] == array[quantVar3j] ? 1 : 0;
      }
      sum_1 = 0;
      for (int quantVar4j = originalBegin; originalBegin <= quantVar4j && originalEnd - 1 >= quantVar4j; ++quantVar4j) {
        sum_1 += array[quantVar2i] == old2[quantVar4j % 4] ? 1 : 0;
      }
      b_2 = b_2 && ((sum_0) == (sum_1));
    }
    CProver.assume((b_2));
    return returnVar;
  }
  
  public static void quickSortRecImplSymb( 
  int[] array, int begin, int end, int depth, int depthLimit) {
    assert array != null;
    assert 0 <= begin;
    assert begin <= end;
    assert end <= array.length;
    assert 0 <= depth;
    assert depth <= depthLimit;
    assert depthLimit < Integer.MAX_VALUE;
    int old3 = array.length;
    int[] old4 = new int[4];
    for (int i = begin; i <= end - 1; ++i) {
      for (int j = begin; j <= end - 1; ++j) {
        try {
          old4[j % 4] = array[j];
        } catch (java.lang.RuntimeException e) {
        }
      }
    }
    if (array != null) {
      for (int __tmpVar__0 = begin; __tmpVar__0 <= end - 1; ++__tmpVar__0) {
        array[__tmpVar__0] = CProver.nondetInt();
      }
    }
    CProver.assume(array.length == old3);
    boolean b_3 = true;
    for (int quantVar5i = begin; begin <= quantVar5i && end - 1 - 1 >= quantVar5i; ++quantVar5i) {
      b_3 = b_3 && array[quantVar5i] <= array[quantVar5i + 1];
    }
    CProver.assume((b_3));
    int sum_2 = 0;
    int sum_3 = 0;
    boolean b_4 = true;
    for (int quantVar6i = begin; begin <= quantVar6i && end - 1 >= quantVar6i; ++quantVar6i) {
      sum_2 = 0;
      for (int quantVar7j = begin; begin <= quantVar7j && end - 1 >= quantVar7j; ++quantVar7j) {
        sum_2 += array[quantVar6i] == array[quantVar7j] ? 1 : 0;
      }
      sum_3 = 0;
      for (int quantVar8j = begin; begin <= quantVar8j && end - 1 >= quantVar8j; ++quantVar8j) {
        sum_3 += array[quantVar6i] == old4[quantVar8j % 4] ? 1 : 0;
      }
      b_4 = b_4 && ((sum_2) == (sum_3));
    }
    CProver.assume((b_4));
  }
  
  public static void insertionSortSymb( 
  int[] array, int begin, int end) {
    assert array != null;
    assert 0 <= begin;
    assert begin <= end;
    assert end <= array.length;
    int old5 = array.length;
    int[] old6 = new int[4];
    for (int i = begin; i <= end - 1; ++i) {
      for (int j = begin; j <= end - 1; ++j) {
        try {
          old6[j % 4] = array[j];
        } catch (java.lang.RuntimeException e) {
        }
      }
    }
    if (array != null) {
      for (int __tmpVar__0 = begin; __tmpVar__0 <= end - 1; ++__tmpVar__0) {
        array[__tmpVar__0] = CProver.nondetInt();
      }
    }
    CProver.assume(array.length == old5);
    boolean b_5 = true;
    for (int quantVar9i = begin; begin <= quantVar9i && end - 1 - 1 >= quantVar9i; ++quantVar9i) {
      b_5 = b_5 && array[quantVar9i] <= array[quantVar9i + 1];
    }
    CProver.assume((b_5));
    int sum_4 = 0;
    int sum_5 = 0;
    boolean b_6 = true;
    for (int quantVar10i = begin; begin <= quantVar10i && end - 1 >= quantVar10i; ++quantVar10i) {
      sum_4 = 0;
      for (int quantVar11j = begin; begin <= quantVar11j && end - 1 >= quantVar11j; ++quantVar11j) {
        sum_4 += array[quantVar10i] == array[quantVar11j] ? 1 : 0;
      }
      sum_5 = 0;
      for (int quantVar12j = begin; begin <= quantVar12j && end - 1 >= quantVar12j; ++quantVar12j) {
        sum_5 += array[quantVar10i] == old6[quantVar12j % 4] ? 1 : 0;
      }
      b_6 = b_6 && ((sum_4) == (sum_5));
    }
    CProver.assume((b_6));
  }
  
  public static void swapSymb( 
  int[] array, int i, int j) {
    assert array != null;
    assert 0 <= i;
    assert i < array.length;
    assert 0 <= j;
    assert j < array.length;
    int old7 = array.length;
    int old8 = array[j];
    int old9 = array[i];
    array[i] = CProver.nondetInt();
    array[j] = CProver.nondetInt();
    CProver.assume(array.length == old7);
    CProver.assume(array[i] == old8 && array[j] == old9);
  }
  
  public static void sortPairSymb(int i1, int i2,  
  int[] array) {
    assert array != null;
    assert 0 <= i1;
    assert i1 < array.length;
    assert 0 <= i2;
    assert i2 < array.length;
    int old10 = array.length;
    int old11 = array[i1];
    int old12 = array[i2];
    array[i1] = CProver.nondetInt();
    array[i2] = CProver.nondetInt();
    CProver.assume(array.length == old10);
    CProver.assume((old11 <= old12) ? (array[i1] == old11 && array[i2] == old12) : (array[i1] == old12 && array[i2] == old11));
  }
  
  public static int medianOf3Symb( 
  int[] array, int begin, int end) {
    assert array != null;
    assert 0 <= begin;
    assert begin < end;
    assert end <= array.length;
    assert end - begin >= 3;
    int returnVar = CProver.nondetInt();
    int old13 = array.length;
    int[] old14 = new int[4];
    for (int i = begin; i <= end - 1; ++i) {
      for (int j = begin; j <= end - 1; ++j) {
        try {
          old14[j % 4] = array[j];
        } catch (java.lang.RuntimeException e) {
        }
      }
    }
    array[begin] = CProver.nondetInt();
    array[begin + ((end - begin) / 2)] = CProver.nondetInt();
    array[end - 1] = CProver.nondetInt();
    CProver.assume(array.length == old13);
    CProver.assume(returnVar == begin + ((end - begin) / 2));
    CProver.assume(array[begin] <= array[returnVar] && array[returnVar] <= array[end - 1]);
    int sum_6 = 0;
    int sum_7 = 0;
    boolean b_7 = true;
    for (int quantVar13i = begin; begin <= quantVar13i && end - 1 >= quantVar13i; ++quantVar13i) {
      sum_6 = 0;
      for (int quantVar14j = begin; begin <= quantVar14j && end - 1 >= quantVar14j; ++quantVar14j) {
        sum_6 += array[quantVar13i] == array[quantVar14j] ? 1 : 0;
      }
      sum_7 = 0;
      for (int quantVar15j = begin; begin <= quantVar15j && end - 1 >= quantVar15j; ++quantVar15j) {
        sum_7 += array[quantVar13i] == old14[quantVar15j % 4] ? 1 : 0;
      }
      b_7 = b_7 && ((sum_6) == (sum_7));
    }
    CProver.assume((b_7));
    return returnVar;
  }
  
  public static int partitionSymb( 
  int[] array, int begin, int end) {
    assert array != null;
    assert 0 <= begin;
    assert begin < end;
    assert end <= array.length;
    assert end - begin >= 3;
    int returnVar = CProver.nondetInt();
    int old15 = array.length;
    int[] old16 = new int[4];
    for (int i = begin; i <= end - 1; ++i) {
      for (int j = begin; j <= end - 1; ++j) {
        try {
          old16[j % 4] = array[j];
        } catch (java.lang.RuntimeException e) {
        }
      }
    }
    if (array != null) {
      for (int __tmpVar__0 = begin; __tmpVar__0 <= end - 1; ++__tmpVar__0) {
        array[__tmpVar__0] = CProver.nondetInt();
      }
    }
    CProver.assume(array.length == old15);
    CProver.assume(begin <= returnVar && returnVar < end);
    boolean b_8 = true;
    for (int quantVar16i = begin; begin <= quantVar16i && returnVar >= quantVar16i; ++quantVar16i) {
      b_8 = b_8 && array[quantVar16i] <= array[returnVar];
    }
    CProver.assume((b_8));
    boolean b_9 = true;
    for (int quantVar17i = returnVar; returnVar <= quantVar17i && end - 1 >= quantVar17i; ++quantVar17i) {
      b_9 = b_9 && array[returnVar] <= array[quantVar17i];
    }
    CProver.assume((b_9));
    int sum_8 = 0;
    int sum_9 = 0;
    boolean b_10 = true;
    for (int quantVar18i = begin; begin <= quantVar18i && end - 1 >= quantVar18i; ++quantVar18i) {
      sum_8 = 0;
      for (int quantVar19j = begin; begin <= quantVar19j && end - 1 >= quantVar19j; ++quantVar19j) {
        sum_8 += array[quantVar18i] == array[quantVar19j] ? 1 : 0;
      }
      sum_9 = 0;
      for (int quantVar20j = begin; begin <= quantVar20j && end - 1 >= quantVar20j; ++quantVar20j) {
        sum_9 += array[quantVar18i] == old16[quantVar20j % 4] ? 1 : 0;
      }
      b_10 = b_10 && ((sum_8) == (sum_9));
    }
    CProver.assume((b_10));
    return returnVar;
  }
  
  public static double logSymb(double a) {
    assert a > 0;
    double returnVar = CProver.nondetDouble();
    CProver.assume(1 <= returnVar && returnVar < 100);
    return returnVar;
  }
  
  public static int minSymb(int a, int b) {
    int returnVar = CProver.nondetInt();
    CProver.assume(returnVar == (a < b ? a : b));
    return returnVar;
  }
  
  public static int maxSymb(int a, int b) {
    int returnVar = CProver.nondetInt();
    CProver.assume(returnVar == (a > b ? a : b));
    return returnVar;
  }
  
  public BlockQuickSort() {
    {
    }
  }
  private static final int BLOCKSIZE = 2;
  private static final int IS_THRESH = 3;
  private static final int STACK_SIZE = 80;
  
  public static int hoareBlockPartitionVerf( 
  int[] array, int originalBegin, int originalEnd, int pivotPosition) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= originalBegin && originalBegin < originalEnd && originalEnd <= array.length);
    }
    {
      CProver.assume((originalEnd - originalBegin) >= 1);
    }
    {
      CProver.assume(originalBegin <= pivotPosition && pivotPosition < originalEnd);
    }
    int old17 = array.length;
    int old18 = array[pivotPosition];
    int[] old19 = new int[4];
    for (int i = originalBegin; i <= originalEnd - 1; ++i) {
      for (int j = originalBegin; j <= originalEnd - 1; ++j) {
        try {
          old19[j % 4] = array[j];
        } catch (java.lang.RuntimeException e) {
        }
      }
    }
    int returnVar = 0;
    try {
       
      int[] indexL = new int[BLOCKSIZE];
       
      int[] indexR = new int[BLOCKSIZE];
      int begin = originalBegin;
      int end = originalEnd;
      int last = end - 1;
      int pivot = array[pivotPosition];
      swap(array, pivotPosition, last);
      assert !false;
      pivotPosition = last;
      last--;
      int numLeft = 0;
      int numRight = 0;
      int startLeft = 0;
      int startRight = 0;
      int num = 0;
      if (last - begin + 1 > 2 * BLOCKSIZE) {
        while (last - begin + 1 > 2 * BLOCKSIZE) {
          if (numLeft == 0) {
            assert !false;
            startLeft = 0;
            for (int j = 0; j < BLOCKSIZE; ) {
              assert !false;
              indexL[numLeft] = j;
              numLeft += array[begin + j] >= pivot ? 1 : 0;
              j++;
            }
          }
          if (numRight == 0) {
            assert !false;
            startRight = 0;
            for (int j = 0; j < BLOCKSIZE; ) {
              assert !false;
              indexR[numRight] = j;
              numRight += pivot >= array[last - j] ? 1 : 0;
              j++;
            }
          }
          assert !false;
          num = min(numLeft, numRight);
          if (num > 0) {
            for (int j = 0; j < num; ) {
              swap(array, begin + indexL[startLeft + j], last - indexR[startRight + j]);
              j++;
            }
          }
          numLeft -= num;
          numRight -= num;
          startLeft += num;
          startRight += num;
          begin += (numLeft == 0) ? BLOCKSIZE : 0;
          last -= (numRight == 0) ? BLOCKSIZE : 0;
        }
      }
      int shiftR = 0;
      int shiftL = 0;
      if (numRight == 0 && numLeft == 0) {
        assert !false;
        shiftL = ((last - begin) + 1) / 2;
        assert !false;
        shiftR = (last - begin) + 1 - shiftL;
        assert !false;
        startLeft = 0;
        assert !false;
        startRight = 0;
        for (int j = 0; j < shiftL; ) {
          assert !false;
          indexL[numLeft] = j;
          numLeft += array[begin + j] >= pivot ? 1 : 0;
          assert !false;
          indexR[numRight] = j;
          numRight += pivot >= array[last - j] ? 1 : 0;
          j++;
        }
        if (shiftL < shiftR) {
          assert !false;
          indexR[numRight] = shiftR - 1;
          numRight += pivot >= array[last - shiftR + 1] ? 1 : 0;
        }
      } else if (numRight != 0) {
        assert !false;
        shiftL = (last - begin) - BLOCKSIZE + 1;
        assert !false;
        shiftR = BLOCKSIZE;
        assert !false;
        startLeft = 0;
        for (int j = 0; j < shiftL; ) {
          assert !false;
          indexL[numLeft] = j;
          numLeft += array[begin + j] >= pivot ? 1 : 0;
          j++;
        }
      } else {
        assert !false;
        shiftL = BLOCKSIZE;
        assert !false;
        shiftR = (last - begin) - BLOCKSIZE + 1;
        assert !false;
        startRight = 0;
        for (int j = 0; j < shiftR; ) {
          assert !false;
          indexR[numRight] = j;
          numRight += pivot >= array[last - j] ? 1 : 0;
          j++;
        }
      }
      assert !false;
      num = min(numLeft, numRight);
      if (num > 0) {
        for (int j = 0; j < num; ) {
          swap(array, begin + indexL[startLeft + j], last - indexR[startRight + j]);
          j++;
        }
      }
      numLeft -= num;
      numRight -= num;
      startLeft += num;
      startRight += num;
      begin += (numLeft == 0) ? shiftL : 0;
      last -= (numRight == 0) ? shiftR : 0;
      if (numLeft != 0) {
        int lowerI = startLeft + numLeft - 1;
        int upper = last - begin;
        while (lowerI >= startLeft && indexL[lowerI] == upper) {
          upper--;
          lowerI--;
        }
        while (lowerI >= startLeft) {
          swap(array, begin + upper, begin + indexL[lowerI]);
          upper--;
          lowerI--;
        }
        swap(array, pivotPosition, begin + upper + 1);
        {
          returnVar = begin + upper + 1;
          throw new BlockQuickSort.ReturnException();
        }
      } else if (numRight != 0) {
        int lowerI = startRight + numRight - 1;
        int upper = last - begin;
        while (lowerI >= startRight && indexR[lowerI] == upper) {
          upper--;
          lowerI--;
        }
        while (lowerI >= startRight) {
          swap(array, last - upper, last - indexR[lowerI]);
          upper--;
          lowerI--;
        }
        swap(array, pivotPosition, last - upper);
        {
          returnVar = last - upper;
          throw new BlockQuickSort.ReturnException();
        }
      } else {
        swap(array, pivotPosition, begin);
        {
          returnVar = begin;
          throw new BlockQuickSort.ReturnException();
        }
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old17;
    }
    {
      {
        assert originalBegin <= returnVar;
        assert returnVar < originalEnd;
      }
    }
    {
      assert array[returnVar] == old18;
    }
    {
      int quantVar21i = CProver.nondetInt();
      assert !(originalBegin <= quantVar21i && quantVar21i <= returnVar) || array[quantVar21i] <= array[returnVar];
    }
    {
      int quantVar22i = CProver.nondetInt();
      assert !(returnVar <= quantVar22i && quantVar22i < originalEnd) || array[returnVar] <= array[quantVar22i];
    }
    {
      int quantVar23i = CProver.nondetInt();
      int sum_10 = 0;
      int sum_11 = 0;
      if (!!(originalBegin <= quantVar23i && quantVar23i < originalEnd)) {
        sum_10 = 0;
        for (int quantVar24j = originalBegin; originalBegin <= quantVar24j && originalEnd - 1 >= quantVar24j; ++quantVar24j) {
          sum_10 += array[quantVar23i] == array[quantVar24j] ? 1 : 0;
        }
        sum_11 = 0;
        for (int quantVar25j = originalBegin; originalBegin <= quantVar25j && originalEnd - 1 >= quantVar25j; ++quantVar25j) {
          sum_11 += array[quantVar23i] == old19[quantVar25j % 4] ? 1 : 0;
        }
      }
      assert !(originalBegin <= quantVar23i && quantVar23i < originalEnd) || ((sum_10) == (sum_11));
    }
    return returnVar;
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= originalBegin && originalBegin < originalEnd && originalEnd <= array.length; 
      requires (originalEnd - originalBegin) >= 1; 
      requires originalBegin <= pivotPosition && pivotPosition < originalEnd; 
      ensures array.length == \old(array.length); 
      ensures originalBegin <= \result && \result < originalEnd; 
      ensures array[\result] == \old(array[pivotPosition]); 
      ensures (\forall int i; originalBegin <= i <= \result; array[i] <= array[\result]); 
      ensures (\forall int i; \result <= i < originalEnd; array[\result] <= array[i]); 
      ensures (\forall int i; originalBegin <= i < originalEnd; ((\num_of int j; originalBegin <= j < originalEnd; array[i] == array[j]) == (\num_of int j; originalBegin <= j < originalEnd; array[i] == \old(array[j])))); 
      assignable array[originalBegin .. originalEnd - 1]; 
   */

  public static int hoareBlockPartition( 
  int[] array, int originalBegin, int originalEnd, int pivotPosition) {
     
    int[] indexL = new int[BLOCKSIZE];
     
    int[] indexR = new int[BLOCKSIZE];
    int begin = originalBegin;
    int end = originalEnd;
    int last = end - 1;
    int pivot = array[pivotPosition];
    swap(array, pivotPosition, last);
    pivotPosition = last;
    last--;
    int numLeft = 0;
    int numRight = 0;
    int startLeft = 0;
    int startRight = 0;
    int num = 0;
    if (last - begin + 1 > 2 * BLOCKSIZE) {
      //@ loop_invariant originalBegin <= begin && begin <= last && last < originalEnd - 1;
      //@ loop_invariant 0 <= numLeft && numLeft <= BLOCKSIZE;
      //@ loop_invariant 0 <= numRight && numRight <= BLOCKSIZE;
      //@ loop_invariant 0 <= startLeft && startLeft <= BLOCKSIZE && startLeft + numLeft <= BLOCKSIZE;
      //@ loop_invariant 0 <= startRight && startRight <= BLOCKSIZE && startRight + numRight <= BLOCKSIZE;
      //@ loop_invariant 0 <= num && num <= BLOCKSIZE;
      //@ loop_invariant numRight == 0 || numLeft == 0;
      //@ loop_invariant array[originalEnd - 1] == \old(array[pivotPosition]);
      //@ loop_invariant (\exists int i; 0 <= i < (originalEnd - originalBegin); begin == originalBegin + i * BLOCKSIZE);
      //@ loop_invariant (\exists int i; 0 <= i < (originalEnd - originalBegin); last == originalEnd - 2 - i * BLOCKSIZE);
      //@ loop_invariant (\forall int i; 0 <= i < BLOCKSIZE; 0 <= indexL[i] && indexL[i] < BLOCKSIZE);
      //@ loop_invariant (\forall int i; 0 <= i < numLeft; indexL[startLeft + i] < last - begin && pivot <= array[begin + indexL[startLeft + i]]);
      //@ loop_invariant (\forall int i; 0 <= i < startLeft + numLeft - 1; indexL[i] < indexL[i + 1]);
      //@ loop_invariant (numLeft != 0) ==> numLeft == (\num_of int i; startLeft <= i < BLOCKSIZE; pivot <= array[begin + i]);
      //@ loop_invariant (\forall int i; 0 <= i < BLOCKSIZE; 0 <= indexR[i] && indexR[i] < BLOCKSIZE);
      //@ loop_invariant (\forall int i; 0 <= i < numRight; indexR[startRight + i] < last - begin && array[last - indexR[startRight + i]] <= pivot);
      //@ loop_invariant (\forall int i; 0 <= i < startRight + numRight - 1; indexR[i] < indexR[i + 1]);
      //@ loop_invariant (numRight != 0) ==> numRight == (\num_of int i; startRight <= i < BLOCKSIZE; array[last - i] <= pivot);
      //@ loop_invariant (numLeft == 0) ==> (\forall int i; originalBegin <= i < begin; array[i] <= pivot);
      //@ loop_invariant (numLeft != 0) ==> (\forall int i; originalBegin <= i < begin + indexL[startLeft]; array[i] <= pivot);
      //@ loop_invariant (numRight == 0) ==> (\forall int i; last < i < originalEnd; pivot <= array[i]);
      //@ loop_invariant (numRight != 0) ==> (\forall int i; last - indexR[startRight] < i < originalEnd; pivot <= array[i]);
      //@ loop_invariant (\forall int i; originalBegin <= i < originalEnd; (\num_of int j; originalBegin <= j < originalEnd; array[i] == array[j]) == (\num_of int j; originalBegin <= j < originalEnd; array[i] == \old(array[j])));
      //@ loop_modifies array[(begin > originalBegin ? begin : originalBegin) .. (begin + BLOCKSIZE - 1 > originalEnd - 2 ? originalEnd - 2 : begin + BLOCKSIZE - 1)], array[(last - BLOCKSIZE - 1 > originalBegin ? last - BLOCKSIZE - 1 : originalBegin) .. (last < originalEnd - 2 ? last : originalEnd - 2)], last, begin, numLeft, numRight, startLeft, startRight, num, indexL[0 .. BLOCKSIZE - 1], indexR[0 .. BLOCKSIZE - 1];
      //@ loop_decreases last - begin;
      while (last - begin + 1 > 2 * BLOCKSIZE) {
        if (numLeft == 0) {
          startLeft = 0;
          //@ loop_invariant 0 <= j <= BLOCKSIZE;
          //@ loop_invariant numLeft == (\num_of int k; 0 <= k < j; pivot <= array[begin + k]);
          //@ loop_invariant (\forall int k; 0 <= k < numLeft; 0 <= indexL[k] && indexL[k] < j && pivot <= array[begin + indexL[k]]);
          //@ loop_invariant (\forall int k; 0 <= k < BLOCKSIZE; 0 <= indexL[k] && indexL[k] < BLOCKSIZE);
          //@ loop_invariant (\forall int k; 0 <= k < numLeft - 1; indexL[k] < indexL[k + 1]);
          //@ loop_modifies numLeft, indexL[0 .. BLOCKSIZE - 1], j;
          //@ loop_decreases BLOCKSIZE - j;
          for (int j = 0; j < BLOCKSIZE; j++) {
            indexL[numLeft] = j;
            numLeft += array[begin + j] >= pivot ? 1 : 0;
          }
        }
        if (numRight == 0) {
          startRight = 0;
          //@ loop_invariant 0 <= j <= BLOCKSIZE;
          //@ loop_invariant numRight == (\num_of int k; 0 <= k < j; array[last - k] <= pivot);
          //@ loop_invariant (\forall int k; 0 <= k < numRight; 0 <= indexR[k] && indexR[k] < j && array[last - indexR[k]] <= pivot);
          //@ loop_invariant (\forall int k; 0 <= k < BLOCKSIZE; 0 <= indexR[k] && indexR[k] < BLOCKSIZE);
          //@ loop_invariant (\forall int k; 0 <= k < numRight - 1; indexR[k] < indexR[k + 1]);
          //@ loop_modifies numRight, indexR[0 .. BLOCKSIZE - 1], j;
          //@ loop_decreases BLOCKSIZE - j;
          for (int j = 0; j < BLOCKSIZE; j++) {
            indexR[numRight] = j;
            numRight += pivot >= array[last - j] ? 1 : 0;
          }
        }
        num = min(numLeft, numRight);
        if (num > 0) {
          //@ loop_invariant 0 <= j <= num;
          //@ loop_invariant (\forall int i; originalBegin <= i < begin + indexL[startLeft]; array[i] <= pivot);
          //@ loop_invariant j > 0 ==> (\forall int i; originalBegin <= i <= begin + indexL[startLeft + j - 1]; array[i] <= pivot);
          //@ loop_invariant (\forall int i; last - indexR[startRight] < i < originalEnd; pivot <= array[i]);
          //@ loop_invariant j > 0 ==> (\forall int i; last - indexR[startRight + j - 1] <= i < originalEnd; pivot <= array[i]);
          //@ loop_invariant (\forall int i; startLeft + j <= i < startLeft + numLeft; pivot <= array[begin + indexL[i]]);
          //@ loop_invariant (\forall int i; startRight + j <= i < startRight + numRight; array[last - indexR[i]] <= pivot);
          //@ loop_invariant (\forall int i; begin <= i < last + 1; (\num_of int k; begin <= k < last + 1; array[i] == array[k]) == (\num_of int k; begin <= k < last + 1; array[i] == \old(array[k])));
          //@ loop_modifies array[begin + indexL[startLeft] .. begin + indexL[startLeft + num - 1]], array[last - indexR[startRight + num - 1] .. last - indexR[startRight]], j;
          //@ loop_decreases num - j;
          for (int j = 0; j < num; j++) {
            swap(array, begin + indexL[startLeft + j], last - indexR[startRight + j]);
          }
        }
        numLeft -= num;
        numRight -= num;
        startLeft += num;
        startRight += num;
        begin += (numLeft == 0) ? BLOCKSIZE : 0;
        last -= (numRight == 0) ? BLOCKSIZE : 0;
      }
    }
    int shiftR = 0;
    int shiftL = 0;
    if (numRight == 0 && numLeft == 0) {
      shiftL = ((last - begin) + 1) / 2;
      shiftR = (last - begin) + 1 - shiftL;
      startLeft = 0;
      startRight = 0;
      //@ loop_invariant 0 <= j <= shiftL;
      //@ loop_invariant 0 <= numLeft && numLeft <= j;
      //@ loop_invariant 0 <= numRight && numRight <= j;
      //@ loop_invariant numLeft == (\num_of int k; 0 <= k < j; pivot <= array[begin + k]);
      //@ loop_invariant numRight == (\num_of int k; 0 <= k < j; array[last - k] <= pivot);
      //@ loop_invariant (\forall int k; 0 <= k < numLeft; 0 <= indexL[k] && indexL[k] < j && pivot <= array[begin + indexL[k]]);
      //@ loop_invariant (\forall int k; 0 <= k < BLOCKSIZE; 0 <= indexL[k] && indexL[k] < BLOCKSIZE);
      //@ loop_invariant (\forall int k; 0 <= k < numRight; 0 <= indexR[k] && indexR[k] < j && array[last - indexR[k]] <= pivot);
      //@ loop_invariant (\forall int k; 0 <= k < BLOCKSIZE; 0 <= indexR[k] && indexR[k] < BLOCKSIZE);
      //@ loop_invariant (\forall int k; 0 <= k < numLeft - 1; indexL[k] < indexL[k + 1]);
      //@ loop_invariant (\forall int k; 0 <= k < numRight - 1; indexR[k] < indexR[k + 1]);
      //@ loop_decreases shiftL - j;
      //@ loop_modifies indexL[0 .. shiftL - 1], numLeft, indexR[0 .. shiftL - 1], numRight, j;
      for (int j = 0; j < shiftL; j++) {
        indexL[numLeft] = j;
        numLeft += array[begin + j] >= pivot ? 1 : 0;
        indexR[numRight] = j;
        numRight += pivot >= array[last - j] ? 1 : 0;
      }
      if (shiftL < shiftR) {
        indexR[numRight] = shiftR - 1;
        numRight += pivot >= array[last - shiftR + 1] ? 1 : 0;
      }
    } else if (numRight != 0) {
      shiftL = (last - begin) - BLOCKSIZE + 1;
      shiftR = BLOCKSIZE;
      startLeft = 0;
      //@ loop_invariant 0 <= j <= shiftL;
      //@ loop_invariant numLeft == (\num_of int k; 0 <= k < j; pivot <= array[begin + k]);
      //@ loop_invariant (\forall int k; 0 <= k < numLeft; 0 <= indexL[k] && indexL[k] < j && pivot <= array[begin + indexL[k]]);
      //@ loop_invariant (\forall int k; 0 <= k < BLOCKSIZE; 0 <= indexL[k] && indexL[k] < BLOCKSIZE);
      //@ loop_invariant (\forall int k; 0 <= k < numLeft - 1; indexL[k] < indexL[k + 1]);
      //@ loop_modifies numLeft, indexL[0 .. shiftL - 1], j;
      //@ loop_decreases shiftL - j;
      for (int j = 0; j < shiftL; j++) {
        indexL[numLeft] = j;
        numLeft += array[begin + j] >= pivot ? 1 : 0;
      }
    } else {
      shiftL = BLOCKSIZE;
      shiftR = (last - begin) - BLOCKSIZE + 1;
      startRight = 0;
      //@ loop_invariant 0 <= j <= shiftR;
      //@ loop_invariant numRight == (\num_of int k; 0 <= k < j; array[last - k] <= pivot);
      //@ loop_invariant (\forall int k; 0 <= k < numRight; 0 <= indexR[k] && indexR[k] < j && array[last - indexR[k]] <= pivot);
      //@ loop_invariant (\forall int k; 0 <= k < BLOCKSIZE; 0 <= indexR[k] && indexR[k] < BLOCKSIZE);
      //@ loop_invariant (\forall int k; 0 <= k < numRight - 1; indexR[k] < indexR[k + 1]);
      //@ loop_modifies numRight, indexR[0 .. shiftR - 1], j;
      //@ loop_decreases shiftR - j;
      for (int j = 0; j < shiftR; j++) {
        indexR[numRight] = j;
        numRight += pivot >= array[last - j] ? 1 : 0;
      }
    }
    num = min(numLeft, numRight);
    if (num > 0) {
      //@ loop_invariant 0 <= j <= num;
      //@ loop_invariant (\forall int i; originalBegin <= i < begin + indexL[startLeft]; array[i] <= pivot);
      //@ loop_invariant j > 0 ==> (\forall int i; originalBegin <= i <= begin + indexL[startLeft + j - 1]; array[i] <= pivot);
      //@ loop_invariant (\forall int i; last - indexR[startRight] < i < originalEnd; pivot <= array[i]);
      //@ loop_invariant j > 0 ==> (\forall int i; last - indexR[startRight + j - 1] <= i < originalEnd; pivot <= array[i]);
      //@ loop_invariant (\forall int i; startLeft + j <= i < startLeft + numLeft; pivot <= array[begin + indexL[i]]);
      //@ loop_invariant (\forall int i; startRight + j <= i < startRight + numRight; array[last - indexR[i]] <= pivot);
      //@ loop_invariant (\forall int i; begin <= i < last + 1; (\num_of int k; begin <= k < last + 1; array[i] == array[k]) == (\num_of int k; begin <= k < last + 1; array[i] == \old(array[k])));
      //@ loop_modifies array[begin + indexL[startLeft] .. begin + indexL[startLeft + num - 1]], array[last - indexR[startRight + num - 1] .. last - indexR[startRight]], j;
      //@ loop_decreases num - j;
      for (int j = 0; j < num; j++) {
        swap(array, begin + indexL[startLeft + j], last - indexR[startRight + j]);
      }
    }
    numLeft -= num;
    numRight -= num;
    startLeft += num;
    startRight += num;
    begin += (numLeft == 0) ? shiftL : 0;
    last -= (numRight == 0) ? shiftR : 0;
    if (numLeft != 0) {
      int lowerI = startLeft + numLeft - 1;
      int upper = last - begin;
      //@ loop_invariant 0 <= startLeft && startLeft - 1 <= lowerI && lowerI < startLeft + numLeft && startLeft + numLeft <= BLOCKSIZE;
      //@ loop_invariant upper == last - begin - (startLeft + numLeft - 1 - lowerI);
      //@ loop_invariant (\forall int i; lowerI < i < startLeft + numLeft - 1; indexL[i] == upper + (i - lowerI));
      //@ loop_invariant (\forall int i; begin <= i < begin + indexL[startLeft]; array[i] <= pivot);
      //@ loop_invariant (\forall int i; begin + upper < i <= last; pivot <= array[i]);
      //@ loop_modifies lowerI, upper;
      //@ loop_decreases lowerI + 1;
      while (lowerI >= startLeft && indexL[lowerI] == upper) {
        upper--;
        lowerI--;
      }
      //@ loop_invariant 0 <= startLeft && startLeft - 1 <= lowerI && lowerI < startLeft + numLeft && startLeft + numLeft <= BLOCKSIZE;
      //@ loop_invariant upper == last - begin - (startLeft + numLeft - 1 - lowerI);
      //@ loop_invariant (\forall int i; startLeft <= i < lowerI; indexL[i] == indexL[i + 1] - 1);
      //@ loop_invariant (\forall int i; begin + indexL[startLeft] <= i < begin + upper; pivot <= array[i]);
      //@ loop_invariant (\forall int i; begin + upper < i <= last; pivot <= array[i]);
      //@ loop_invariant lowerI >= startLeft ==> indexL[lowerI] == upper || array[begin + upper] <= pivot;
      //@ loop_invariant lowerI < startLeft && upper >= 0 ==> array[begin + upper] <= pivot;
      //@ loop_invariant (\forall int i; begin <= i < last + 1; (\num_of int k; begin <= k < last + 1; array[i] == array[k]) == (\num_of int k; begin <= k < last + 1; array[i] == \old(array[k])));
      //@ loop_modifies upper, lowerI, array[begin + indexL[startLeft] .. last];
      //@ loop_decreases lowerI + 1;
      while (lowerI >= startLeft) {
        swap(array, begin + upper, begin + indexL[lowerI]);
        upper--;
        lowerI--;
      }
      swap(array, pivotPosition, begin + upper + 1);
      return begin + upper + 1;
    } else if (numRight != 0) {
      int lowerI = startRight + numRight - 1;
      int upper = last - begin;
      //@ loop_invariant 0 <= startRight && startRight - 1 <= lowerI && lowerI < startRight + numRight && startRight + numRight <= BLOCKSIZE;
      //@ loop_invariant upper == last - begin - (startRight + numRight - 1 - lowerI);
      //@ loop_invariant (\forall int i; lowerI < i < startRight + numRight - 1; indexR[i] == upper + (i - lowerI));
      //@ loop_invariant (\forall int i; last - indexR[startRight] < i <= last; pivot <= array[i]);
      //@ loop_invariant (\forall int i; begin <= i < last - upper; array[i] <= pivot);
      //@ loop_modifies lowerI, upper;
      //@ loop_decreases lowerI + 1;
      while (lowerI >= startRight && indexR[lowerI] == upper) {
        upper--;
        lowerI--;
      }
      //@ loop_invariant 0 <= startRight && startRight - 1 <= lowerI && lowerI < startRight + numRight && startRight + numRight <= BLOCKSIZE;
      //@ loop_invariant upper == last - begin - (startRight + numRight - 1 - lowerI);
      //@ loop_invariant (\forall int i; startRight <= i < lowerI; indexR[i] == indexR[i + 1] - 1);
      //@ loop_invariant (\forall int i; begin <= i < last - upper; array[i] <= pivot);
      //@ loop_invariant (\forall int i; last - upper < i <= last - indexR[startRight]; array[i] <= pivot);
      //@ loop_invariant lowerI >= startRight ==> indexR[lowerI] == upper || pivot <= array[last - upper];
      //@ loop_invariant lowerI < startRight && upper >= 0 ==> pivot <= array[last - upper];
      //@ loop_invariant (\forall int i; begin <= i < last + 1; (\num_of int k; begin <= k < last + 1; array[i] == array[k]) == (\num_of int k; begin <= k < last + 1; array[i] == \old(array[k])));
      //@ loop_modifies upper, lowerI, array[begin .. last - indexR[startRight]];
      //@ loop_decreases lowerI + 1;
      while (lowerI >= startRight) {
        swap(array, last - upper, last - indexR[lowerI]);
        upper--;
        lowerI--;
      }
      swap(array, pivotPosition, last - upper);
      return last - upper;
    } else {
      swap(array, pivotPosition, begin);
      return begin;
    }
  }
  
  public static void quickSortVerf( 
  int[] array, int originalBegin, int originalEnd) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= originalBegin && originalBegin < originalEnd && originalEnd <= array.length);
    }
    int old20 = array.length;
    int[] old21 = new int[4];
    for (int i = originalBegin; i <= originalEnd - 1; ++i) {
      for (int j = originalBegin; j <= originalEnd - 1; ++j) {
        try {
          old21[j % 4] = array[j];
        } catch (java.lang.RuntimeException e) {
        }
      }
    }
    try {
      int begin = originalBegin;
      int end = originalEnd;
       
      int[] stack = new int[STACK_SIZE];
      int top = 0;
      int depth = 0;
      int depthLimit = (int)(2 * log(end - begin) / log(2)) + 3;
      assert !false;
      stack[top++] = begin;
      assert !false;
      stack[top++] = end;
      while (top > 0) {
        assert !false;
        end = stack[--top];
        assert !false;
        begin = stack[--top];
        while (end - begin > IS_THRESH && depth < depthLimit) {
          int pivot = partition(array, begin, end);
          if (pivot - begin > end - pivot) {
            assert !false;
            stack[top++] = begin;
            assert !false;
            stack[top++] = pivot;
            assert !false;
            begin = pivot + 1;
          } else {
            assert !false;
            stack[top++] = pivot + 1;
            assert !false;
            stack[top++] = end;
            assert !false;
            end = pivot;
          }
          depth++;
        }
        if (end - begin <= IS_THRESH || depth >= depthLimit) {
          insertionSort(array, begin, end);
        }
        depth--;
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old20;
    }
    {
      int quantVar26i = CProver.nondetInt();
      assert !(originalBegin <= quantVar26i && quantVar26i < originalEnd - 1) || array[quantVar26i] <= array[quantVar26i + 1];
    }
    {
      int quantVar27i = CProver.nondetInt();
      int sum_12 = 0;
      int sum_13 = 0;
      if (!!(originalBegin <= quantVar27i && quantVar27i < originalEnd)) {
        sum_12 = 0;
        for (int quantVar28j = originalBegin; originalBegin <= quantVar28j && originalEnd - 1 >= quantVar28j; ++quantVar28j) {
          sum_12 += array[quantVar27i] == array[quantVar28j] ? 1 : 0;
        }
        sum_13 = 0;
        for (int quantVar29j = originalBegin; originalBegin <= quantVar29j && originalEnd - 1 >= quantVar29j; ++quantVar29j) {
          sum_13 += array[quantVar27i] == old21[quantVar29j % 4] ? 1 : 0;
        }
      }
      assert !(originalBegin <= quantVar27i && quantVar27i < originalEnd) || ((sum_12) == (sum_13));
    }
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= originalBegin && originalBegin < originalEnd && originalEnd <= array.length; 
      ensures array.length == \old(array.length); 
      ensures (\forall int i; originalBegin <= i < originalEnd - 1; array[i] <= array[i + 1]); 
      ensures (\forall int i; originalBegin <= i < originalEnd; ((\num_of int j; originalBegin <= j < originalEnd; array[i] == array[j]) == (\num_of int j; originalBegin <= j < originalEnd; array[i] == \old(array[j])))); 
      assignable array[originalBegin .. originalEnd - 1]; 
   */

  public static void quickSort( 
  int[] array, int originalBegin, int originalEnd) {
    int begin = originalBegin;
    int end = originalEnd;
     
    int[] stack = new int[STACK_SIZE];
    int top = 0;
    int depth = 0;
    int depthLimit = (int)(2 * log(end - begin) / log(2)) + 3;
    stack[top++] = begin;
    stack[top++] = end;
    //@ loop_invariant 0 <= top && top < STACK_SIZE;
    //@ loop_invariant 0 <= depth && depth <= depthLimit;
    //@ loop_invariant originalBegin <= begin && begin <= end && end <= originalEnd;
    //@ loop_invariant (\forall int i; originalBegin <= i < min(begin, (\min int j; 0 <= j < top; stack[j])); array[i] <= array[i + 1]);
    //@ loop_invariant (\forall int i; max(end, (\max int j; 0 <= j < top; stack[j])) <= i < originalEnd; array[i] <= array[i + 1]);
    //@ loop_invariant (\forall int i; originalBegin <= i < originalEnd; (\num_of int k; originalBegin <= k < originalEnd; array[i] == array[k]) == (\num_of int k; originalBegin <= k < originalEnd; array[i] == \old(array[k])));
    //@ loop_modifies top, depth, stack[0 .. STACK_SIZE - 1], array[originalBegin .. originalEnd - 1];
    //@ loop_decreases (\sum int i; originalBegin <= i < originalEnd; (\num_of int j; i <= j < originalEnd; array[j] < array[i]));
    while (top > 0) {
      end = stack[--top];
      begin = stack[--top];
      //@ loop_invariant top >= 0 && top < STACK_SIZE;
      //@ loop_invariant originalBegin <= begin && begin <= end && end <= originalEnd;
      //@ loop_invariant 0 <= depth && depth <= depthLimit;
      //@ loop_invariant (\forall int i; 0 <= i < top / 2; originalBegin <= stack[2 * i] && stack[2 * i] < stack[2 * i + 1] && stack[2 * i + 1] <= originalEnd);
      //@ loop_invariant (\forall int i; 0 <= i < top / 2; (\forall int j; 0 <= j < stack[2 * i]; array[j] <= (\min int k; stack[2 * i] <= k < stack[2 * i + 1]; array[k])));
      //@ loop_invariant (\forall int i; 0 <= i < top / 2; (\forall int j; stack[2 * i + 1] <= j < originalEnd; (\max int k; stack[2 * i] <= k < stack[2 * i + 1]; array[k]) <= array[j]));
      //@ loop_invariant (\forall int i; originalBegin <= i < originalEnd; (\num_of int k; originalBegin <= k < originalEnd; array[i] == array[k]) == (\num_of int k; originalBegin <= k < originalEnd; array[i] == \old(array[k])));
      //@ loop_modifies top, depth, stack[0 .. STACK_SIZE - 1], array[originalBegin .. originalEnd - 1];
      //@ loop_decreases end - begin;
      while (end - begin > IS_THRESH && depth < depthLimit) {
        int pivot = partition(array, begin, end);
        if (pivot - begin > end - pivot) {
          stack[top++] = begin;
          stack[top++] = pivot;
          begin = pivot + 1;
        } else {
          stack[top++] = pivot + 1;
          stack[top++] = end;
          end = pivot;
        }
        depth++;
      }
      if (end - begin <= IS_THRESH || depth >= depthLimit) {
        insertionSort(array, begin, end);
      }
      depth--;
    }
  }
  
  public static void quickSortRecVerf( 
  int[] array, int begin, int end) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= begin && begin < end && end <= array.length);
    }
    int old22 = array.length;
    int[] old23 = new int[4];
    for (int i = begin; i <= end - 1; ++i) {
      for (int j = begin; j <= end - 1; ++j) {
        try {
          old23[j % 4] = array[j];
        } catch (java.lang.RuntimeException e) {
        }
      }
    }
    try {
      int depth = 0;
      int depthLimit = (int)(2 * log(end - begin) / log(2)) + 3;
      quickSortRecImpl(array, begin, end, depth, depthLimit);
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old22;
    }
    {
      int quantVar30i = CProver.nondetInt();
      assert !(begin <= quantVar30i && quantVar30i < end - 1) || array[quantVar30i] <= array[quantVar30i + 1];
    }
    {
      int quantVar31i = CProver.nondetInt();
      int sum_14 = 0;
      int sum_15 = 0;
      if (!!(begin <= quantVar31i && quantVar31i < end)) {
        sum_14 = 0;
        for (int quantVar32j = begin; begin <= quantVar32j && end - 1 >= quantVar32j; ++quantVar32j) {
          sum_14 += array[quantVar31i] == array[quantVar32j] ? 1 : 0;
        }
        sum_15 = 0;
        for (int quantVar33j = begin; begin <= quantVar33j && end - 1 >= quantVar33j; ++quantVar33j) {
          sum_15 += array[quantVar31i] == old23[quantVar33j % 4] ? 1 : 0;
        }
      }
      assert !(begin <= quantVar31i && quantVar31i < end) || ((sum_14) == (sum_15));
    }
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= begin && begin < end && end <= array.length; 
      ensures array.length == \old(array.length); 
      ensures (\forall int i; begin <= i < end - 1; array[i] <= array[i + 1]); 
      ensures (\forall int i; begin <= i < end; ((\num_of int j; begin <= j < end; array[i] == array[j]) == (\num_of int j; begin <= j < end; array[i] == \old(array[j])))); 
      assignable array[begin .. end - 1]; 
   */

  public static void quickSortRec( 
  int[] array, int begin, int end) {
    int depth = 0;
    int depthLimit = (int)(2 * log(end - begin) / log(2)) + 3;
    quickSortRecImpl(array, begin, end, depth, depthLimit);
  }
  
  public static void quickSortRecImplVerf( 
  int[] array, int begin, int end, int depth, int depthLimit) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= begin && begin <= end && end <= array.length);
    }
    {
      CProver.assume(0 <= depth && depth <= depthLimit && depthLimit < Integer.MAX_VALUE);
    }
    int old24 = array.length;
    int[] old25 = new int[4];
    for (int i = begin; i <= end - 1; ++i) {
      for (int j = begin; j <= end - 1; ++j) {
        try {
          old25[j % 4] = array[j];
        } catch (java.lang.RuntimeException e) {
        }
      }
    }
    try {
      if (end - begin <= IS_THRESH || depth >= depthLimit) {
        insertionSort(array, begin, end);
        {
          throw new BlockQuickSort.ReturnException();
        }
      }
      int pivot = partition(array, begin, end);
      quickSortRecImpl(array, begin, pivot, depth + 1, depthLimit);
      quickSortRecImpl(array, pivot, end, depth + 1, depthLimit);
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old24;
    }
    {
      int quantVar34i = CProver.nondetInt();
      assert !(begin <= quantVar34i && quantVar34i < end - 1) || array[quantVar34i] <= array[quantVar34i + 1];
    }
    {
      int quantVar35i = CProver.nondetInt();
      int sum_16 = 0;
      int sum_17 = 0;
      if (!!(begin <= quantVar35i && quantVar35i < end)) {
        sum_16 = 0;
        for (int quantVar36j = begin; begin <= quantVar36j && end - 1 >= quantVar36j; ++quantVar36j) {
          sum_16 += array[quantVar35i] == array[quantVar36j] ? 1 : 0;
        }
        sum_17 = 0;
        for (int quantVar37j = begin; begin <= quantVar37j && end - 1 >= quantVar37j; ++quantVar37j) {
          sum_17 += array[quantVar35i] == old25[quantVar37j % 4] ? 1 : 0;
        }
      }
      assert !(begin <= quantVar35i && quantVar35i < end) || ((sum_16) == (sum_17));
    }
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= begin && begin <= end && end <= array.length; 
      requires 0 <= depth && depth <= depthLimit && depthLimit < Integer.MAX_VALUE; 
      ensures array.length == \old(array.length); 
      ensures (\forall int i; begin <= i < end - 1; array[i] <= array[i + 1]); 
      ensures (\forall int i; begin <= i < end; ((\num_of int j; begin <= j < end; array[i] == array[j]) == (\num_of int j; begin <= j < end; array[i] == \old(array[j])))); 
      assignable array[begin .. end - 1]; 
   */

  public static void quickSortRecImpl( 
  int[] array, int begin, int end, int depth, int depthLimit) {
    if (end - begin <= IS_THRESH || depth >= depthLimit) {
      insertionSort(array, begin, end);
      return;
    }
    int pivot = partition(array, begin, end);
    quickSortRecImpl(array, begin, pivot, depth + 1, depthLimit);
    quickSortRecImpl(array, pivot, end, depth + 1, depthLimit);
  }
  
  public static void insertionSortVerf( 
  int[] array, int begin, int end) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= begin && begin <= end && end <= array.length);
    }
    int old26 = array.length;
    int[] old27 = new int[4];
    for (int i = begin; i <= end - 1; ++i) {
      for (int j = begin; j <= end - 1; ++j) {
        try {
          old27[j % 4] = array[j];
        } catch (java.lang.RuntimeException e) {
        }
      }
    }
    try {
      for (int i = begin; i < end; ) {
        int j = i;
        while (j > begin && array[j - 1] > array[j]) {
          swap(array, j, j - 1);
          j--;
        }
        i++;
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old26;
    }
    {
      int quantVar38i = CProver.nondetInt();
      assert !(begin <= quantVar38i && quantVar38i < end - 1) || array[quantVar38i] <= array[quantVar38i + 1];
    }
    {
      int quantVar39i = CProver.nondetInt();
      int sum_18 = 0;
      int sum_19 = 0;
      if (!!(begin <= quantVar39i && quantVar39i < end)) {
        sum_18 = 0;
        for (int quantVar40j = begin; begin <= quantVar40j && end - 1 >= quantVar40j; ++quantVar40j) {
          sum_18 += array[quantVar39i] == array[quantVar40j] ? 1 : 0;
        }
        sum_19 = 0;
        for (int quantVar41j = begin; begin <= quantVar41j && end - 1 >= quantVar41j; ++quantVar41j) {
          sum_19 += array[quantVar39i] == old27[quantVar41j % 4] ? 1 : 0;
        }
      }
      assert !(begin <= quantVar39i && quantVar39i < end) || ((sum_18) == (sum_19));
    }
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= begin && begin <= end && end <= array.length; 
      ensures array.length == \old(array.length); 
      ensures (\forall int i; begin <= i < end - 1; array[i] <= array[i + 1]); 
      ensures (\forall int i; begin <= i < end; ((\num_of int j; begin <= j < end; array[i] == array[j]) == (\num_of int j; begin <= j < end; array[i] == \old(array[j])))); 
      assignable array[begin .. end - 1]; 
   */

  public static void insertionSort( 
  int[] array, int begin, int end) {
    for (int i = begin; i < end; i++) {
      int j = i;
      while (j > begin && array[j - 1] > array[j]) {
        swap(array, j, j - 1);
        j--;
      }
    }
  }
  
  public static void swapVerf( 
  int[] array, int i, int j) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= i && i < array.length);
    }
    {
      CProver.assume(0 <= j && j < array.length);
    }
    int old28 = array.length;
    int old29 = array[j];
    int old30 = array[i];
    try {
      int temp = array[i];
      assert !false;
      array[i] = array[j];
      assert !false;
      array[j] = temp;
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old28;
    }
    {
      {
        assert array[i] == old29;
        assert array[j] == old30;
      }
    }
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= i < array.length; 
      requires 0 <= j < array.length; 
      ensures array.length == \old(array.length); 
      ensures array[i] == \old(array[j]) && array[j] == \old(array[i]); 
      assignable array[i], array[j]; 
   */

  public static void swap( 
  int[] array, int i, int j) {
    int temp = array[i];
    array[i] = array[j];
    array[j] = temp;
  }
  
  public static void sortPairVerf(int i1, int i2,  
  int[] array) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= i1 && i1 < array.length);
    }
    {
      CProver.assume(0 <= i2 && i2 < array.length);
    }
    int old31 = array.length;
    int old32 = array[i1];
    int old33 = array[i2];
    try {
      if (array[i1] > array[i2]) {
        swap(array, i1, i2);
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old31;
    }
    {
      assert (old32 <= old33) ? (array[i1] == old32 && array[i2] == old33) : (array[i1] == old33 && array[i2] == old32);
    }
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= i1 && i1 < array.length; 
      requires 0 <= i2 && i2 < array.length; 
      ensures array.length == \old(array.length); 
      ensures (\old(array[i1]) <= \old(array[i2])) ? (array[i1] == \old(array[i1]) && array[i2] == \old(array[i2])) : (array[i1] == \old(array[i2]) && array[i2] == \old(array[i1])); 
      assignable array[i1], array[i2]; 
   */

  public static void sortPair(int i1, int i2,  
  int[] array) {
    if (array[i1] > array[i2]) {
      swap(array, i1, i2);
    }
  }
  
  public static int medianOf3Verf( 
  int[] array, int begin, int end) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= begin && begin < end && end <= array.length);
    }
    {
      CProver.assume(end - begin >= 3);
    }
    int old34 = array.length;
    int[] old35 = new int[4];
    for (int i = begin; i <= end - 1; ++i) {
      for (int j = begin; j <= end - 1; ++j) {
        try {
          old35[j % 4] = array[j];
        } catch (java.lang.RuntimeException e) {
        }
      }
    }
    int returnVar = 0;
    try {
      int mid = begin + ((end - begin) / 2);
      sortPair(begin, mid, array);
      sortPair(mid, end - 1, array);
      sortPair(begin, mid, array);
      {
        returnVar = mid;
        throw new BlockQuickSort.ReturnException();
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old34;
    }
    {
      assert returnVar == begin + ((end - begin) / 2);
    }
    {
      {
        assert array[begin] <= array[returnVar];
        assert array[returnVar] <= array[end - 1];
      }
    }
    {
      int quantVar42i = CProver.nondetInt();
      int sum_20 = 0;
      int sum_21 = 0;
      if (!!(begin <= quantVar42i && quantVar42i < end)) {
        sum_20 = 0;
        for (int quantVar43j = begin; begin <= quantVar43j && end - 1 >= quantVar43j; ++quantVar43j) {
          sum_20 += array[quantVar42i] == array[quantVar43j] ? 1 : 0;
        }
        sum_21 = 0;
        for (int quantVar44j = begin; begin <= quantVar44j && end - 1 >= quantVar44j; ++quantVar44j) {
          sum_21 += array[quantVar42i] == old35[quantVar44j % 4] ? 1 : 0;
        }
      }
      assert !(begin <= quantVar42i && quantVar42i < end) || ((sum_20) == (sum_21));
    }
    return returnVar;
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= begin && begin < end && end <= array.length; 
      requires end - begin >= 3; 
      ensures array.length == \old(array.length); 
      ensures \result == begin + ((end - begin) / 2); 
      ensures array[begin] <= array[\result] && array[\result] <= array[end - 1]; 
      ensures (\forall int i; begin <= i < end; ((\num_of int j; begin <= j < end; array[i] == array[j]) == (\num_of int j; begin <= j < end; array[i] == \old(array[j])))); 
      assignable array[begin], array[begin + ((end - begin) / 2)], array[end - 1]; 
   */

  public static int medianOf3( 
  int[] array, int begin, int end) {
    int mid = begin + ((end - begin) / 2);
    sortPair(begin, mid, array);
    sortPair(mid, end - 1, array);
    sortPair(begin, mid, array);
    return mid;
  }
  
  public static int partitionVerf( 
  int[] array, int begin, int end) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= begin && begin < end && end <= array.length);
    }
    {
      CProver.assume(end - begin >= 3);
    }
    int old36 = array.length;
    int[] old37 = new int[4];
    for (int i = begin; i <= end - 1; ++i) {
      for (int j = begin; j <= end - 1; ++j) {
        try {
          old37[j % 4] = array[j];
        } catch (java.lang.RuntimeException e) {
        }
      }
    }
    int returnVar = 0;
    try {
      int mid = medianOf3(array, begin, end);
      {
        returnVar = hoareBlockPartition(array, begin + 1, end - 1, mid);
        throw new BlockQuickSort.ReturnException();
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old36;
    }
    {
      {
        assert begin <= returnVar;
        assert returnVar < end;
      }
    }
    {
      int quantVar45i = CProver.nondetInt();
      assert !(begin <= quantVar45i && quantVar45i <= returnVar) || array[quantVar45i] <= array[returnVar];
    }
    {
      int quantVar46i = CProver.nondetInt();
      assert !(returnVar <= quantVar46i && quantVar46i < end) || array[returnVar] <= array[quantVar46i];
    }
    {
      int quantVar47i = CProver.nondetInt();
      int sum_22 = 0;
      int sum_23 = 0;
      if (!!(begin <= quantVar47i && quantVar47i < end)) {
        sum_22 = 0;
        for (int quantVar48j = begin; begin <= quantVar48j && end - 1 >= quantVar48j; ++quantVar48j) {
          sum_22 += array[quantVar47i] == array[quantVar48j] ? 1 : 0;
        }
        sum_23 = 0;
        for (int quantVar49j = begin; begin <= quantVar49j && end - 1 >= quantVar49j; ++quantVar49j) {
          sum_23 += array[quantVar47i] == old37[quantVar49j % 4] ? 1 : 0;
        }
      }
      assert !(begin <= quantVar47i && quantVar47i < end) || ((sum_22) == (sum_23));
    }
    return returnVar;
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= begin && begin < end && end <= array.length; 
      requires end - begin >= 3; 
      ensures array.length == \old(array.length); 
      ensures begin <= \result && \result < end; 
      ensures (\forall int i; begin <= i <= \result; array[i] <= array[\result]); 
      ensures (\forall int i; \result <= i < end; array[\result] <= array[i]); 
      ensures (\forall int i; begin <= i < end; ((\num_of int j; begin <= j < end; array[i] == array[j]) == (\num_of int j; begin <= j < end; array[i] == \old(array[j])))); 
      assignable array[begin .. end - 1]; 
   */

  public static int partition( 
  int[] array, int begin, int end) {
    int mid = medianOf3(array, begin, end);
    return hoareBlockPartition(array, begin + 1, end - 1, mid);
  }
  
   
  public static double logVerf(double a) {
    {
      CProver.assume(a > 0);
    }
    double returnVar = 0.0;
    try {
      if (a <= 0) {
        throw new IllegalArgumentException("Argument must be positive.");
      }
      int iterations = 1000;
      double result = 0.0;
      double x = (a - 1) / (a + 1);
      for (int i = 0; i < iterations; ) {
        int exponent = 2 * i + 1;
        result += power(x, exponent) / exponent;
        i++;
      }
      {
        returnVar = 2 * result;
        throw new BlockQuickSort.ReturnException();
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      {
        assert 1 <= returnVar;
        assert returnVar < 100;
      }
    }
    return returnVar;
  }
    /*@
      requires a > 0; 
      ensures 1 <= \result && \result < 100; 
   */

   
  public static double log(double a) {
    if (a <= 0) {
      throw new IllegalArgumentException("Argument must be positive.");
    }
    int iterations = 1000;
    double result = 0.0;
    double x = (a - 1) / (a + 1);
    for (int i = 0; i < iterations; i++) {
      int exponent = 2 * i + 1;
      result += power(x, exponent) / exponent;
    }
    return 2 * result;
  }
  
  private static double powerVerf(double base, int exponent) {
    double returnVar = 0.0;
    try {
      double result = 1.0;
      for (int i = 0; i < exponent; ) {
        result *= base;
        i++;
      }
      {
        returnVar = result;
        throw new BlockQuickSort.ReturnException();
      }
    } catch (BlockQuickSort.ReturnException ex) {
    } catch (java.lang.RuntimeException e) {
      CProver.assume(false);
    }
    return returnVar;
  }
    /*@
    private behavior
      signals_only java.lang.RuntimeException; 
   */

  private static double power(double base, int exponent) {
    double result = 1.0;
    for (int i = 0; i < exponent; i++) {
      result *= base;
    }
    return result;
  }
  
   
  public static int minVerf(int a, int b) {
    int returnVar = 0;
    try {
      {
        returnVar = a < b ? a : b;
        throw new BlockQuickSort.ReturnException();
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert returnVar == (a < b ? a : b);
    }
    return returnVar;
  }
    /*@
    public normal_behavior
      ensures \result == (a < b ? a : b); 
   */

   
  public static int min(int a, int b) {
    return a < b ? a : b;
  }
  
   
  public static int maxVerf(int a, int b) {
    int returnVar = 0;
    try {
      {
        returnVar = a > b ? a : b;
        throw new BlockQuickSort.ReturnException();
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert returnVar == (a > b ? a : b);
    }
    return returnVar;
  }
    /*@
    public normal_behavior
      ensures \result == (a > b ? a : b); 
   */

   
  public static int max(int a, int b) {
    return a > b ? a : b;
  }
  
   
  public static boolean permutationVerf( 
  int[] array1,  
  int[] array2, int begin, int end) {
    {
      CProver.assume(array1 != null);
    }
    {
      CProver.assume(array2 != null);
    }
    {
      CProver.assume(0 <= begin && begin <= end && end <= array1.length);
    }
    {
      CProver.assume(array1.length == array2.length);
    }
    int old38 = array1.length;
    int old39 = array2.length;
    boolean returnVar = true;
    try {
      for (int i = begin; i < end; ) {
        int count1 = 0;
        int count2 = 0;
        for (int j = begin; j < end; ) {
          if (array1[i] == array1[j]) {
            count1++;
          }
          if (array1[i] == array2[j]) {
            count2++;
          }
          j++;
        }
        if (count1 != count2) {
          {
            returnVar = false;
            throw new BlockQuickSort.ReturnException();
          }
        }
        i++;
      }
      {
        returnVar = true;
        throw new BlockQuickSort.ReturnException();
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array1.length == old38;
    }
    {
      assert array2.length == old39;
    }
    {
      int quantVar50i = CProver.nondetInt();
      int sum_24 = 0;
      int sum_25 = 0;
      int sum_26 = 0;
      int sum_27 = 0;
      boolean b_11 = false;
      if (!!returnVar) {
        if (!!(begin <= quantVar50i && quantVar50i < end)) {
          sum_24 = 0;
          for (int quantVar51j = begin; begin <= quantVar51j && end - 1 >= quantVar51j; ++quantVar51j) {
            sum_24 += array1[quantVar50i] == array1[quantVar51j] ? 1 : 0;
          }
          sum_25 = 0;
          for (int quantVar52j = begin; begin <= quantVar52j && end - 1 >= quantVar52j; ++quantVar52j) {
            sum_25 += array1[quantVar50i] == array2[quantVar52j] ? 1 : 0;
          }
        }
      }
      if (!returnVar || (!(begin <= quantVar50i && quantVar50i < end) || ((sum_24) == (sum_25)))) {
        for (int quantVar53i = begin; begin <= quantVar53i && end - 1 >= quantVar53i; ++quantVar53i) {
          sum_26 = 0;
          for (int quantVar54j = begin; begin <= quantVar54j && end - 1 >= quantVar54j; ++quantVar54j) {
            sum_26 += array1[quantVar53i] == array1[quantVar54j] ? 1 : 0;
          }
          sum_27 = 0;
          for (int quantVar55j = begin; begin <= quantVar55j && end - 1 >= quantVar55j; ++quantVar55j) {
            sum_27 += array1[quantVar53i] == array2[quantVar55j] ? 1 : 0;
          }
          b_11 = b_11 || !((sum_26) == (sum_27));
        }
      }
      {
        assert !returnVar || (!(begin <= quantVar50i && quantVar50i < end) || ((sum_24) == (sum_25)));
        assert b_11 || returnVar;
      }
    }
    return returnVar;
  }
    /*@
    public normal_behavior
      requires array1 != null; 
      requires array2 != null; 
      requires 0 <= begin && begin <= end && end <= array1.length; 
      requires array1.length == array2.length; 
      ensures array1.length == \old(array1.length); 
      ensures array2.length == \old(array2.length); 
      ensures \result == (\forall int i; begin <= i < end; ((\num_of int j; begin <= j < end; array1[i] == array1[j]) == (\num_of int j; begin <= j < end; array1[i] == array2[j]))); 
   */

   
  public static boolean permutation( 
  int[] array1,  
  int[] array2, int begin, int end) {
    //@ loop_invariant begin <= i <= end;
    //@ loop_invariant (\forall int j; begin <= j < i; (\num_of int k; begin <= k < end; array1[j] == array1[k]) == (\num_of int k; begin <= k < end; array1[j] == array2[k]));
    //@ loop_modifies i;
    //@ loop_decreases end - i;
    for (int i = begin; i < end; i++) {
      int count1 = 0;
      int count2 = 0;
      //@ loop_invariant begin <= j <= end;
      //@ loop_invariant count1 == (\num_of int k; begin <= k < j; array1[i] == array1[k]);
      //@ loop_invariant count2 == (\num_of int k; begin <= k < j; array1[i] == array2[k]);
      //@ loop_modifies j, count1, count2;
      //@ loop_decreases end - j;
      for (int j = begin; j < end; j++) {
        if (array1[i] == array1[j]) {
          count1++;
        }
        if (array1[i] == array2[j]) {
          count2++;
        }
      }
      if (count1 != count2) {
        return false;
      }
    }
    return true;
  }
  
  public static class ReturnException extends java.lang.RuntimeException {
  }
}