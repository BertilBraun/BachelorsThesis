
import org.cprover.CProver;

public class BlockQuickSort {
    /*@
    public behavior
      assignable \nothing; 
      signals () false; 
   */

  public static BlockQuickSort BlockQuickSortSymb() {
    return new BlockQuickSort();

  }
  
  public static int hoareBlockPartitionSymb( 
  int[] array, int originalBegin, int originalEnd, int pivotPosition) {
    assert array != null;
    assert array.length < 500;
    assert (originalEnd - originalBegin) >= 1;
    assert (originalEnd - originalBegin) <= 500;
    assert 0 <= originalBegin;
    assert originalBegin < originalEnd;
    assert originalEnd <= array.length;
    assert originalBegin <= pivotPosition;
    assert pivotPosition < originalEnd;
    int returnVar = CProver.nondetInt();
    int old0 = array.length;
    int old1 = array[pivotPosition];
    int[] old2 = new int[1];
    for (int i = originalBegin; i <= originalEnd - 1; ++i) {
      for (int j = originalBegin; j <= originalEnd - 1; ++j) {
        try {
          old2[j % 1] = array[j];

        } catch (java.lang.RuntimeException e) {

        }

      }

    }
    if (array != null) {
      for (int __tmpVar__0 = originalBegin; __tmpVar__0 <= originalEnd - 1; ++__tmpVar__0) {
        array[__tmpVar__0] = CProver.nondetInt();

      }

    }
    CProver.assume(array.length == old0);
    CProver.assume(originalBegin <= returnVar && returnVar < originalEnd);
    CProver.assume(array[returnVar] == old1);
    boolean b_0 = true;
    for (int quantVar0i = originalBegin; originalBegin <= quantVar0i && returnVar >= quantVar0i; ++quantVar0i) {
      b_0 = b_0 && array[quantVar0i] <= array[returnVar];

    }
    CProver.assume((b_0));
    boolean b_1 = true;
    for (int quantVar1i = returnVar; returnVar <= quantVar1i && originalEnd - 1 >= quantVar1i; ++quantVar1i) {
      b_1 = b_1 && array[returnVar] <= array[quantVar1i];

    }
    CProver.assume((b_1));
    int sum_0 = 0;
    int sum_1 = 0;
    boolean b_2 = true;
    for (int quantVar2i = originalBegin; originalBegin <= quantVar2i && originalEnd - 1 >= quantVar2i; ++quantVar2i) {
      for (int quantVar3j = originalBegin; originalBegin <= quantVar3j && originalEnd - 1 >= quantVar3j; ++quantVar3j) {
        sum_0 += array[quantVar2i] == array[quantVar3j] ? 1 : 0;

      }
      for (int quantVar4j = originalBegin; originalBegin <= quantVar4j && originalEnd - 1 >= quantVar4j; ++quantVar4j) {
        sum_1 += array[quantVar2i] == old2[quantVar4j % 1] ? 1 : 0;

      }
      b_2 = b_2 && ((sum_0) == (sum_1));

    }
    CProver.assume((b_2));
    return returnVar;

  }
  
  public static void quickSortRecImplSymb( 
  int[] array, int begin, int end, int depth, int depthLimit) {
    assert array != null;
    assert array.length < 500;
    assert 0 <= begin;
    assert begin <= end;
    assert end <= array.length;
    assert 0 <= depth;
    assert depth <= depthLimit;
    assert depthLimit < 500;
    int old3 = array.length;
    int[] old4 = new int[1];
    for (int i = begin; i <= end - 1; ++i) {
      for (int j = begin; j <= end - 1; ++j) {
        try {
          old4[j % 1] = array[j];

        } catch (java.lang.RuntimeException e) {

        }

      }

    }
    if (array != null) {
      for (int __tmpVar__0 = begin; __tmpVar__0 <= end - 1; ++__tmpVar__0) {
        array[__tmpVar__0] = CProver.nondetInt();

      }

    }
    CProver.assume(array.length == old3);
    boolean b_3 = true;
    for (int quantVar5i = begin; begin <= quantVar5i && end - 1 - 1 >= quantVar5i; ++quantVar5i) {
      b_3 = b_3 && array[quantVar5i] <= array[quantVar5i + 1];

    }
    CProver.assume((b_3));
    int sum_2 = 0;
    int sum_3 = 0;
    boolean b_4 = true;
    for (int quantVar6i = begin; begin <= quantVar6i && end - 1 >= quantVar6i; ++quantVar6i) {
      for (int quantVar7j = begin; begin <= quantVar7j && end - 1 >= quantVar7j; ++quantVar7j) {
        sum_2 += array[quantVar6i] == array[quantVar7j] ? 1 : 0;

      }
      for (int quantVar8j = begin; begin <= quantVar8j && end - 1 >= quantVar8j; ++quantVar8j) {
        sum_3 += array[quantVar6i] == old4[quantVar8j % 1] ? 1 : 0;

      }
      b_4 = b_4 && ((sum_2) == (sum_3));

    }
    CProver.assume((b_4));

  }
  
  public static void insertionSortSymb( 
  int[] array, int begin, int end) {
    assert array != null;
    assert array.length < 500;
    assert 0 <= begin;
    assert begin <= end;
    assert end <= array.length;
    int old5 = array.length;
    int[] old6 = new int[1];
    for (int i = begin; i <= end - 1; ++i) {
      for (int j = begin; j <= end - 1; ++j) {
        try {
          old6[j % 1] = array[j];

        } catch (java.lang.RuntimeException e) {

        }

      }

    }
    if (array != null) {
      for (int __tmpVar__0 = begin; __tmpVar__0 <= end - 1; ++__tmpVar__0) {
        array[__tmpVar__0] = CProver.nondetInt();

      }

    }
    CProver.assume(array.length == old5);
    boolean b_5 = true;
    for (int quantVar9i = begin; begin <= quantVar9i && end - 1 - 1 >= quantVar9i; ++quantVar9i) {
      b_5 = b_5 && array[quantVar9i] <= array[quantVar9i + 1];

    }
    CProver.assume((b_5));
    int sum_4 = 0;
    int sum_5 = 0;
    boolean b_6 = true;
    for (int quantVar10i = begin; begin <= quantVar10i && end - 1 >= quantVar10i; ++quantVar10i) {
      for (int quantVar11j = begin; begin <= quantVar11j && end - 1 >= quantVar11j; ++quantVar11j) {
        sum_4 += array[quantVar10i] == array[quantVar11j] ? 1 : 0;

      }
      for (int quantVar12j = begin; begin <= quantVar12j && end - 1 >= quantVar12j; ++quantVar12j) {
        sum_5 += array[quantVar10i] == old6[quantVar12j % 1] ? 1 : 0;

      }
      b_6 = b_6 && ((sum_4) == (sum_5));

    }
    CProver.assume((b_6));

  }
  
  public static void swapSymb( 
  int[] array, int i, int j) {
    assert array != null;
    assert array.length < 500;
    assert 0 <= i;
    assert i < array.length;
    assert 0 <= j;
    assert j < array.length;
    int old7 = array.length;
    int old8 = array[j];
    int old9 = array[i];
    array[i] = CProver.nondetInt();
    array[j] = CProver.nondetInt();
    CProver.assume(array.length == old7);
    CProver.assume(array[i] == old8 && array[j] == old9);

  }
  
  public static void sortPairSymb(int i1, int i2,  
  int[] array) {
    assert array != null;
    assert array.length < 500;
    assert 0 <= i1;
    assert i1 < array.length;
    assert 0 <= i2;
    assert i2 < array.length;
    int old10 = array.length;
    int old11 = array[i1];
    int old12 = array[i2];
    array[i1] = CProver.nondetInt();
    array[i2] = CProver.nondetInt();
    CProver.assume(array.length == old10);
    CProver.assume((old11 <= old12) ? (array[i1] == old11 && array[i2] == old12) : (array[i1] == old12 && array[i2] == old11));

  }
  
  public static int medianOf3Symb( 
  int[] array, int begin, int end) {
    assert array != null;
    assert array.length < 500;
    assert end - begin >= 3;
    assert 0 <= begin;
    assert begin < end;
    assert end <= array.length;
    int returnVar = CProver.nondetInt();
    int old13 = array.length;
    int[] old14 = new int[1];
    for (int i = begin; i <= end - 1; ++i) {
      for (int j = begin; j <= end - 1; ++j) {
        try {
          old14[j % 1] = array[j];

        } catch (java.lang.RuntimeException e) {

        }

      }

    }
    array[begin] = CProver.nondetInt();
    array[begin + ((end - begin) / 2)] = CProver.nondetInt();
    array[end - 1] = CProver.nondetInt();
    CProver.assume(array.length == old13);
    CProver.assume(returnVar == begin + ((end - begin) / 2));
    CProver.assume(array[begin] <= array[returnVar] && array[returnVar] <= array[end - 1]);
    int sum_6 = 0;
    int sum_7 = 0;
    boolean b_7 = true;
    for (int quantVar13i = begin; begin <= quantVar13i && end - 1 >= quantVar13i; ++quantVar13i) {
      for (int quantVar14j = begin; begin <= quantVar14j && end - 1 >= quantVar14j; ++quantVar14j) {
        sum_6 += array[quantVar13i] == array[quantVar14j] ? 1 : 0;

      }
      for (int quantVar15j = begin; begin <= quantVar15j && end - 1 >= quantVar15j; ++quantVar15j) {
        sum_7 += array[quantVar13i] == old14[quantVar15j % 1] ? 1 : 0;

      }
      b_7 = b_7 && ((sum_6) == (sum_7));

    }
    CProver.assume((b_7));
    return returnVar;

  }
  
  public static int partitionSymb( 
  int[] array, int begin, int end) {
    assert array != null;
    assert array.length < 500;
    assert end - begin >= 3;
    assert 0 <= begin;
    assert begin < end;
    assert end <= array.length;
    int returnVar = CProver.nondetInt();
    int old15 = array.length;
    int[] old16 = new int[1];
    for (int i = begin; i <= end - 1; ++i) {
      for (int j = begin; j <= end - 1; ++j) {
        try {
          old16[j % 1] = array[j];

        } catch (java.lang.RuntimeException e) {

        }

      }

    }
    if (array != null) {
      for (int __tmpVar__0 = begin; __tmpVar__0 <= end - 1; ++__tmpVar__0) {
        array[__tmpVar__0] = CProver.nondetInt();

      }

    }
    CProver.assume(array.length == old15);
    CProver.assume(begin <= returnVar && returnVar < end);
    boolean b_8 = true;
    for (int quantVar16i = begin; begin <= quantVar16i && returnVar >= quantVar16i; ++quantVar16i) {
      b_8 = b_8 && array[quantVar16i] <= array[returnVar];

    }
    CProver.assume((b_8));
    boolean b_9 = true;
    for (int quantVar17i = returnVar; returnVar <= quantVar17i && end - 1 >= quantVar17i; ++quantVar17i) {
      b_9 = b_9 && array[returnVar] <= array[quantVar17i];

    }
    CProver.assume((b_9));
    int sum_8 = 0;
    int sum_9 = 0;
    boolean b_10 = true;
    for (int quantVar18i = begin; begin <= quantVar18i && end - 1 >= quantVar18i; ++quantVar18i) {
      for (int quantVar19j = begin; begin <= quantVar19j && end - 1 >= quantVar19j; ++quantVar19j) {
        sum_8 += array[quantVar18i] == array[quantVar19j] ? 1 : 0;

      }
      for (int quantVar20j = begin; begin <= quantVar20j && end - 1 >= quantVar20j; ++quantVar20j) {
        sum_9 += array[quantVar18i] == old16[quantVar20j % 1] ? 1 : 0;

      }
      b_10 = b_10 && ((sum_8) == (sum_9));

    }
    CProver.assume((b_10));
    return returnVar;

  }
  
  public static double logSymb(double a) {
    assert a > 0;
    double returnVar = CProver.nondetDouble();
    CProver.assume(1 <= returnVar && returnVar < 100);
    return returnVar;

  }
  
  public static int minSymb(int a, int b) {
    int returnVar = CProver.nondetInt();
    CProver.assume(returnVar == (a < b ? a : b));
    return returnVar;

  }
  
  public static int maxSymb(int a, int b) {
    int returnVar = CProver.nondetInt();
    CProver.assume(returnVar == (a > b ? a : b));
    return returnVar;

  }
  
  public static boolean permutationSymb( 
  int[] array1,  
  int[] array2, int begin, int end) {
    assert array1 != null;
    assert array2 != null;
    assert 0 <= begin;
    assert begin <= end;
    assert end <= array1.length;
    assert array1.length == array2.length;
    boolean returnVar = CProver.nondetBoolean();
    int old17 = array1.length;
    int old18 = array2.length;
    CProver.assume(array1.length == old17);
    CProver.assume(array2.length == old18);
    int sum_10 = 0;
    int sum_11 = 0;
    boolean b_11 = true;
    int quantVar24i = CProver.nondetInt();
    int sum_12 = 0;
    int sum_13 = 0;
    if (!!returnVar) {
      for (int quantVar21i = begin; begin <= quantVar21i && end - 1 >= quantVar21i; ++quantVar21i) {
        for (int quantVar22j = begin; begin <= quantVar22j && end - 1 >= quantVar22j; ++quantVar22j) {
          sum_10 += array1[quantVar21i] == array1[quantVar22j] ? 1 : 0;

        }
        for (int quantVar23j = begin; begin <= quantVar23j && end - 1 >= quantVar23j; ++quantVar23j) {
          sum_11 += array1[quantVar21i] == array2[quantVar23j] ? 1 : 0;

        }
        b_11 = b_11 && ((sum_10) == (sum_11));

      }

    }
    if (!returnVar || (b_11)) {
      if (begin <= quantVar24i && quantVar24i < end) {
        for (int quantVar25j = begin; begin <= quantVar25j && end - 1 >= quantVar25j; ++quantVar25j) {
          sum_12 += array1[quantVar24i] == array1[quantVar25j] ? 1 : 0;

        }
        for (int quantVar26j = begin; begin <= quantVar26j && end - 1 >= quantVar26j; ++quantVar26j) {
          sum_13 += array1[quantVar24i] == array2[quantVar26j] ? 1 : 0;

        }

      }

    }
    CProver.assume((!returnVar || (b_11)) && (begin <= quantVar24i && quantVar24i < end && !((sum_12) == (sum_13)) || returnVar));
    return returnVar;

  }
  
  public BlockQuickSort() {
    {

    }

  }
  private static final int BLOCKSIZE = 2;
  private static final int IS_THRESH = 3;
  private static final int STACK_SIZE = 80;
  
  public static int hoareBlockPartitionVerf( 
  int[] array, int originalBegin, int originalEnd, int pivotPosition) {
    {
      CProver.assume(array != null && array.length < 500);

    }
    {
      CProver.assume((originalEnd - originalBegin) >= 1 && (originalEnd - originalBegin) <= 500);

    }
    {
      CProver.assume(0 <= originalBegin && originalBegin < originalEnd && originalEnd <= array.length);

    }
    {
      CProver.assume(originalBegin <= pivotPosition && pivotPosition < originalEnd);

    }
    int old19 = array.length;
    int old20 = array[pivotPosition];
    int[] old21 = new int[1];
    int[] old22 = array;
    for (int i = originalBegin; i <= originalEnd - 1; ++i) {
      for (int j = originalBegin; j <= originalEnd - 1; ++j) {
        try {
          old21[j % 1] = array[j];

        } catch (java.lang.RuntimeException e) {

        }

      }

    }
    int returnVar = 0;
    try {
      int[] $$param0 = null;
      int $$param1 = 0;
      int $$param2 = 0;
      int $$param3 = 0;
      int $$param4 = 0;
      int[] $$param5 = null;
      int $$param6 = 0;
      int $$param7 = 0;
      int $$param8 = 0;
      int $$param9 = 0;
      int $$param10 = 0;
      int $$param11 = 0;
      int $$param12 = 0;
      int $$param13 = 0;
      int[] $$param14 = null;
      int $$param15 = 0;
      int $$param16 = 0;
      int[] $$param17 = null;
      int $$param18 = 0;
      int $$param19 = 0;
      int[] $$param20 = null;
      int $$param21 = 0;
      int $$param22 = 0;
      int[] $$param23 = null;
      int $$param24 = 0;
      int $$param25 = 0;
      int[] $$param26 = null;
      int $$param27 = 0;
      int $$param28 = 0;
      int[] $$param29 = null;
      int $$param30 = 0;
      int $$param31 = 0;
       
      int[] indexL = new int[BLOCKSIZE];
       
      int[] indexR = new int[BLOCKSIZE];
      int begin = originalBegin;
      int end = originalEnd;
      int last = end - 1;
      int pivot = array[pivotPosition];
      $$param0 = array;
      $$param1 = pivotPosition;
      $$param2 = last;
      assert !(true && (old22 != $$param0 || $$param1 > originalEnd - 1 || $$param1 < originalBegin)) : "Illegal assignment to array[i] conflicting with assignables array[originalBegin .. originalEnd - 1]";
      assert !(true && (old22 != $$param0 || $$param2 > originalEnd - 1 || $$param2 < originalBegin)) : "Illegal assignment to array[j] conflicting with assignables array[originalBegin .. originalEnd - 1]";
      swapSymb($$param0, $$param1, $$param2);
      assert !false;
      pivotPosition = last;
      last--;
      int numLeft = 0;
      int numRight = 0;
      int startLeft = 0;
      int startRight = 0;
      int num = 0;
      if (last - begin + 1 > 2 * BLOCKSIZE) {
        int old23 = array[pivotPosition];
        int[] old24 = new int[1];
        int[] old25 = array;
        for (int i = originalBegin; i <= originalEnd - 1; ++i) {
          for (int j = originalBegin; j <= originalEnd - 1; ++j) {
            try {
              old24[j % 1] = array[j];

            } catch (java.lang.RuntimeException e) {

            }

          }

        }
        {
          boolean b_12 = false;
          boolean b_13 = false;
          int quantVar34i = CProver.nondetInt();
          int quantVar35i = CProver.nondetInt();
          int quantVar36i = CProver.nondetInt();
          int sum_16 = 0;
          int quantVar38i = CProver.nondetInt();
          int quantVar39i = CProver.nondetInt();
          int quantVar40i = CProver.nondetInt();
          int sum_17 = 0;
          int quantVar42i = CProver.nondetInt();
          int quantVar43i = CProver.nondetInt();
          int quantVar44i = CProver.nondetInt();
          int quantVar45i = CProver.nondetInt();
          int quantVar46i = CProver.nondetInt();
          int sum_18 = 0;
          int sum_19 = 0;
          {
            assert originalBegin <= begin;
            assert begin <= last;
            assert last < originalEnd - 1;

          }
          {
            assert 0 <= numLeft;
            assert numLeft <= BLOCKSIZE;

          }
          {
            assert 0 <= numRight;
            assert numRight <= BLOCKSIZE;

          }
          {
            assert 0 <= startLeft;
            assert startLeft <= BLOCKSIZE;
            assert startLeft + numLeft <= BLOCKSIZE;

          }
          {
            assert 0 <= startRight;
            assert startRight <= BLOCKSIZE;
            assert startRight + numRight <= BLOCKSIZE;

          }
          {
            assert 0 <= num;
            assert num <= BLOCKSIZE;

          }
          assert numRight == 0 || numLeft == 0;
          assert array[originalEnd - 1] == old23;
          for (int quantVar32i = 0; 0 <= quantVar32i && (originalEnd - originalBegin) - 1 >= quantVar32i; ++quantVar32i) {
            b_12 = b_12 || begin == originalBegin + quantVar32i * BLOCKSIZE;

          }
          assert b_12;
          for (int quantVar33i = 0; 0 <= quantVar33i && (originalEnd - originalBegin) - 1 >= quantVar33i; ++quantVar33i) {
            b_13 = b_13 || last == originalEnd - 2 - quantVar33i * BLOCKSIZE;

          }
          assert b_13;
          assert !(0 <= quantVar34i && quantVar34i < BLOCKSIZE) || 0 <= indexL[quantVar34i] && indexL[quantVar34i] < BLOCKSIZE;
          assert !(0 <= quantVar35i && quantVar35i < numLeft) || indexL[startLeft + quantVar35i] < last - begin && pivot <= array[begin + indexL[startLeft + quantVar35i]];
          assert !(0 <= quantVar36i && quantVar36i < startLeft + numLeft - 1) || indexL[quantVar36i] < indexL[quantVar36i + 1];
          if (!!(numLeft != 0)) {
            for (int quantVar37i = startLeft; startLeft <= quantVar37i && BLOCKSIZE - 1 >= quantVar37i; ++quantVar37i) {
              sum_16 += pivot <= array[begin + quantVar37i] ? 1 : 0;

            }

          }
          assert !(numLeft != 0) || numLeft == (sum_16);
          assert !(0 <= quantVar38i && quantVar38i < BLOCKSIZE) || 0 <= indexR[quantVar38i] && indexR[quantVar38i] < BLOCKSIZE;
          assert !(0 <= quantVar39i && quantVar39i < numRight) || indexR[startRight + quantVar39i] < last - begin && array[last - indexR[startRight + quantVar39i]] <= pivot;
          assert !(0 <= quantVar40i && quantVar40i < startRight + numRight - 1) || indexR[quantVar40i] < indexR[quantVar40i + 1];
          if (!!(numRight != 0)) {
            for (int quantVar41i = startRight; startRight <= quantVar41i && BLOCKSIZE - 1 >= quantVar41i; ++quantVar41i) {
              sum_17 += array[last - quantVar41i] <= pivot ? 1 : 0;

            }

          }
          assert !(numRight != 0) || numRight == (sum_17);
          assert !(numLeft == 0) || (!(originalBegin <= quantVar42i && quantVar42i < begin) || array[quantVar42i] <= pivot);
          assert !(numLeft != 0) || (!(originalBegin <= quantVar43i && quantVar43i < begin + indexL[startLeft]) || array[quantVar43i] <= pivot);
          assert !(numRight == 0) || (!(last < quantVar44i && quantVar44i < originalEnd) || pivot <= array[quantVar44i]);
          assert !(numRight != 0) || (!(last - indexR[startRight] < quantVar45i && quantVar45i < originalEnd) || pivot <= array[quantVar45i]);
          if (!!(originalBegin <= quantVar46i && quantVar46i < originalEnd)) {
            for (int quantVar47j = originalBegin; originalBegin <= quantVar47j && originalEnd - 1 >= quantVar47j; ++quantVar47j) {
              sum_18 += array[quantVar46i] == array[quantVar47j] ? 1 : 0;

            }
            for (int quantVar48j = originalBegin; originalBegin <= quantVar48j && originalEnd - 1 >= quantVar48j; ++quantVar48j) {
              sum_19 += array[quantVar46i] == old24[quantVar48j % 1] ? 1 : 0;

            }

          }
          assert !(originalBegin <= quantVar46i && quantVar46i < originalEnd) || (sum_18) == (sum_19);

        }
        assert !(false && (old25 != array || min(begin + BLOCKSIZE - 1, originalEnd - 2) > originalEnd - 1 || max(begin, originalBegin) < originalBegin)) : "Illegal assignment to array[max(begin, originalBegin) .. min(begin + BLOCKSIZE - 1, originalEnd - 2)] conflicting with assiganbles + array[originalBegin .. originalEnd - 1]";
        assert !(false && (old25 != array || min(last, originalEnd - 2) > originalEnd - 1 || max(last - BLOCKSIZE - 1, originalBegin) < originalBegin)) : "Illegal assignment to array[max(last - BLOCKSIZE - 1, originalBegin) .. min(last, originalEnd - 2)] conflicting with assiganbles + array[originalBegin .. originalEnd - 1]";
        assert !(false && (old25 != indexL || BLOCKSIZE - 1 > originalEnd - 1 || 0 < originalBegin)) : "Illegal assignment to indexL[0 .. BLOCKSIZE - 1] conflicting with assiganbles + array[originalBegin .. originalEnd - 1]";
        assert !(false && (old25 != indexR || BLOCKSIZE - 1 > originalEnd - 1 || 0 < originalBegin)) : "Illegal assignment to indexR[0 .. BLOCKSIZE - 1] conflicting with assiganbles + array[originalBegin .. originalEnd - 1]";
        num = CProver.nondetInt();
        startRight = CProver.nondetInt();
        startLeft = CProver.nondetInt();
        numRight = CProver.nondetInt();
        numLeft = CProver.nondetInt();
        begin = CProver.nondetInt();
        last = CProver.nondetInt();
        if (indexR != null) {
          for (int __tmpVar__0 = 0; __tmpVar__0 <= BLOCKSIZE - 1; ++__tmpVar__0) {
            indexR[__tmpVar__0] = CProver.nondetInt();

          }

        }
        if (indexL != null) {
          for (int __tmpVar__0 = 0; __tmpVar__0 <= BLOCKSIZE - 1; ++__tmpVar__0) {
            indexL[__tmpVar__0] = CProver.nondetInt();

          }

        }
        if (array != null) {
          for (int __tmpVar__0 = max(last - BLOCKSIZE - 1, originalBegin); __tmpVar__0 <= minSymb($$param8, $$param9); ++__tmpVar__0) {
            array[__tmpVar__0] = CProver.nondetInt();

          }

        }
        if (array != null) {
          for (int __tmpVar__0 = max(begin, originalBegin); __tmpVar__0 <= minSymb($$param10, $$param11); ++__tmpVar__0) {
            array[__tmpVar__0] = CProver.nondetInt();

          }

        }
        int oldDecreasesClauseValue0 = last - begin;
        {
          int quantVar49i = CProver.nondetInt();
          int quantVar50i = CProver.nondetInt();
          boolean b_14 = true;
          boolean b_15 = true;
          boolean b_16 = true;
          int sum_20 = 0;
          boolean b_17 = true;
          boolean b_18 = true;
          boolean b_19 = true;
          int sum_21 = 0;
          boolean b_20 = true;
          boolean b_21 = true;
          boolean b_22 = true;
          boolean b_23 = true;
          int sum_22 = 0;
          int sum_23 = 0;
          boolean b_24 = true;
          CProver.assume(originalBegin <= begin && begin <= last && last < originalEnd - 1);
          CProver.assume(0 <= numLeft && numLeft <= BLOCKSIZE);
          CProver.assume(0 <= numRight && numRight <= BLOCKSIZE);
          CProver.assume(0 <= startLeft && startLeft <= BLOCKSIZE && startLeft + numLeft <= BLOCKSIZE);
          CProver.assume(0 <= startRight && startRight <= BLOCKSIZE && startRight + numRight <= BLOCKSIZE);
          CProver.assume(0 <= num && num <= BLOCKSIZE);
          CProver.assume(numRight == 0 || numLeft == 0);
          CProver.assume(array[originalEnd - 1] == old23);
          CProver.assume((0 <= quantVar49i && quantVar49i < (originalEnd - originalBegin) && begin == originalBegin + quantVar49i * BLOCKSIZE));
          CProver.assume((0 <= quantVar50i && quantVar50i < (originalEnd - originalBegin) && last == originalEnd - 2 - quantVar50i * BLOCKSIZE));
          for (int quantVar51i = 0; 0 <= quantVar51i && BLOCKSIZE - 1 >= quantVar51i; ++quantVar51i) {
            b_14 = b_14 && (0 <= indexL[quantVar51i] && indexL[quantVar51i] < BLOCKSIZE);

          }
          CProver.assume((b_14));
          for (int quantVar52i = 0; 0 <= quantVar52i && numLeft - 1 >= quantVar52i; ++quantVar52i) {
            b_15 = b_15 && (indexL[startLeft + quantVar52i] < last - begin && pivot <= array[begin + indexL[startLeft + quantVar52i]]);

          }
          CProver.assume((b_15));
          for (int quantVar53i = 0; 0 <= quantVar53i && startLeft + numLeft - 1 - 1 >= quantVar53i; ++quantVar53i) {
            b_16 = b_16 && indexL[quantVar53i] < indexL[quantVar53i + 1];

          }
          CProver.assume((b_16));
          if (!!(numLeft != 0)) {
            for (int quantVar54i = startLeft; startLeft <= quantVar54i && BLOCKSIZE - 1 >= quantVar54i; ++quantVar54i) {
              sum_20 += pivot <= array[begin + quantVar54i] ? 1 : 0;

            }

          }
          CProver.assume(!(numLeft != 0) || numLeft == (sum_20));
          for (int quantVar55i = 0; 0 <= quantVar55i && BLOCKSIZE - 1 >= quantVar55i; ++quantVar55i) {
            b_17 = b_17 && (0 <= indexR[quantVar55i] && indexR[quantVar55i] < BLOCKSIZE);

          }
          CProver.assume((b_17));
          for (int quantVar56i = 0; 0 <= quantVar56i && numRight - 1 >= quantVar56i; ++quantVar56i) {
            b_18 = b_18 && (indexR[startRight + quantVar56i] < last - begin && array[last - indexR[startRight + quantVar56i]] <= pivot);

          }
          CProver.assume((b_18));
          for (int quantVar57i = 0; 0 <= quantVar57i && startRight + numRight - 1 - 1 >= quantVar57i; ++quantVar57i) {
            b_19 = b_19 && indexR[quantVar57i] < indexR[quantVar57i + 1];

          }
          CProver.assume((b_19));
          if (!!(numRight != 0)) {
            for (int quantVar58i = startRight; startRight <= quantVar58i && BLOCKSIZE - 1 >= quantVar58i; ++quantVar58i) {
              sum_21 += array[last - quantVar58i] <= pivot ? 1 : 0;

            }

          }
          CProver.assume(!(numRight != 0) || numRight == (sum_21));
          if (!!(numLeft == 0)) {
            for (int quantVar59i = originalBegin; originalBegin <= quantVar59i && begin - 1 >= quantVar59i; ++quantVar59i) {
              b_20 = b_20 && array[quantVar59i] <= pivot;

            }

          }
          CProver.assume(!(numLeft == 0) || (b_20));
          if (!!(numLeft != 0)) {
            for (int quantVar60i = originalBegin; originalBegin <= quantVar60i && begin + indexL[startLeft] - 1 >= quantVar60i; ++quantVar60i) {
              b_21 = b_21 && array[quantVar60i] <= pivot;

            }

          }
          CProver.assume(!(numLeft != 0) || (b_21));
          if (!!(numRight == 0)) {
            for (int quantVar61i = last + 1; last + 1 <= quantVar61i && originalEnd - 1 >= quantVar61i; ++quantVar61i) {
              b_22 = b_22 && pivot <= array[quantVar61i];

            }

          }
          CProver.assume(!(numRight == 0) || (b_22));
          if (!!(numRight != 0)) {
            for (int quantVar62i = last - indexR[startRight] + 1; last - indexR[startRight] + 1 <= quantVar62i && originalEnd - 1 >= quantVar62i; ++quantVar62i) {
              b_23 = b_23 && pivot <= array[quantVar62i];

            }

          }
          CProver.assume(!(numRight != 0) || (b_23));
          for (int quantVar63i = originalBegin; originalBegin <= quantVar63i && originalEnd - 1 >= quantVar63i; ++quantVar63i) {
            for (int quantVar64j = originalBegin; originalBegin <= quantVar64j && originalEnd - 1 >= quantVar64j; ++quantVar64j) {
              sum_22 += array[quantVar63i] == array[quantVar64j] ? 1 : 0;

            }
            for (int quantVar65j = originalBegin; originalBegin <= quantVar65j && originalEnd - 1 >= quantVar65j; ++quantVar65j) {
              sum_23 += array[quantVar63i] == old24[quantVar65j % 1] ? 1 : 0;

            }
            b_24 = b_24 && (sum_22) == (sum_23);

          }
          CProver.assume((b_24));

        }
        if (last - begin + 1 > 2 * BLOCKSIZE) {
          if (numLeft == 0) {
            assert !false;
            startLeft = 0;
            {
              int j = 0;
              int[] old26 = array;
              {
                int sum_24 = 0;
                int quantVar67k = CProver.nondetInt();
                int quantVar68k = CProver.nondetInt();
                {
                  assert 0 <= j;
                  assert j <= BLOCKSIZE;

                }
                for (int quantVar66k = 0; 0 <= quantVar66k && j - 1 >= quantVar66k; ++quantVar66k) {
                  sum_24 += pivot <= array[begin + quantVar66k] ? 1 : 0;

                }
                assert numLeft == (sum_24);
                assert !(0 <= quantVar67k && quantVar67k < numLeft) || 0 <= indexL[quantVar67k] && indexL[quantVar67k] < j && pivot <= array[begin + indexL[quantVar67k]];
                assert !(0 <= quantVar68k && quantVar68k < numLeft - 1) || indexL[quantVar68k] < indexL[quantVar68k + 1];

              }
              assert !(false && (old26 != indexL || BLOCKSIZE - 1 > min(begin + BLOCKSIZE - 1, originalEnd - 2) || 0 < max(begin, originalBegin)) && (array != indexL || BLOCKSIZE - 1 > min(last, originalEnd - 2) || 0 < max(last - BLOCKSIZE - 1, originalBegin)) && (indexL != indexL || BLOCKSIZE - 1 > BLOCKSIZE - 1 || 0 < 0) && (indexR != indexL || BLOCKSIZE - 1 > BLOCKSIZE - 1 || 0 < 0)) : "Illegal assignment to indexL[0 .. BLOCKSIZE - 1] conflicting with assiganbles + array[max(begin, originalBegin) .. min(begin + BLOCKSIZE - 1, originalEnd - 2)], array[max(last - BLOCKSIZE - 1, originalBegin) .. min(last, originalEnd - 2)], indexL[0 .. BLOCKSIZE - 1], indexR[0 .. BLOCKSIZE - 1], last, begin, numLeft, numRight, startLeft, startRight, num";
              j = CProver.nondetInt();
              numLeft = CProver.nondetInt();
              if (indexL != null) {
                for (int __tmpVar__0 = 0; __tmpVar__0 <= BLOCKSIZE - 1; ++__tmpVar__0) {
                  indexL[__tmpVar__0] = CProver.nondetInt();

                }

              }
              int oldDecreasesClauseValue1 = BLOCKSIZE - j;
              {
                int sum_25 = 0;
                boolean b_25 = true;
                boolean b_26 = true;
                CProver.assume(0 <= j && j <= BLOCKSIZE);
                for (int quantVar69k = 0; 0 <= quantVar69k && j - 1 >= quantVar69k; ++quantVar69k) {
                  sum_25 += pivot <= array[begin + quantVar69k] ? 1 : 0;

                }
                CProver.assume(numLeft == (sum_25));
                for (int quantVar70k = 0; 0 <= quantVar70k && numLeft - 1 >= quantVar70k; ++quantVar70k) {
                  b_25 = b_25 && (0 <= indexL[quantVar70k] && indexL[quantVar70k] < j && pivot <= array[begin + indexL[quantVar70k]]);

                }
                CProver.assume((b_25));
                for (int quantVar71k = 0; 0 <= quantVar71k && numLeft - 1 - 1 >= quantVar71k; ++quantVar71k) {
                  b_26 = b_26 && indexL[quantVar71k] < indexL[quantVar71k + 1];

                }
                CProver.assume((b_26));

              }
              if (j < BLOCKSIZE) {
                assert !false;
                indexL[numLeft] = j;
                numLeft += array[begin + j] >= pivot ? 1 : 0;
                j++;
                {
                  int sum_26 = 0;
                  int quantVar73k = CProver.nondetInt();
                  int quantVar74k = CProver.nondetInt();
                  {
                    assert 0 <= j;
                    assert j <= BLOCKSIZE;

                  }
                  for (int quantVar72k = 0; 0 <= quantVar72k && j - 1 >= quantVar72k; ++quantVar72k) {
                    sum_26 += pivot <= array[begin + quantVar72k] ? 1 : 0;

                  }
                  assert numLeft == (sum_26);
                  assert !(0 <= quantVar73k && quantVar73k < numLeft) || 0 <= indexL[quantVar73k] && indexL[quantVar73k] < j && pivot <= array[begin + indexL[quantVar73k]];
                  assert !(0 <= quantVar74k && quantVar74k < numLeft - 1) || indexL[quantVar74k] < indexL[quantVar74k + 1];

                }
                {
                  assert BLOCKSIZE - j >= 0;
                  assert BLOCKSIZE - j < oldDecreasesClauseValue1;

                }
                CProver.assume(false);

              }

            }

          }
          if (numRight == 0) {
            assert !false;
            startRight = 0;
            {
              int j = 0;
              int[] old27 = array;
              {
                int sum_27 = 0;
                int quantVar76k = CProver.nondetInt();
                int quantVar77k = CProver.nondetInt();
                {
                  assert 0 <= j;
                  assert j <= BLOCKSIZE;

                }
                for (int quantVar75k = 0; 0 <= quantVar75k && j - 1 >= quantVar75k; ++quantVar75k) {
                  sum_27 += array[last - quantVar75k] <= pivot ? 1 : 0;

                }
                assert numRight == (sum_27);
                assert !(0 <= quantVar76k && quantVar76k < numRight) || 0 <= indexR[quantVar76k] && indexR[quantVar76k] < j && array[last - indexR[quantVar76k]] <= pivot;
                assert !(0 <= quantVar77k && quantVar77k < numRight - 1) || indexR[quantVar77k] < indexR[quantVar77k + 1];

              }
              assert !(false && (old27 != indexR || BLOCKSIZE - 1 > min(begin + BLOCKSIZE - 1, originalEnd - 2) || 0 < max(begin, originalBegin)) && (array != indexR || BLOCKSIZE - 1 > min(last, originalEnd - 2) || 0 < max(last - BLOCKSIZE - 1, originalBegin)) && (indexL != indexR || BLOCKSIZE - 1 > BLOCKSIZE - 1 || 0 < 0) && (indexR != indexR || BLOCKSIZE - 1 > BLOCKSIZE - 1 || 0 < 0)) : "Illegal assignment to indexR[0 .. BLOCKSIZE - 1] conflicting with assiganbles + array[max(begin, originalBegin) .. min(begin + BLOCKSIZE - 1, originalEnd - 2)], array[max(last - BLOCKSIZE - 1, originalBegin) .. min(last, originalEnd - 2)], indexL[0 .. BLOCKSIZE - 1], indexR[0 .. BLOCKSIZE - 1], last, begin, numLeft, numRight, startLeft, startRight, num";
              j = CProver.nondetInt();
              numRight = CProver.nondetInt();
              if (indexR != null) {
                for (int __tmpVar__0 = 0; __tmpVar__0 <= BLOCKSIZE - 1; ++__tmpVar__0) {
                  indexR[__tmpVar__0] = CProver.nondetInt();

                }

              }
              int oldDecreasesClauseValue2 = BLOCKSIZE - j;
              {
                int sum_28 = 0;
                boolean b_27 = true;
                boolean b_28 = true;
                CProver.assume(0 <= j && j <= BLOCKSIZE);
                for (int quantVar78k = 0; 0 <= quantVar78k && j - 1 >= quantVar78k; ++quantVar78k) {
                  sum_28 += array[last - quantVar78k] <= pivot ? 1 : 0;

                }
                CProver.assume(numRight == (sum_28));
                for (int quantVar79k = 0; 0 <= quantVar79k && numRight - 1 >= quantVar79k; ++quantVar79k) {
                  b_27 = b_27 && (0 <= indexR[quantVar79k] && indexR[quantVar79k] < j && array[last - indexR[quantVar79k]] <= pivot);

                }
                CProver.assume((b_27));
                for (int quantVar80k = 0; 0 <= quantVar80k && numRight - 1 - 1 >= quantVar80k; ++quantVar80k) {
                  b_28 = b_28 && indexR[quantVar80k] < indexR[quantVar80k + 1];

                }
                CProver.assume((b_28));

              }
              if (j < BLOCKSIZE) {
                assert !false;
                indexR[numRight] = j;
                numRight += pivot >= array[last - j] ? 1 : 0;
                j++;
                {
                  int sum_29 = 0;
                  int quantVar82k = CProver.nondetInt();
                  int quantVar83k = CProver.nondetInt();
                  {
                    assert 0 <= j;
                    assert j <= BLOCKSIZE;

                  }
                  for (int quantVar81k = 0; 0 <= quantVar81k && j - 1 >= quantVar81k; ++quantVar81k) {
                    sum_29 += array[last - quantVar81k] <= pivot ? 1 : 0;

                  }
                  assert numRight == (sum_29);
                  assert !(0 <= quantVar82k && quantVar82k < numRight) || 0 <= indexR[quantVar82k] && indexR[quantVar82k] < j && array[last - indexR[quantVar82k]] <= pivot;
                  assert !(0 <= quantVar83k && quantVar83k < numRight - 1) || indexR[quantVar83k] < indexR[quantVar83k + 1];

                }
                {
                  assert BLOCKSIZE - j >= 0;
                  assert BLOCKSIZE - j < oldDecreasesClauseValue2;

                }
                CProver.assume(false);

              }

            }

          }
          assert !false;
          $$param3 = numLeft;
          $$param4 = numRight;
          num = minSymb($$param3, $$param4);
          if (num > 0) {
            {
              int j = 0;
              int[] old28 = new int[1];
              int[] old29 = array;
              for (int i = begin; i <= last + 1 - 1; ++i) {
                for (int k = begin; k <= last + 1 - 1; ++k) {
                  try {
                    old28[k % 1] = array[k];

                  } catch (java.lang.RuntimeException e) {

                  }

                }

              }
              {
                int quantVar84i = CProver.nondetInt();
                int quantVar85i = CProver.nondetInt();
                int quantVar86i = CProver.nondetInt();
                int quantVar87i = CProver.nondetInt();
                int quantVar88i = CProver.nondetInt();
                int quantVar89i = CProver.nondetInt();
                int quantVar90i = CProver.nondetInt();
                int sum_30 = 0;
                int sum_31 = 0;
                {
                  assert 0 <= j;
                  assert j <= num;

                }
                assert !(originalBegin <= quantVar84i && quantVar84i < begin + indexL[startLeft]) || array[quantVar84i] <= pivot;
                assert !(j > 0) || (!(originalBegin <= quantVar85i && quantVar85i <= begin + indexL[startLeft + j - 1]) || array[quantVar85i] <= pivot);
                assert !(last - indexR[startRight] < quantVar86i && quantVar86i < originalEnd) || pivot <= array[quantVar86i];
                assert !(j > 0) || (!(last - indexR[startRight + j - 1] <= quantVar87i && quantVar87i < originalEnd) || pivot <= array[quantVar87i]);
                assert !(startLeft + j <= quantVar88i && quantVar88i < startLeft + numLeft) || pivot <= array[begin + indexL[quantVar88i]];
                assert !(startRight + j <= quantVar89i && quantVar89i < startRight + numRight) || array[last - indexR[quantVar89i]] <= pivot;
                if (!!(begin <= quantVar90i && quantVar90i < last + 1)) {
                  for (int quantVar91k = begin; begin <= quantVar91k && last + 1 - 1 >= quantVar91k; ++quantVar91k) {
                    sum_30 += array[quantVar90i] == array[quantVar91k] ? 1 : 0;

                  }
                  for (int quantVar92k = begin; begin <= quantVar92k && last + 1 - 1 >= quantVar92k; ++quantVar92k) {
                    sum_31 += array[quantVar90i] == old28[quantVar92k % 1] ? 1 : 0;

                  }

                }
                assert !(begin <= quantVar90i && quantVar90i < last + 1) || (sum_30) == (sum_31);

              }
              assert !(false && (old29 != array || begin + indexL[startLeft + num - 1] > min(begin + BLOCKSIZE - 1, originalEnd - 2) || begin + indexL[startLeft] < max(begin, originalBegin)) && (array != array || begin + indexL[startLeft + num - 1] > min(last, originalEnd - 2) || begin + indexL[startLeft] < max(last - BLOCKSIZE - 1, originalBegin)) && (indexL != array || begin + indexL[startLeft + num - 1] > BLOCKSIZE - 1 || begin + indexL[startLeft] < 0) && (indexR != array || begin + indexL[startLeft + num - 1] > BLOCKSIZE - 1 || begin + indexL[startLeft] < 0)) : "Illegal assignment to array[begin + indexL[startLeft] .. begin + indexL[startLeft + num - 1]] conflicting with assiganbles + array[max(begin, originalBegin) .. min(begin + BLOCKSIZE - 1, originalEnd - 2)], array[max(last - BLOCKSIZE - 1, originalBegin) .. min(last, originalEnd - 2)], indexL[0 .. BLOCKSIZE - 1], indexR[0 .. BLOCKSIZE - 1], last, begin, numLeft, numRight, startLeft, startRight, num";
              assert !(false && (old29 != array || last - indexR[startRight] > min(begin + BLOCKSIZE - 1, originalEnd - 2) || last - indexR[startRight + num - 1] < max(begin, originalBegin)) && (array != array || last - indexR[startRight] > min(last, originalEnd - 2) || last - indexR[startRight + num - 1] < max(last - BLOCKSIZE - 1, originalBegin)) && (indexL != array || last - indexR[startRight] > BLOCKSIZE - 1 || last - indexR[startRight + num - 1] < 0) && (indexR != array || last - indexR[startRight] > BLOCKSIZE - 1 || last - indexR[startRight + num - 1] < 0)) : "Illegal assignment to array[last - indexR[startRight + num - 1] .. last - indexR[startRight]] conflicting with assiganbles + array[max(begin, originalBegin) .. min(begin + BLOCKSIZE - 1, originalEnd - 2)], array[max(last - BLOCKSIZE - 1, originalBegin) .. min(last, originalEnd - 2)], indexL[0 .. BLOCKSIZE - 1], indexR[0 .. BLOCKSIZE - 1], last, begin, numLeft, numRight, startLeft, startRight, num";
              j = CProver.nondetInt();
              if (array != null) {
                for (int __tmpVar__0 = last - indexR[startRight + num - 1]; __tmpVar__0 <= last - indexR[startRight]; ++__tmpVar__0) {
                  array[__tmpVar__0] = CProver.nondetInt();

                }

              }
              if (array != null) {
                for (int __tmpVar__0 = begin + indexL[startLeft]; __tmpVar__0 <= begin + indexL[startLeft + num - 1]; ++__tmpVar__0) {
                  array[__tmpVar__0] = CProver.nondetInt();

                }

              }
              int oldDecreasesClauseValue3 = num - j;
              {
                boolean b_29 = true;
                boolean b_30 = true;
                boolean b_31 = true;
                boolean b_32 = true;
                boolean b_33 = true;
                boolean b_34 = true;
                int sum_32 = 0;
                int sum_33 = 0;
                boolean b_35 = true;
                CProver.assume(0 <= j && j <= num);
                for (int quantVar93i = originalBegin; originalBegin <= quantVar93i && begin + indexL[startLeft] - 1 >= quantVar93i; ++quantVar93i) {
                  b_29 = b_29 && array[quantVar93i] <= pivot;

                }
                CProver.assume((b_29));
                if (!!(j > 0)) {
                  for (int quantVar94i = originalBegin; originalBegin <= quantVar94i && begin + indexL[startLeft + j - 1] >= quantVar94i; ++quantVar94i) {
                    b_30 = b_30 && array[quantVar94i] <= pivot;

                  }

                }
                CProver.assume(!(j > 0) || (b_30));
                for (int quantVar95i = last - indexR[startRight] + 1; last - indexR[startRight] + 1 <= quantVar95i && originalEnd - 1 >= quantVar95i; ++quantVar95i) {
                  b_31 = b_31 && pivot <= array[quantVar95i];

                }
                CProver.assume((b_31));
                if (!!(j > 0)) {
                  for (int quantVar96i = last - indexR[startRight + j - 1]; last - indexR[startRight + j - 1] <= quantVar96i && originalEnd - 1 >= quantVar96i; ++quantVar96i) {
                    b_32 = b_32 && pivot <= array[quantVar96i];

                  }

                }
                CProver.assume(!(j > 0) || (b_32));
                for (int quantVar97i = startLeft + j; startLeft + j <= quantVar97i && startLeft + numLeft - 1 >= quantVar97i; ++quantVar97i) {
                  b_33 = b_33 && pivot <= array[begin + indexL[quantVar97i]];

                }
                CProver.assume((b_33));
                for (int quantVar98i = startRight + j; startRight + j <= quantVar98i && startRight + numRight - 1 >= quantVar98i; ++quantVar98i) {
                  b_34 = b_34 && array[last - indexR[quantVar98i]] <= pivot;

                }
                CProver.assume((b_34));
                for (int quantVar99i = begin; begin <= quantVar99i && last + 1 - 1 >= quantVar99i; ++quantVar99i) {
                  for (int quantVar100k = begin; begin <= quantVar100k && last + 1 - 1 >= quantVar100k; ++quantVar100k) {
                    sum_32 += array[quantVar99i] == array[quantVar100k] ? 1 : 0;

                  }
                  for (int quantVar101k = begin; begin <= quantVar101k && last + 1 - 1 >= quantVar101k; ++quantVar101k) {
                    sum_33 += array[quantVar99i] == old28[quantVar101k % 1] ? 1 : 0;

                  }
                  b_35 = b_35 && (sum_32) == (sum_33);

                }
                CProver.assume((b_35));

              }
              if (j < num) {
                $$param5 = array;
                $$param6 = begin + indexL[startLeft + j];
                $$param7 = last - indexR[startRight + j];
                assert !(true && (old29 != $$param5 || $$param6 > begin + indexL[startLeft + num - 1] || $$param6 < begin + indexL[startLeft]) && ($$param5 != $$param5 || $$param6 > last - indexR[startRight] || $$param6 < last - indexR[startRight + num - 1])) : "Illegal assignment to array[i] conflicting with assignables array[begin + indexL[startLeft] .. begin + indexL[startLeft + num - 1]], array[last - indexR[startRight + num - 1] .. last - indexR[startRight]], j, j";
                assert !(true && (old29 != $$param5 || $$param7 > begin + indexL[startLeft + num - 1] || $$param7 < begin + indexL[startLeft]) && ($$param5 != $$param5 || $$param7 > last - indexR[startRight] || $$param7 < last - indexR[startRight + num - 1])) : "Illegal assignment to array[j] conflicting with assignables array[begin + indexL[startLeft] .. begin + indexL[startLeft + num - 1]], array[last - indexR[startRight + num - 1] .. last - indexR[startRight]], j, j";
                swapSymb($$param5, $$param6, $$param7);
                j++;
                {
                  int quantVar102i = CProver.nondetInt();
                  int quantVar103i = CProver.nondetInt();
                  int quantVar104i = CProver.nondetInt();
                  int quantVar105i = CProver.nondetInt();
                  int quantVar106i = CProver.nondetInt();
                  int quantVar107i = CProver.nondetInt();
                  int quantVar108i = CProver.nondetInt();
                  int sum_34 = 0;
                  int sum_35 = 0;
                  {
                    assert 0 <= j;
                    assert j <= num;

                  }
                  assert !(originalBegin <= quantVar102i && quantVar102i < begin + indexL[startLeft]) || array[quantVar102i] <= pivot;
                  assert !(j > 0) || (!(originalBegin <= quantVar103i && quantVar103i <= begin + indexL[startLeft + j - 1]) || array[quantVar103i] <= pivot);
                  assert !(last - indexR[startRight] < quantVar104i && quantVar104i < originalEnd) || pivot <= array[quantVar104i];
                  assert !(j > 0) || (!(last - indexR[startRight + j - 1] <= quantVar105i && quantVar105i < originalEnd) || pivot <= array[quantVar105i]);
                  assert !(startLeft + j <= quantVar106i && quantVar106i < startLeft + numLeft) || pivot <= array[begin + indexL[quantVar106i]];
                  assert !(startRight + j <= quantVar107i && quantVar107i < startRight + numRight) || array[last - indexR[quantVar107i]] <= pivot;
                  if (!!(begin <= quantVar108i && quantVar108i < last + 1)) {
                    for (int quantVar109k = begin; begin <= quantVar109k && last + 1 - 1 >= quantVar109k; ++quantVar109k) {
                      sum_34 += array[quantVar108i] == array[quantVar109k] ? 1 : 0;

                    }
                    for (int quantVar110k = begin; begin <= quantVar110k && last + 1 - 1 >= quantVar110k; ++quantVar110k) {
                      sum_35 += array[quantVar108i] == old28[quantVar110k % 1] ? 1 : 0;

                    }

                  }
                  assert !(begin <= quantVar108i && quantVar108i < last + 1) || (sum_34) == (sum_35);

                }
                {
                  assert num - j >= 0;
                  assert num - j < oldDecreasesClauseValue3;

                }
                CProver.assume(false);

              }

            }

          }
          numLeft -= num;
          numRight -= num;
          startLeft += num;
          startRight += num;
          begin += (numLeft == 0) ? BLOCKSIZE : 0;
          last -= (numRight == 0) ? BLOCKSIZE : 0;
          {
            boolean b_36 = false;
            boolean b_37 = false;
            int quantVar113i = CProver.nondetInt();
            int quantVar114i = CProver.nondetInt();
            int quantVar115i = CProver.nondetInt();
            int sum_36 = 0;
            int quantVar117i = CProver.nondetInt();
            int quantVar118i = CProver.nondetInt();
            int quantVar119i = CProver.nondetInt();
            int sum_37 = 0;
            int quantVar121i = CProver.nondetInt();
            int quantVar122i = CProver.nondetInt();
            int quantVar123i = CProver.nondetInt();
            int quantVar124i = CProver.nondetInt();
            int quantVar125i = CProver.nondetInt();
            int sum_38 = 0;
            int sum_39 = 0;
            {
              assert originalBegin <= begin;
              assert begin <= last;
              assert last < originalEnd - 1;

            }
            {
              assert 0 <= numLeft;
              assert numLeft <= BLOCKSIZE;

            }
            {
              assert 0 <= numRight;
              assert numRight <= BLOCKSIZE;

            }
            {
              assert 0 <= startLeft;
              assert startLeft <= BLOCKSIZE;
              assert startLeft + numLeft <= BLOCKSIZE;

            }
            {
              assert 0 <= startRight;
              assert startRight <= BLOCKSIZE;
              assert startRight + numRight <= BLOCKSIZE;

            }
            {
              assert 0 <= num;
              assert num <= BLOCKSIZE;

            }
            assert numRight == 0 || numLeft == 0;
            assert array[originalEnd - 1] == old23;
            for (int quantVar111i = 0; 0 <= quantVar111i && (originalEnd - originalBegin) - 1 >= quantVar111i; ++quantVar111i) {
              b_36 = b_36 || begin == originalBegin + quantVar111i * BLOCKSIZE;

            }
            assert b_36;
            for (int quantVar112i = 0; 0 <= quantVar112i && (originalEnd - originalBegin) - 1 >= quantVar112i; ++quantVar112i) {
              b_37 = b_37 || last == originalEnd - 2 - quantVar112i * BLOCKSIZE;

            }
            assert b_37;
            assert !(0 <= quantVar113i && quantVar113i < BLOCKSIZE) || 0 <= indexL[quantVar113i] && indexL[quantVar113i] < BLOCKSIZE;
            assert !(0 <= quantVar114i && quantVar114i < numLeft) || indexL[startLeft + quantVar114i] < last - begin && pivot <= array[begin + indexL[startLeft + quantVar114i]];
            assert !(0 <= quantVar115i && quantVar115i < startLeft + numLeft - 1) || indexL[quantVar115i] < indexL[quantVar115i + 1];
            if (!!(numLeft != 0)) {
              for (int quantVar116i = startLeft; startLeft <= quantVar116i && BLOCKSIZE - 1 >= quantVar116i; ++quantVar116i) {
                sum_36 += pivot <= array[begin + quantVar116i] ? 1 : 0;

              }

            }
            assert !(numLeft != 0) || numLeft == (sum_36);
            assert !(0 <= quantVar117i && quantVar117i < BLOCKSIZE) || 0 <= indexR[quantVar117i] && indexR[quantVar117i] < BLOCKSIZE;
            assert !(0 <= quantVar118i && quantVar118i < numRight) || indexR[startRight + quantVar118i] < last - begin && array[last - indexR[startRight + quantVar118i]] <= pivot;
            assert !(0 <= quantVar119i && quantVar119i < startRight + numRight - 1) || indexR[quantVar119i] < indexR[quantVar119i + 1];
            if (!!(numRight != 0)) {
              for (int quantVar120i = startRight; startRight <= quantVar120i && BLOCKSIZE - 1 >= quantVar120i; ++quantVar120i) {
                sum_37 += array[last - quantVar120i] <= pivot ? 1 : 0;

              }

            }
            assert !(numRight != 0) || numRight == (sum_37);
            assert !(numLeft == 0) || (!(originalBegin <= quantVar121i && quantVar121i < begin) || array[quantVar121i] <= pivot);
            assert !(numLeft != 0) || (!(originalBegin <= quantVar122i && quantVar122i < begin + indexL[startLeft]) || array[quantVar122i] <= pivot);
            assert !(numRight == 0) || (!(last < quantVar123i && quantVar123i < originalEnd) || pivot <= array[quantVar123i]);
            assert !(numRight != 0) || (!(last - indexR[startRight] < quantVar124i && quantVar124i < originalEnd) || pivot <= array[quantVar124i]);
            if (!!(originalBegin <= quantVar125i && quantVar125i < originalEnd)) {
              for (int quantVar126j = originalBegin; originalBegin <= quantVar126j && originalEnd - 1 >= quantVar126j; ++quantVar126j) {
                sum_38 += array[quantVar125i] == array[quantVar126j] ? 1 : 0;

              }
              for (int quantVar127j = originalBegin; originalBegin <= quantVar127j && originalEnd - 1 >= quantVar127j; ++quantVar127j) {
                sum_39 += array[quantVar125i] == old24[quantVar127j % 1] ? 1 : 0;

              }

            }
            assert !(originalBegin <= quantVar125i && quantVar125i < originalEnd) || (sum_38) == (sum_39);

          }
          {
            assert last - begin >= 0;
            assert last - begin < oldDecreasesClauseValue0;

          }
          CProver.assume(false);

        }

      }
      int shiftR = 0;
      int shiftL = 0;
      if (numRight == 0 && numLeft == 0) {
        assert !false;
        shiftL = ((last - begin) + 1) / 2;
        assert !false;
        shiftR = (last - begin) + 1 - shiftL;
        assert !false;
        startLeft = 0;
        assert !false;
        startRight = 0;
        {
          int j = 0;
          int[] old30 = array;
          {
            int sum_40 = 0;
            int sum_41 = 0;
            int quantVar130k = CProver.nondetInt();
            int quantVar131k = CProver.nondetInt();
            int quantVar132k = CProver.nondetInt();
            int quantVar133k = CProver.nondetInt();
            {
              assert 0 <= j;
              assert j <= shiftL;

            }
            {
              assert 0 <= numLeft;
              assert numLeft <= j;

            }
            {
              assert 0 <= numRight;
              assert numRight <= j;

            }
            for (int quantVar128k = 0; 0 <= quantVar128k && j - 1 >= quantVar128k; ++quantVar128k) {
              sum_40 += pivot <= array[begin + quantVar128k] ? 1 : 0;

            }
            assert numLeft == (sum_40);
            for (int quantVar129k = 0; 0 <= quantVar129k && j - 1 >= quantVar129k; ++quantVar129k) {
              sum_41 += array[last - quantVar129k] <= pivot ? 1 : 0;

            }
            assert numRight == (sum_41);
            assert !(0 <= quantVar130k && quantVar130k < numLeft) || 0 <= indexL[quantVar130k] && indexL[quantVar130k] < j && pivot <= array[begin + indexL[quantVar130k]];
            assert !(0 <= quantVar131k && quantVar131k < numRight) || 0 <= indexR[quantVar131k] && indexR[quantVar131k] < j && array[last - indexR[quantVar131k]] <= pivot;
            assert !(0 <= quantVar132k && quantVar132k < numLeft - 1) || indexL[quantVar132k] < indexL[quantVar132k + 1];
            assert !(0 <= quantVar133k && quantVar133k < numRight - 1) || indexR[quantVar133k] < indexR[quantVar133k + 1];

          }
          assert !(false && (old30 != indexL || shiftL - 1 > originalEnd - 1 || 0 < originalBegin)) : "Illegal assignment to indexL[0 .. shiftL - 1] conflicting with assiganbles + array[originalBegin .. originalEnd - 1]";
          assert !(false && (old30 != indexR || shiftL - 1 > originalEnd - 1 || 0 < originalBegin)) : "Illegal assignment to indexR[0 .. shiftL - 1] conflicting with assiganbles + array[originalBegin .. originalEnd - 1]";
          j = CProver.nondetInt();
          numRight = CProver.nondetInt();
          numLeft = CProver.nondetInt();
          if (indexR != null) {
            for (int __tmpVar__0 = 0; __tmpVar__0 <= shiftL - 1; ++__tmpVar__0) {
              indexR[__tmpVar__0] = CProver.nondetInt();

            }

          }
          if (indexL != null) {
            for (int __tmpVar__0 = 0; __tmpVar__0 <= shiftL - 1; ++__tmpVar__0) {
              indexL[__tmpVar__0] = CProver.nondetInt();

            }

          }
          int oldDecreasesClauseValue4 = shiftL - j;
          {
            int sum_42 = 0;
            int sum_43 = 0;
            boolean b_38 = true;
            boolean b_39 = true;
            boolean b_40 = true;
            boolean b_41 = true;
            CProver.assume(0 <= j && j <= shiftL);
            CProver.assume(0 <= numLeft && numLeft <= j);
            CProver.assume(0 <= numRight && numRight <= j);
            for (int quantVar134k = 0; 0 <= quantVar134k && j - 1 >= quantVar134k; ++quantVar134k) {
              sum_42 += pivot <= array[begin + quantVar134k] ? 1 : 0;

            }
            CProver.assume(numLeft == (sum_42));
            for (int quantVar135k = 0; 0 <= quantVar135k && j - 1 >= quantVar135k; ++quantVar135k) {
              sum_43 += array[last - quantVar135k] <= pivot ? 1 : 0;

            }
            CProver.assume(numRight == (sum_43));
            for (int quantVar136k = 0; 0 <= quantVar136k && numLeft - 1 >= quantVar136k; ++quantVar136k) {
              b_38 = b_38 && (0 <= indexL[quantVar136k] && indexL[quantVar136k] < j && pivot <= array[begin + indexL[quantVar136k]]);

            }
            CProver.assume((b_38));
            for (int quantVar137k = 0; 0 <= quantVar137k && numRight - 1 >= quantVar137k; ++quantVar137k) {
              b_39 = b_39 && (0 <= indexR[quantVar137k] && indexR[quantVar137k] < j && array[last - indexR[quantVar137k]] <= pivot);

            }
            CProver.assume((b_39));
            for (int quantVar138k = 0; 0 <= quantVar138k && numLeft - 1 - 1 >= quantVar138k; ++quantVar138k) {
              b_40 = b_40 && indexL[quantVar138k] < indexL[quantVar138k + 1];

            }
            CProver.assume((b_40));
            for (int quantVar139k = 0; 0 <= quantVar139k && numRight - 1 - 1 >= quantVar139k; ++quantVar139k) {
              b_41 = b_41 && indexR[quantVar139k] < indexR[quantVar139k + 1];

            }
            CProver.assume((b_41));

          }
          if (j < shiftL) {
            assert !false;
            indexL[numLeft] = j;
            numLeft += array[begin + j] >= pivot ? 1 : 0;
            assert !false;
            indexR[numRight] = j;
            numRight += pivot >= array[last - j] ? 1 : 0;
            j++;
            {
              int sum_44 = 0;
              int sum_45 = 0;
              int quantVar142k = CProver.nondetInt();
              int quantVar143k = CProver.nondetInt();
              int quantVar144k = CProver.nondetInt();
              int quantVar145k = CProver.nondetInt();
              {
                assert 0 <= j;
                assert j <= shiftL;

              }
              {
                assert 0 <= numLeft;
                assert numLeft <= j;

              }
              {
                assert 0 <= numRight;
                assert numRight <= j;

              }
              for (int quantVar140k = 0; 0 <= quantVar140k && j - 1 >= quantVar140k; ++quantVar140k) {
                sum_44 += pivot <= array[begin + quantVar140k] ? 1 : 0;

              }
              assert numLeft == (sum_44);
              for (int quantVar141k = 0; 0 <= quantVar141k && j - 1 >= quantVar141k; ++quantVar141k) {
                sum_45 += array[last - quantVar141k] <= pivot ? 1 : 0;

              }
              assert numRight == (sum_45);
              assert !(0 <= quantVar142k && quantVar142k < numLeft) || 0 <= indexL[quantVar142k] && indexL[quantVar142k] < j && pivot <= array[begin + indexL[quantVar142k]];
              assert !(0 <= quantVar143k && quantVar143k < numRight) || 0 <= indexR[quantVar143k] && indexR[quantVar143k] < j && array[last - indexR[quantVar143k]] <= pivot;
              assert !(0 <= quantVar144k && quantVar144k < numLeft - 1) || indexL[quantVar144k] < indexL[quantVar144k + 1];
              assert !(0 <= quantVar145k && quantVar145k < numRight - 1) || indexR[quantVar145k] < indexR[quantVar145k + 1];

            }
            {
              assert shiftL - j >= 0;
              assert shiftL - j < oldDecreasesClauseValue4;

            }
            CProver.assume(false);

          }

        }
        if (shiftL < shiftR) {
          assert !false;
          indexR[numRight] = shiftR - 1;
          numRight += pivot >= array[last - shiftR + 1] ? 1 : 0;

        }

      } else if (numRight != 0) {
        assert !false;
        shiftL = (last - begin) - BLOCKSIZE + 1;
        assert !false;
        shiftR = BLOCKSIZE;
        assert !false;
        startLeft = 0;
        {
          int j = 0;
          int[] old31 = array;
          {
            int sum_46 = 0;
            int quantVar147k = CProver.nondetInt();
            int quantVar148k = CProver.nondetInt();
            {
              assert 0 <= j;
              assert j <= shiftL;

            }
            for (int quantVar146k = 0; 0 <= quantVar146k && j - 1 >= quantVar146k; ++quantVar146k) {
              sum_46 += pivot <= array[begin + quantVar146k] ? 1 : 0;

            }
            assert numLeft == (sum_46);
            assert !(0 <= quantVar147k && quantVar147k < numLeft) || 0 <= indexL[quantVar147k] && indexL[quantVar147k] < j && pivot <= array[begin + indexL[quantVar147k]];
            assert !(0 <= quantVar148k && quantVar148k < numLeft - 1) || indexL[quantVar148k] < indexL[quantVar148k + 1];

          }
          assert !(false && (old31 != indexL || shiftL - 1 > originalEnd - 1 || 0 < originalBegin)) : "Illegal assignment to indexL[0 .. shiftL - 1] conflicting with assiganbles + array[originalBegin .. originalEnd - 1]";
          j = CProver.nondetInt();
          numLeft = CProver.nondetInt();
          if (indexL != null) {
            for (int __tmpVar__0 = 0; __tmpVar__0 <= shiftL - 1; ++__tmpVar__0) {
              indexL[__tmpVar__0] = CProver.nondetInt();

            }

          }
          int oldDecreasesClauseValue5 = shiftL - j;
          {
            int sum_47 = 0;
            boolean b_42 = true;
            boolean b_43 = true;
            CProver.assume(0 <= j && j <= shiftL);
            for (int quantVar149k = 0; 0 <= quantVar149k && j - 1 >= quantVar149k; ++quantVar149k) {
              sum_47 += pivot <= array[begin + quantVar149k] ? 1 : 0;

            }
            CProver.assume(numLeft == (sum_47));
            for (int quantVar150k = 0; 0 <= quantVar150k && numLeft - 1 >= quantVar150k; ++quantVar150k) {
              b_42 = b_42 && (0 <= indexL[quantVar150k] && indexL[quantVar150k] < j && pivot <= array[begin + indexL[quantVar150k]]);

            }
            CProver.assume((b_42));
            for (int quantVar151k = 0; 0 <= quantVar151k && numLeft - 1 - 1 >= quantVar151k; ++quantVar151k) {
              b_43 = b_43 && indexL[quantVar151k] < indexL[quantVar151k + 1];

            }
            CProver.assume((b_43));

          }
          if (j < shiftL) {
            assert !false;
            indexL[numLeft] = j;
            numLeft += array[begin + j] >= pivot ? 1 : 0;
            j++;
            {
              int sum_48 = 0;
              int quantVar153k = CProver.nondetInt();
              int quantVar154k = CProver.nondetInt();
              {
                assert 0 <= j;
                assert j <= shiftL;

              }
              for (int quantVar152k = 0; 0 <= quantVar152k && j - 1 >= quantVar152k; ++quantVar152k) {
                sum_48 += pivot <= array[begin + quantVar152k] ? 1 : 0;

              }
              assert numLeft == (sum_48);
              assert !(0 <= quantVar153k && quantVar153k < numLeft) || 0 <= indexL[quantVar153k] && indexL[quantVar153k] < j && pivot <= array[begin + indexL[quantVar153k]];
              assert !(0 <= quantVar154k && quantVar154k < numLeft - 1) || indexL[quantVar154k] < indexL[quantVar154k + 1];

            }
            {
              assert shiftL - j >= 0;
              assert shiftL - j < oldDecreasesClauseValue5;

            }
            CProver.assume(false);

          }

        }

      } else {
        assert !false;
        shiftL = BLOCKSIZE;
        assert !false;
        shiftR = (last - begin) - BLOCKSIZE + 1;
        assert !false;
        startRight = 0;
        {
          int j = 0;
          int[] old32 = array;
          {
            int sum_49 = 0;
            int quantVar156k = CProver.nondetInt();
            int quantVar157k = CProver.nondetInt();
            {
              assert 0 <= j;
              assert j <= shiftR;

            }
            for (int quantVar155k = 0; 0 <= quantVar155k && j - 1 >= quantVar155k; ++quantVar155k) {
              sum_49 += array[last - quantVar155k] <= pivot ? 1 : 0;

            }
            assert numRight == (sum_49);
            assert !(0 <= quantVar156k && quantVar156k < numRight) || 0 <= indexR[quantVar156k] && indexR[quantVar156k] < j && array[last - indexR[quantVar156k]] <= pivot;
            assert !(0 <= quantVar157k && quantVar157k < numRight - 1) || indexR[quantVar157k] < indexR[quantVar157k + 1];

          }
          assert !(false && (old32 != indexR || shiftR - 1 > originalEnd - 1 || 0 < originalBegin)) : "Illegal assignment to indexR[0 .. shiftR - 1] conflicting with assiganbles + array[originalBegin .. originalEnd - 1]";
          j = CProver.nondetInt();
          numRight = CProver.nondetInt();
          if (indexR != null) {
            for (int __tmpVar__0 = 0; __tmpVar__0 <= shiftR - 1; ++__tmpVar__0) {
              indexR[__tmpVar__0] = CProver.nondetInt();

            }

          }
          int oldDecreasesClauseValue6 = shiftR - j;
          {
            int sum_50 = 0;
            boolean b_44 = true;
            boolean b_45 = true;
            CProver.assume(0 <= j && j <= shiftR);
            for (int quantVar158k = 0; 0 <= quantVar158k && j - 1 >= quantVar158k; ++quantVar158k) {
              sum_50 += array[last - quantVar158k] <= pivot ? 1 : 0;

            }
            CProver.assume(numRight == (sum_50));
            for (int quantVar159k = 0; 0 <= quantVar159k && numRight - 1 >= quantVar159k; ++quantVar159k) {
              b_44 = b_44 && (0 <= indexR[quantVar159k] && indexR[quantVar159k] < j && array[last - indexR[quantVar159k]] <= pivot);

            }
            CProver.assume((b_44));
            for (int quantVar160k = 0; 0 <= quantVar160k && numRight - 1 - 1 >= quantVar160k; ++quantVar160k) {
              b_45 = b_45 && indexR[quantVar160k] < indexR[quantVar160k + 1];

            }
            CProver.assume((b_45));

          }
          if (j < shiftR) {
            assert !false;
            indexR[numRight] = j;
            numRight += pivot >= array[last - j] ? 1 : 0;
            j++;
            {
              int sum_51 = 0;
              int quantVar162k = CProver.nondetInt();
              int quantVar163k = CProver.nondetInt();
              {
                assert 0 <= j;
                assert j <= shiftR;

              }
              for (int quantVar161k = 0; 0 <= quantVar161k && j - 1 >= quantVar161k; ++quantVar161k) {
                sum_51 += array[last - quantVar161k] <= pivot ? 1 : 0;

              }
              assert numRight == (sum_51);
              assert !(0 <= quantVar162k && quantVar162k < numRight) || 0 <= indexR[quantVar162k] && indexR[quantVar162k] < j && array[last - indexR[quantVar162k]] <= pivot;
              assert !(0 <= quantVar163k && quantVar163k < numRight - 1) || indexR[quantVar163k] < indexR[quantVar163k + 1];

            }
            {
              assert shiftR - j >= 0;
              assert shiftR - j < oldDecreasesClauseValue6;

            }
            CProver.assume(false);

          }

        }

      }
      assert !false;
      $$param12 = numLeft;
      $$param13 = numRight;
      num = minSymb($$param12, $$param13);
      if (num > 0) {
        {
          int j = 0;
          int[] old33 = new int[1];
          int[] old34 = array;
          for (int i = begin; i <= last + 1 - 1; ++i) {
            for (int k = begin; k <= last + 1 - 1; ++k) {
              try {
                old33[k % 1] = array[k];

              } catch (java.lang.RuntimeException e) {

              }

            }

          }
          {
            int quantVar164i = CProver.nondetInt();
            int quantVar165i = CProver.nondetInt();
            int quantVar166i = CProver.nondetInt();
            int quantVar167i = CProver.nondetInt();
            int quantVar168i = CProver.nondetInt();
            int quantVar169i = CProver.nondetInt();
            int quantVar170i = CProver.nondetInt();
            int sum_52 = 0;
            int sum_53 = 0;
            {
              assert 0 <= j;
              assert j <= num;

            }
            assert !(originalBegin <= quantVar164i && quantVar164i < begin + indexL[startLeft]) || array[quantVar164i] <= pivot;
            assert !(j > 0) || (!(originalBegin <= quantVar165i && quantVar165i <= begin + indexL[startLeft + j - 1]) || array[quantVar165i] <= pivot);
            assert !(last - indexR[startRight] < quantVar166i && quantVar166i < originalEnd) || pivot <= array[quantVar166i];
            assert !(j > 0) || (!(last - indexR[startRight + j - 1] <= quantVar167i && quantVar167i < originalEnd) || pivot <= array[quantVar167i]);
            assert !(startLeft + j <= quantVar168i && quantVar168i < startLeft + numLeft) || pivot <= array[begin + indexL[quantVar168i]];
            assert !(startRight + j <= quantVar169i && quantVar169i < startRight + numRight) || array[last - indexR[quantVar169i]] <= pivot;
            if (!!(begin <= quantVar170i && quantVar170i < last + 1)) {
              for (int quantVar171k = begin; begin <= quantVar171k && last + 1 - 1 >= quantVar171k; ++quantVar171k) {
                sum_52 += array[quantVar170i] == array[quantVar171k] ? 1 : 0;

              }
              for (int quantVar172k = begin; begin <= quantVar172k && last + 1 - 1 >= quantVar172k; ++quantVar172k) {
                sum_53 += array[quantVar170i] == old33[quantVar172k % 1] ? 1 : 0;

              }

            }
            assert !(begin <= quantVar170i && quantVar170i < last + 1) || (sum_52) == (sum_53);

          }
          assert !(false && (old34 != array || begin + indexL[startLeft + num - 1] > originalEnd - 1 || begin + indexL[startLeft] < originalBegin)) : "Illegal assignment to array[begin + indexL[startLeft] .. begin + indexL[startLeft + num - 1]] conflicting with assiganbles + array[originalBegin .. originalEnd - 1]";
          assert !(false && (old34 != array || last - indexR[startRight] > originalEnd - 1 || last - indexR[startRight + num - 1] < originalBegin)) : "Illegal assignment to array[last - indexR[startRight + num - 1] .. last - indexR[startRight]] conflicting with assiganbles + array[originalBegin .. originalEnd - 1]";
          j = CProver.nondetInt();
          if (array != null) {
            for (int __tmpVar__0 = last - indexR[startRight + num - 1]; __tmpVar__0 <= last - indexR[startRight]; ++__tmpVar__0) {
              array[__tmpVar__0] = CProver.nondetInt();

            }

          }
          if (array != null) {
            for (int __tmpVar__0 = begin + indexL[startLeft]; __tmpVar__0 <= begin + indexL[startLeft + num - 1]; ++__tmpVar__0) {
              array[__tmpVar__0] = CProver.nondetInt();

            }

          }
          int oldDecreasesClauseValue7 = num - j;
          {
            boolean b_46 = true;
            boolean b_47 = true;
            boolean b_48 = true;
            boolean b_49 = true;
            boolean b_50 = true;
            boolean b_51 = true;
            int sum_54 = 0;
            int sum_55 = 0;
            boolean b_52 = true;
            CProver.assume(0 <= j && j <= num);
            for (int quantVar173i = originalBegin; originalBegin <= quantVar173i && begin + indexL[startLeft] - 1 >= quantVar173i; ++quantVar173i) {
              b_46 = b_46 && array[quantVar173i] <= pivot;

            }
            CProver.assume((b_46));
            if (!!(j > 0)) {
              for (int quantVar174i = originalBegin; originalBegin <= quantVar174i && begin + indexL[startLeft + j - 1] >= quantVar174i; ++quantVar174i) {
                b_47 = b_47 && array[quantVar174i] <= pivot;

              }

            }
            CProver.assume(!(j > 0) || (b_47));
            for (int quantVar175i = last - indexR[startRight] + 1; last - indexR[startRight] + 1 <= quantVar175i && originalEnd - 1 >= quantVar175i; ++quantVar175i) {
              b_48 = b_48 && pivot <= array[quantVar175i];

            }
            CProver.assume((b_48));
            if (!!(j > 0)) {
              for (int quantVar176i = last - indexR[startRight + j - 1]; last - indexR[startRight + j - 1] <= quantVar176i && originalEnd - 1 >= quantVar176i; ++quantVar176i) {
                b_49 = b_49 && pivot <= array[quantVar176i];

              }

            }
            CProver.assume(!(j > 0) || (b_49));
            for (int quantVar177i = startLeft + j; startLeft + j <= quantVar177i && startLeft + numLeft - 1 >= quantVar177i; ++quantVar177i) {
              b_50 = b_50 && pivot <= array[begin + indexL[quantVar177i]];

            }
            CProver.assume((b_50));
            for (int quantVar178i = startRight + j; startRight + j <= quantVar178i && startRight + numRight - 1 >= quantVar178i; ++quantVar178i) {
              b_51 = b_51 && array[last - indexR[quantVar178i]] <= pivot;

            }
            CProver.assume((b_51));
            for (int quantVar179i = begin; begin <= quantVar179i && last + 1 - 1 >= quantVar179i; ++quantVar179i) {
              for (int quantVar180k = begin; begin <= quantVar180k && last + 1 - 1 >= quantVar180k; ++quantVar180k) {
                sum_54 += array[quantVar179i] == array[quantVar180k] ? 1 : 0;

              }
              for (int quantVar181k = begin; begin <= quantVar181k && last + 1 - 1 >= quantVar181k; ++quantVar181k) {
                sum_55 += array[quantVar179i] == old33[quantVar181k % 1] ? 1 : 0;

              }
              b_52 = b_52 && (sum_54) == (sum_55);

            }
            CProver.assume((b_52));

          }
          if (j < num) {
            $$param14 = array;
            $$param15 = begin + indexL[startLeft + j];
            $$param16 = last - indexR[startRight + j];
            assert !(true && (old34 != $$param14 || $$param15 > begin + indexL[startLeft + num - 1] || $$param15 < begin + indexL[startLeft]) && ($$param14 != $$param14 || $$param15 > last - indexR[startRight] || $$param15 < last - indexR[startRight + num - 1])) : "Illegal assignment to array[i] conflicting with assignables array[begin + indexL[startLeft] .. begin + indexL[startLeft + num - 1]], array[last - indexR[startRight + num - 1] .. last - indexR[startRight]], j, j";
            assert !(true && (old34 != $$param14 || $$param16 > begin + indexL[startLeft + num - 1] || $$param16 < begin + indexL[startLeft]) && ($$param14 != $$param14 || $$param16 > last - indexR[startRight] || $$param16 < last - indexR[startRight + num - 1])) : "Illegal assignment to array[j] conflicting with assignables array[begin + indexL[startLeft] .. begin + indexL[startLeft + num - 1]], array[last - indexR[startRight + num - 1] .. last - indexR[startRight]], j, j";
            swapSymb($$param14, $$param15, $$param16);
            j++;
            {
              int quantVar182i = CProver.nondetInt();
              int quantVar183i = CProver.nondetInt();
              int quantVar184i = CProver.nondetInt();
              int quantVar185i = CProver.nondetInt();
              int quantVar186i = CProver.nondetInt();
              int quantVar187i = CProver.nondetInt();
              int quantVar188i = CProver.nondetInt();
              int sum_56 = 0;
              int sum_57 = 0;
              {
                assert 0 <= j;
                assert j <= num;

              }
              assert !(originalBegin <= quantVar182i && quantVar182i < begin + indexL[startLeft]) || array[quantVar182i] <= pivot;
              assert !(j > 0) || (!(originalBegin <= quantVar183i && quantVar183i <= begin + indexL[startLeft + j - 1]) || array[quantVar183i] <= pivot);
              assert !(last - indexR[startRight] < quantVar184i && quantVar184i < originalEnd) || pivot <= array[quantVar184i];
              assert !(j > 0) || (!(last - indexR[startRight + j - 1] <= quantVar185i && quantVar185i < originalEnd) || pivot <= array[quantVar185i]);
              assert !(startLeft + j <= quantVar186i && quantVar186i < startLeft + numLeft) || pivot <= array[begin + indexL[quantVar186i]];
              assert !(startRight + j <= quantVar187i && quantVar187i < startRight + numRight) || array[last - indexR[quantVar187i]] <= pivot;
              if (!!(begin <= quantVar188i && quantVar188i < last + 1)) {
                for (int quantVar189k = begin; begin <= quantVar189k && last + 1 - 1 >= quantVar189k; ++quantVar189k) {
                  sum_56 += array[quantVar188i] == array[quantVar189k] ? 1 : 0;

                }
                for (int quantVar190k = begin; begin <= quantVar190k && last + 1 - 1 >= quantVar190k; ++quantVar190k) {
                  sum_57 += array[quantVar188i] == old33[quantVar190k % 1] ? 1 : 0;

                }

              }
              assert !(begin <= quantVar188i && quantVar188i < last + 1) || (sum_56) == (sum_57);

            }
            {
              assert num - j >= 0;
              assert num - j < oldDecreasesClauseValue7;

            }
            CProver.assume(false);

          }

        }

      }
      numLeft -= num;
      numRight -= num;
      startLeft += num;
      startRight += num;
      begin += (numLeft == 0) ? shiftL : 0;
      last -= (numRight == 0) ? shiftR : 0;
      if (numLeft != 0) {
        int lowerI = startLeft + numLeft - 1;
        int upper = last - begin;
        {
          int quantVar191i = CProver.nondetInt();
          int quantVar192i = CProver.nondetInt();
          int quantVar193i = CProver.nondetInt();
          {
            assert 0 <= startLeft;
            assert startLeft - 1 <= lowerI;
            assert lowerI < startLeft + numLeft;
            assert startLeft + numLeft <= BLOCKSIZE;

          }
          assert upper == last - begin - (startLeft + numLeft - 1 - lowerI);
          assert !(lowerI < quantVar191i && quantVar191i < startLeft + numLeft - 1) || indexL[quantVar191i] == upper + (quantVar191i - lowerI);
          assert !(begin <= quantVar192i && quantVar192i < begin + indexL[startLeft]) || array[quantVar192i] <= pivot;
          assert !(begin + upper < quantVar193i && quantVar193i <= last) || pivot <= array[quantVar193i];

        }
        upper = CProver.nondetInt();
        lowerI = CProver.nondetInt();
        int oldDecreasesClauseValue8 = lowerI + 1;
        {
          boolean b_53 = true;
          boolean b_54 = true;
          boolean b_55 = true;
          CProver.assume(0 <= startLeft && startLeft - 1 <= lowerI && lowerI < startLeft + numLeft && startLeft + numLeft <= BLOCKSIZE);
          CProver.assume(upper == last - begin - (startLeft + numLeft - 1 - lowerI));
          for (int quantVar194i = lowerI + 1; lowerI + 1 <= quantVar194i && startLeft + numLeft - 1 - 1 >= quantVar194i; ++quantVar194i) {
            b_53 = b_53 && indexL[quantVar194i] == upper + (quantVar194i - lowerI);

          }
          CProver.assume((b_53));
          for (int quantVar195i = begin; begin <= quantVar195i && begin + indexL[startLeft] - 1 >= quantVar195i; ++quantVar195i) {
            b_54 = b_54 && array[quantVar195i] <= pivot;

          }
          CProver.assume((b_54));
          for (int quantVar196i = begin + upper + 1; begin + upper + 1 <= quantVar196i && last >= quantVar196i; ++quantVar196i) {
            b_55 = b_55 && pivot <= array[quantVar196i];

          }
          CProver.assume((b_55));

        }
        if (lowerI >= startLeft && indexL[lowerI] == upper) {
          upper--;
          lowerI--;
          {
            int quantVar197i = CProver.nondetInt();
            int quantVar198i = CProver.nondetInt();
            int quantVar199i = CProver.nondetInt();
            {
              assert 0 <= startLeft;
              assert startLeft - 1 <= lowerI;
              assert lowerI < startLeft + numLeft;
              assert startLeft + numLeft <= BLOCKSIZE;

            }
            assert upper == last - begin - (startLeft + numLeft - 1 - lowerI);
            assert !(lowerI < quantVar197i && quantVar197i < startLeft + numLeft - 1) || indexL[quantVar197i] == upper + (quantVar197i - lowerI);
            assert !(begin <= quantVar198i && quantVar198i < begin + indexL[startLeft]) || array[quantVar198i] <= pivot;
            assert !(begin + upper < quantVar199i && quantVar199i <= last) || pivot <= array[quantVar199i];

          }
          {
            assert lowerI + 1 >= 0;
            assert lowerI + 1 < oldDecreasesClauseValue8;

          }
          CProver.assume(false);

        }
        int[] old35 = new int[1];
        int[] old36 = array;
        for (int i = begin; i <= last + 1 - 1; ++i) {
          for (int k = begin; k <= last + 1 - 1; ++k) {
            try {
              old35[k % 1] = array[k];

            } catch (java.lang.RuntimeException e) {

            }

          }

        }
        {
          int quantVar200i = CProver.nondetInt();
          int quantVar201i = CProver.nondetInt();
          int quantVar202i = CProver.nondetInt();
          int quantVar203i = CProver.nondetInt();
          int sum_58 = 0;
          int sum_59 = 0;
          {
            assert 0 <= startLeft;
            assert startLeft - 1 <= lowerI;
            assert lowerI < startLeft + numLeft;
            assert startLeft + numLeft <= BLOCKSIZE;

          }
          assert upper == last - begin - (startLeft + numLeft - 1 - lowerI);
          assert !(startLeft <= quantVar200i && quantVar200i < lowerI) || indexL[quantVar200i] == indexL[quantVar200i + 1] - 1;
          assert !(begin + indexL[startLeft] <= quantVar201i && quantVar201i < begin + upper) || pivot <= array[quantVar201i];
          assert !(begin + upper < quantVar202i && quantVar202i <= last) || pivot <= array[quantVar202i];
          assert !(lowerI >= startLeft) || (indexL[lowerI] == upper || array[begin + upper] <= pivot);
          assert !(lowerI < startLeft) || !(upper >= 0) || array[begin + upper] <= pivot;
          if (!!(begin <= quantVar203i && quantVar203i < last + 1)) {
            for (int quantVar204k = begin; begin <= quantVar204k && last + 1 - 1 >= quantVar204k; ++quantVar204k) {
              sum_58 += array[quantVar203i] == array[quantVar204k] ? 1 : 0;

            }
            for (int quantVar205k = begin; begin <= quantVar205k && last + 1 - 1 >= quantVar205k; ++quantVar205k) {
              sum_59 += array[quantVar203i] == old35[quantVar205k % 1] ? 1 : 0;

            }

          }
          assert !(begin <= quantVar203i && quantVar203i < last + 1) || (sum_58) == (sum_59);

        }
        assert !(false && (old36 != array || last > originalEnd - 1 || begin + indexL[startLeft] < originalBegin)) : "Illegal assignment to array[begin + indexL[startLeft] .. last] conflicting with assiganbles + array[originalBegin .. originalEnd - 1]";
        lowerI = CProver.nondetInt();
        upper = CProver.nondetInt();
        if (array != null) {
          for (int __tmpVar__0 = begin + indexL[startLeft]; __tmpVar__0 <= last; ++__tmpVar__0) {
            array[__tmpVar__0] = CProver.nondetInt();

          }

        }
        int oldDecreasesClauseValue9 = lowerI + 1;
        {
          boolean b_56 = true;
          boolean b_57 = true;
          boolean b_58 = true;
          int sum_60 = 0;
          int sum_61 = 0;
          boolean b_59 = true;
          CProver.assume(0 <= startLeft && startLeft - 1 <= lowerI && lowerI < startLeft + numLeft && startLeft + numLeft <= BLOCKSIZE);
          CProver.assume(upper == last - begin - (startLeft + numLeft - 1 - lowerI));
          for (int quantVar206i = startLeft; startLeft <= quantVar206i && lowerI - 1 >= quantVar206i; ++quantVar206i) {
            b_56 = b_56 && indexL[quantVar206i] == indexL[quantVar206i + 1] - 1;

          }
          CProver.assume((b_56));
          for (int quantVar207i = begin + indexL[startLeft]; begin + indexL[startLeft] <= quantVar207i && begin + upper - 1 >= quantVar207i; ++quantVar207i) {
            b_57 = b_57 && pivot <= array[quantVar207i];

          }
          CProver.assume((b_57));
          for (int quantVar208i = begin + upper + 1; begin + upper + 1 <= quantVar208i && last >= quantVar208i; ++quantVar208i) {
            b_58 = b_58 && pivot <= array[quantVar208i];

          }
          CProver.assume((b_58));
          CProver.assume(!(lowerI >= startLeft) || (indexL[lowerI] == upper || array[begin + upper] <= pivot));
          CProver.assume(!(lowerI < startLeft) || !(upper >= 0) || array[begin + upper] <= pivot);
          for (int quantVar209i = begin; begin <= quantVar209i && last + 1 - 1 >= quantVar209i; ++quantVar209i) {
            for (int quantVar210k = begin; begin <= quantVar210k && last + 1 - 1 >= quantVar210k; ++quantVar210k) {
              sum_60 += array[quantVar209i] == array[quantVar210k] ? 1 : 0;

            }
            for (int quantVar211k = begin; begin <= quantVar211k && last + 1 - 1 >= quantVar211k; ++quantVar211k) {
              sum_61 += array[quantVar209i] == old35[quantVar211k % 1] ? 1 : 0;

            }
            b_59 = b_59 && (sum_60) == (sum_61);

          }
          CProver.assume((b_59));

        }
        if (lowerI >= startLeft) {
          $$param17 = array;
          $$param18 = begin + upper;
          $$param19 = begin + indexL[lowerI];
          assert !(true && (old36 != $$param17 || $$param18 > last || $$param18 < begin + indexL[startLeft])) : "Illegal assignment to array[i] conflicting with assignables array[begin + indexL[startLeft] .. last], upper, lowerI";
          assert !(true && (old36 != $$param17 || $$param19 > last || $$param19 < begin + indexL[startLeft])) : "Illegal assignment to array[j] conflicting with assignables array[begin + indexL[startLeft] .. last], upper, lowerI";
          swapSymb($$param17, $$param18, $$param19);
          upper--;
          lowerI--;
          {
            int quantVar212i = CProver.nondetInt();
            int quantVar213i = CProver.nondetInt();
            int quantVar214i = CProver.nondetInt();
            int quantVar215i = CProver.nondetInt();
            int sum_62 = 0;
            int sum_63 = 0;
            {
              assert 0 <= startLeft;
              assert startLeft - 1 <= lowerI;
              assert lowerI < startLeft + numLeft;
              assert startLeft + numLeft <= BLOCKSIZE;

            }
            assert upper == last - begin - (startLeft + numLeft - 1 - lowerI);
            assert !(startLeft <= quantVar212i && quantVar212i < lowerI) || indexL[quantVar212i] == indexL[quantVar212i + 1] - 1;
            assert !(begin + indexL[startLeft] <= quantVar213i && quantVar213i < begin + upper) || pivot <= array[quantVar213i];
            assert !(begin + upper < quantVar214i && quantVar214i <= last) || pivot <= array[quantVar214i];
            assert !(lowerI >= startLeft) || (indexL[lowerI] == upper || array[begin + upper] <= pivot);
            assert !(lowerI < startLeft) || !(upper >= 0) || array[begin + upper] <= pivot;
            if (!!(begin <= quantVar215i && quantVar215i < last + 1)) {
              for (int quantVar216k = begin; begin <= quantVar216k && last + 1 - 1 >= quantVar216k; ++quantVar216k) {
                sum_62 += array[quantVar215i] == array[quantVar216k] ? 1 : 0;

              }
              for (int quantVar217k = begin; begin <= quantVar217k && last + 1 - 1 >= quantVar217k; ++quantVar217k) {
                sum_63 += array[quantVar215i] == old35[quantVar217k % 1] ? 1 : 0;

              }

            }
            assert !(begin <= quantVar215i && quantVar215i < last + 1) || (sum_62) == (sum_63);

          }
          {
            assert lowerI + 1 >= 0;
            assert lowerI + 1 < oldDecreasesClauseValue9;

          }
          CProver.assume(false);

        }
        $$param20 = array;
        $$param21 = pivotPosition;
        $$param22 = begin + upper + 1;
        assert !(true && (old22 != $$param20 || $$param21 > originalEnd - 1 || $$param21 < originalBegin)) : "Illegal assignment to array[i] conflicting with assignables array[originalBegin .. originalEnd - 1]";
        assert !(true && (old22 != $$param20 || $$param22 > originalEnd - 1 || $$param22 < originalBegin)) : "Illegal assignment to array[j] conflicting with assignables array[originalBegin .. originalEnd - 1]";
        swapSymb($$param20, $$param21, $$param22);
        {
          returnVar = begin + upper + 1;
          throw new BlockQuickSort.ReturnException();

        }

      } else if (numRight != 0) {
        int lowerI = startRight + numRight - 1;
        int upper = last - begin;
        {
          int quantVar218i = CProver.nondetInt();
          int quantVar219i = CProver.nondetInt();
          int quantVar220i = CProver.nondetInt();
          {
            assert 0 <= startRight;
            assert startRight - 1 <= lowerI;
            assert lowerI < startRight + numRight;
            assert startRight + numRight <= BLOCKSIZE;

          }
          assert upper == last - begin - (startRight + numRight - 1 - lowerI);
          assert !(lowerI < quantVar218i && quantVar218i < startRight + numRight - 1) || indexR[quantVar218i] == upper + (quantVar218i - lowerI);
          assert !(last - indexR[startRight] < quantVar219i && quantVar219i <= last) || pivot <= array[quantVar219i];
          assert !(begin <= quantVar220i && quantVar220i < last - upper) || array[quantVar220i] <= pivot;

        }
        upper = CProver.nondetInt();
        lowerI = CProver.nondetInt();
        int oldDecreasesClauseValue10 = lowerI + 1;
        {
          boolean b_60 = true;
          boolean b_61 = true;
          boolean b_62 = true;
          CProver.assume(0 <= startRight && startRight - 1 <= lowerI && lowerI < startRight + numRight && startRight + numRight <= BLOCKSIZE);
          CProver.assume(upper == last - begin - (startRight + numRight - 1 - lowerI));
          for (int quantVar221i = lowerI + 1; lowerI + 1 <= quantVar221i && startRight + numRight - 1 - 1 >= quantVar221i; ++quantVar221i) {
            b_60 = b_60 && indexR[quantVar221i] == upper + (quantVar221i - lowerI);

          }
          CProver.assume((b_60));
          for (int quantVar222i = last - indexR[startRight] + 1; last - indexR[startRight] + 1 <= quantVar222i && last >= quantVar222i; ++quantVar222i) {
            b_61 = b_61 && pivot <= array[quantVar222i];

          }
          CProver.assume((b_61));
          for (int quantVar223i = begin; begin <= quantVar223i && last - upper - 1 >= quantVar223i; ++quantVar223i) {
            b_62 = b_62 && array[quantVar223i] <= pivot;

          }
          CProver.assume((b_62));

        }
        if (lowerI >= startRight && indexR[lowerI] == upper) {
          upper--;
          lowerI--;
          {
            int quantVar224i = CProver.nondetInt();
            int quantVar225i = CProver.nondetInt();
            int quantVar226i = CProver.nondetInt();
            {
              assert 0 <= startRight;
              assert startRight - 1 <= lowerI;
              assert lowerI < startRight + numRight;
              assert startRight + numRight <= BLOCKSIZE;

            }
            assert upper == last - begin - (startRight + numRight - 1 - lowerI);
            assert !(lowerI < quantVar224i && quantVar224i < startRight + numRight - 1) || indexR[quantVar224i] == upper + (quantVar224i - lowerI);
            assert !(last - indexR[startRight] < quantVar225i && quantVar225i <= last) || pivot <= array[quantVar225i];
            assert !(begin <= quantVar226i && quantVar226i < last - upper) || array[quantVar226i] <= pivot;

          }
          {
            assert lowerI + 1 >= 0;
            assert lowerI + 1 < oldDecreasesClauseValue10;

          }
          CProver.assume(false);

        }
        int[] old37 = new int[1];
        int[] old38 = array;
        for (int i = begin; i <= last + 1 - 1; ++i) {
          for (int k = begin; k <= last + 1 - 1; ++k) {
            try {
              old37[k % 1] = array[k];

            } catch (java.lang.RuntimeException e) {

            }

          }

        }
        {
          int quantVar227i = CProver.nondetInt();
          int quantVar228i = CProver.nondetInt();
          int quantVar229i = CProver.nondetInt();
          int quantVar230i = CProver.nondetInt();
          int sum_64 = 0;
          int sum_65 = 0;
          {
            assert 0 <= startRight;
            assert startRight - 1 <= lowerI;
            assert lowerI < startRight + numRight;
            assert startRight + numRight <= BLOCKSIZE;

          }
          assert upper == last - begin - (startRight + numRight - 1 - lowerI);
          assert !(startRight <= quantVar227i && quantVar227i < lowerI) || indexR[quantVar227i] == indexR[quantVar227i + 1] - 1;
          assert !(begin <= quantVar228i && quantVar228i < last - upper) || array[quantVar228i] <= pivot;
          assert !(last - upper < quantVar229i && quantVar229i <= last - indexR[startRight]) || array[quantVar229i] <= pivot;
          assert !(lowerI >= startRight) || (indexR[lowerI] == upper || pivot <= array[last - upper]);
          assert !(lowerI < startRight) || !(upper >= 0) || pivot <= array[last - upper];
          if (!!(begin <= quantVar230i && quantVar230i < last + 1)) {
            for (int quantVar231k = begin; begin <= quantVar231k && last + 1 - 1 >= quantVar231k; ++quantVar231k) {
              sum_64 += array[quantVar230i] == array[quantVar231k] ? 1 : 0;

            }
            for (int quantVar232k = begin; begin <= quantVar232k && last + 1 - 1 >= quantVar232k; ++quantVar232k) {
              sum_65 += array[quantVar230i] == old37[quantVar232k % 1] ? 1 : 0;

            }

          }
          assert !(begin <= quantVar230i && quantVar230i < last + 1) || (sum_64) == (sum_65);

        }
        assert !(false && (old38 != array || last - indexR[startRight] > originalEnd - 1 || begin < originalBegin)) : "Illegal assignment to array[begin .. last - indexR[startRight]] conflicting with assiganbles + array[originalBegin .. originalEnd - 1]";
        lowerI = CProver.nondetInt();
        upper = CProver.nondetInt();
        if (array != null) {
          for (int __tmpVar__0 = begin; __tmpVar__0 <= last - indexR[startRight]; ++__tmpVar__0) {
            array[__tmpVar__0] = CProver.nondetInt();

          }

        }
        int oldDecreasesClauseValue11 = lowerI + 1;
        {
          boolean b_63 = true;
          boolean b_64 = true;
          boolean b_65 = true;
          int sum_66 = 0;
          int sum_67 = 0;
          boolean b_66 = true;
          CProver.assume(0 <= startRight && startRight - 1 <= lowerI && lowerI < startRight + numRight && startRight + numRight <= BLOCKSIZE);
          CProver.assume(upper == last - begin - (startRight + numRight - 1 - lowerI));
          for (int quantVar233i = startRight; startRight <= quantVar233i && lowerI - 1 >= quantVar233i; ++quantVar233i) {
            b_63 = b_63 && indexR[quantVar233i] == indexR[quantVar233i + 1] - 1;

          }
          CProver.assume((b_63));
          for (int quantVar234i = begin; begin <= quantVar234i && last - upper - 1 >= quantVar234i; ++quantVar234i) {
            b_64 = b_64 && array[quantVar234i] <= pivot;

          }
          CProver.assume((b_64));
          for (int quantVar235i = last - upper + 1; last - upper + 1 <= quantVar235i && last - indexR[startRight] >= quantVar235i; ++quantVar235i) {
            b_65 = b_65 && array[quantVar235i] <= pivot;

          }
          CProver.assume((b_65));
          CProver.assume(!(lowerI >= startRight) || (indexR[lowerI] == upper || pivot <= array[last - upper]));
          CProver.assume(!(lowerI < startRight) || !(upper >= 0) || pivot <= array[last - upper]);
          for (int quantVar236i = begin; begin <= quantVar236i && last + 1 - 1 >= quantVar236i; ++quantVar236i) {
            for (int quantVar237k = begin; begin <= quantVar237k && last + 1 - 1 >= quantVar237k; ++quantVar237k) {
              sum_66 += array[quantVar236i] == array[quantVar237k] ? 1 : 0;

            }
            for (int quantVar238k = begin; begin <= quantVar238k && last + 1 - 1 >= quantVar238k; ++quantVar238k) {
              sum_67 += array[quantVar236i] == old37[quantVar238k % 1] ? 1 : 0;

            }
            b_66 = b_66 && (sum_66) == (sum_67);

          }
          CProver.assume((b_66));

        }
        if (lowerI >= startRight) {
          $$param23 = array;
          $$param24 = last - upper;
          $$param25 = last - indexR[lowerI];
          assert !(true && (old38 != $$param23 || $$param24 > last - indexR[startRight] || $$param24 < begin)) : "Illegal assignment to array[i] conflicting with assignables array[begin .. last - indexR[startRight]], upper, lowerI";
          assert !(true && (old38 != $$param23 || $$param25 > last - indexR[startRight] || $$param25 < begin)) : "Illegal assignment to array[j] conflicting with assignables array[begin .. last - indexR[startRight]], upper, lowerI";
          swapSymb($$param23, $$param24, $$param25);
          upper--;
          lowerI--;
          {
            int quantVar239i = CProver.nondetInt();
            int quantVar240i = CProver.nondetInt();
            int quantVar241i = CProver.nondetInt();
            int quantVar242i = CProver.nondetInt();
            int sum_68 = 0;
            int sum_69 = 0;
            {
              assert 0 <= startRight;
              assert startRight - 1 <= lowerI;
              assert lowerI < startRight + numRight;
              assert startRight + numRight <= BLOCKSIZE;

            }
            assert upper == last - begin - (startRight + numRight - 1 - lowerI);
            assert !(startRight <= quantVar239i && quantVar239i < lowerI) || indexR[quantVar239i] == indexR[quantVar239i + 1] - 1;
            assert !(begin <= quantVar240i && quantVar240i < last - upper) || array[quantVar240i] <= pivot;
            assert !(last - upper < quantVar241i && quantVar241i <= last - indexR[startRight]) || array[quantVar241i] <= pivot;
            assert !(lowerI >= startRight) || (indexR[lowerI] == upper || pivot <= array[last - upper]);
            assert !(lowerI < startRight) || !(upper >= 0) || pivot <= array[last - upper];
            if (!!(begin <= quantVar242i && quantVar242i < last + 1)) {
              for (int quantVar243k = begin; begin <= quantVar243k && last + 1 - 1 >= quantVar243k; ++quantVar243k) {
                sum_68 += array[quantVar242i] == array[quantVar243k] ? 1 : 0;

              }
              for (int quantVar244k = begin; begin <= quantVar244k && last + 1 - 1 >= quantVar244k; ++quantVar244k) {
                sum_69 += array[quantVar242i] == old37[quantVar244k % 1] ? 1 : 0;

              }

            }
            assert !(begin <= quantVar242i && quantVar242i < last + 1) || (sum_68) == (sum_69);

          }
          {
            assert lowerI + 1 >= 0;
            assert lowerI + 1 < oldDecreasesClauseValue11;

          }
          CProver.assume(false);

        }
        $$param26 = array;
        $$param27 = pivotPosition;
        $$param28 = last - upper;
        assert !(true && (old22 != $$param26 || $$param27 > originalEnd - 1 || $$param27 < originalBegin)) : "Illegal assignment to array[i] conflicting with assignables array[originalBegin .. originalEnd - 1]";
        assert !(true && (old22 != $$param26 || $$param28 > originalEnd - 1 || $$param28 < originalBegin)) : "Illegal assignment to array[j] conflicting with assignables array[originalBegin .. originalEnd - 1]";
        swapSymb($$param26, $$param27, $$param28);
        {
          returnVar = last - upper;
          throw new BlockQuickSort.ReturnException();

        }

      } else {
        $$param29 = array;
        $$param30 = pivotPosition;
        $$param31 = begin;
        assert !(true && (old22 != $$param29 || $$param30 > originalEnd - 1 || $$param30 < originalBegin)) : "Illegal assignment to array[i] conflicting with assignables array[originalBegin .. originalEnd - 1]";
        assert !(true && (old22 != $$param29 || $$param31 > originalEnd - 1 || $$param31 < originalBegin)) : "Illegal assignment to array[j] conflicting with assignables array[originalBegin .. originalEnd - 1]";
        swapSymb($$param29, $$param30, $$param31);
        {
          returnVar = begin;
          throw new BlockQuickSort.ReturnException();

        }

      }

    } catch (BlockQuickSort.ReturnException ex) {

    }
    {
      assert array.length == old19;

    }
    {
      {
        assert originalBegin <= returnVar;
        assert returnVar < originalEnd;

      }

    }
    {
      assert array[returnVar] == old20;

    }
    {
      int quantVar27i = CProver.nondetInt();
      assert !(originalBegin <= quantVar27i && quantVar27i <= returnVar) || array[quantVar27i] <= array[returnVar];

    }
    {
      int quantVar28i = CProver.nondetInt();
      assert !(returnVar <= quantVar28i && quantVar28i < originalEnd) || array[returnVar] <= array[quantVar28i];

    }
    {
      int quantVar29i = CProver.nondetInt();
      int sum_14 = 0;
      int sum_15 = 0;
      if (!!(originalBegin <= quantVar29i && quantVar29i < originalEnd)) {
        for (int quantVar30j = originalBegin; originalBegin <= quantVar30j && originalEnd - 1 >= quantVar30j; ++quantVar30j) {
          sum_14 += array[quantVar29i] == array[quantVar30j] ? 1 : 0;

        }
        for (int quantVar31j = originalBegin; originalBegin <= quantVar31j && originalEnd - 1 >= quantVar31j; ++quantVar31j) {
          sum_15 += array[quantVar29i] == old21[quantVar31j % 1] ? 1 : 0;

        }

      }
      assert !(originalBegin <= quantVar29i && quantVar29i < originalEnd) || ((sum_14) == (sum_15));

    }
    return returnVar;

  }
    /*@
    public normal_behavior
      requires array != null && array.length < 500; 
      requires (originalEnd - originalBegin) >= 1 && (originalEnd - originalBegin) <= 500; 
      requires 0 <= originalBegin && originalBegin < originalEnd && originalEnd <= array.length; 
      requires originalBegin <= pivotPosition && pivotPosition < originalEnd; 
      ensures array.length == \old(array.length); 
      ensures originalBegin <= \result && \result < originalEnd; 
      ensures array[\result] == \old(array[pivotPosition]); 
      ensures (\forall int i; originalBegin <= i <= \result; array[i] <= array[\result]); 
      ensures (\forall int i; \result <= i < originalEnd; array[\result] <= array[i]); 
      ensures (\forall int i; originalBegin <= i < originalEnd; ((\num_of int j; originalBegin <= j < originalEnd; array[i] == array[j]) == (\num_of int j; originalBegin <= j < originalEnd; array[i] == \old(array[j])))); 
      assignable array[originalBegin .. originalEnd - 1]; 
   */

  public static int hoareBlockPartition( 
  int[] array, int originalBegin, int originalEnd, int pivotPosition) {
     
    int[] indexL = new int[BLOCKSIZE];
     
    int[] indexR = new int[BLOCKSIZE];
    int begin = originalBegin;
    int end = originalEnd;
    int last = end - 1;
    int pivot = array[pivotPosition];
    swap(array, pivotPosition, last);
    pivotPosition = last;
    last--;
    int numLeft = 0;
    int numRight = 0;
    int startLeft = 0;
    int startRight = 0;
    int num = 0;
    if (last - begin + 1 > 2 * BLOCKSIZE) {
      //@ loop_invariant originalBegin <= begin && begin <= last && last < originalEnd - 1;
      //@ loop_invariant 0 <= numLeft && numLeft <= BLOCKSIZE;
      //@ loop_invariant 0 <= numRight && numRight <= BLOCKSIZE;
      //@ loop_invariant 0 <= startLeft && startLeft <= BLOCKSIZE && startLeft + numLeft <= BLOCKSIZE;
      //@ loop_invariant 0 <= startRight && startRight <= BLOCKSIZE && startRight + numRight <= BLOCKSIZE;
      //@ loop_invariant 0 <= num && num <= BLOCKSIZE;
      //@ loop_invariant numRight == 0 || numLeft == 0;
      //@ loop_invariant array[originalEnd - 1] == \old(array[pivotPosition]);
      //@ loop_invariant (\exists int i; 0 <= i < (originalEnd - originalBegin); begin == originalBegin + i * BLOCKSIZE);
      //@ loop_invariant (\exists int i; 0 <= i < (originalEnd - originalBegin); last == originalEnd - 2 - i * BLOCKSIZE);
      //@ loop_invariant (\forall int i; 0 <= i < BLOCKSIZE; 0 <= indexL[i] && indexL[i] < BLOCKSIZE);
      //@ loop_invariant (\forall int i; 0 <= i < numLeft; indexL[startLeft + i] < last - begin && pivot <= array[begin + indexL[startLeft + i]]);
      //@ loop_invariant (\forall int i; 0 <= i < startLeft + numLeft - 1; indexL[i] < indexL[i + 1]);
      //@ loop_invariant (numLeft != 0) ==> numLeft == (\num_of int i; startLeft <= i < BLOCKSIZE; pivot <= array[begin + i]);
      //@ loop_invariant (\forall int i; 0 <= i < BLOCKSIZE; 0 <= indexR[i] && indexR[i] < BLOCKSIZE);
      //@ loop_invariant (\forall int i; 0 <= i < numRight; indexR[startRight + i] < last - begin && array[last - indexR[startRight + i]] <= pivot);
      //@ loop_invariant (\forall int i; 0 <= i < startRight + numRight - 1; indexR[i] < indexR[i + 1]);
      //@ loop_invariant (numRight != 0) ==> numRight == (\num_of int i; startRight <= i < BLOCKSIZE; array[last - i] <= pivot);
      //@ loop_invariant (numLeft == 0) ==> (\forall int i; originalBegin <= i < begin; array[i] <= pivot);
      //@ loop_invariant (numLeft != 0) ==> (\forall int i; originalBegin <= i < begin + indexL[startLeft]; array[i] <= pivot);
      //@ loop_invariant (numRight == 0) ==> (\forall int i; last < i < originalEnd; pivot <= array[i]);
      //@ loop_invariant (numRight != 0) ==> (\forall int i; last - indexR[startRight] < i < originalEnd; pivot <= array[i]);
      //@ loop_invariant (\forall int i; originalBegin <= i < originalEnd; (\num_of int j; originalBegin <= j < originalEnd; array[i] == array[j]) == (\num_of int j; originalBegin <= j < originalEnd; array[i] == \old(array[j])));
      //@ loop_modifies array[max(begin, originalBegin) .. min(begin + BLOCKSIZE - 1, originalEnd - 2)], array[max(last - BLOCKSIZE - 1, originalBegin) .. min(last, originalEnd - 2)], last, begin, numLeft, numRight, startLeft, startRight, indexL[0 .. BLOCKSIZE - 1], indexR[0 .. BLOCKSIZE - 1], num;
      //@ loop_decreases last - begin;
      while (last - begin + 1 > 2 * BLOCKSIZE) {
        if (numLeft == 0) {
          startLeft = 0;
          //@ loop_invariant 0 <= j <= BLOCKSIZE;
          //@ loop_invariant numLeft == (\num_of int k; 0 <= k < j; pivot <= array[begin + k]);
          //@ loop_invariant (\forall int k; 0 <= k < numLeft; 0 <= indexL[k] && indexL[k] < j && pivot <= array[begin + indexL[k]]);
          //@ loop_invariant (\forall int k; 0 <= k < numLeft - 1; indexL[k] < indexL[k + 1]);
          //@ loop_modifies numLeft, indexL[0 .. BLOCKSIZE - 1], j;
          //@ loop_decreases BLOCKSIZE - j;
          for (int j = 0; j < BLOCKSIZE; j++) {
            indexL[numLeft] = j;
            numLeft += array[begin + j] >= pivot ? 1 : 0;
            j++;

          }

        }
        if (numRight == 0) {
          startRight = 0;
          //@ loop_invariant 0 <= j <= BLOCKSIZE;
          //@ loop_invariant numRight == (\num_of int k; 0 <= k < j; array[last - k] <= pivot);
          //@ loop_invariant (\forall int k; 0 <= k < numRight; 0 <= indexR[k] && indexR[k] < j && array[last - indexR[k]] <= pivot);
          //@ loop_invariant (\forall int k; 0 <= k < numRight - 1; indexR[k] < indexR[k + 1]);
          //@ loop_modifies numRight, indexR[0 .. BLOCKSIZE - 1], j;
          //@ loop_decreases BLOCKSIZE - j;
          for (int j = 0; j < BLOCKSIZE; j++) {
            indexR[numRight] = j;
            numRight += pivot >= array[last - j] ? 1 : 0;
            j++;

          }

        }
        num = min(numLeft, numRight);
        if (num > 0) {
          //@ loop_invariant 0 <= j <= num;
          //@ loop_invariant (\forall int i; originalBegin <= i < begin + indexL[startLeft]; array[i] <= pivot);
          //@ loop_invariant j > 0 ==> (\forall int i; originalBegin <= i <= begin + indexL[startLeft + j - 1]; array[i] <= pivot);
          //@ loop_invariant (\forall int i; last - indexR[startRight] < i < originalEnd; pivot <= array[i]);
          //@ loop_invariant j > 0 ==> (\forall int i; last - indexR[startRight + j - 1] <= i < originalEnd; pivot <= array[i]);
          //@ loop_invariant (\forall int i; startLeft + j <= i < startLeft + numLeft; pivot <= array[begin + indexL[i]]);
          //@ loop_invariant (\forall int i; startRight + j <= i < startRight + numRight; array[last - indexR[i]] <= pivot);
          //@ loop_invariant (\forall int i; begin <= i < last + 1; (\num_of int k; begin <= k < last + 1; array[i] == array[k]) == (\num_of int k; begin <= k < last + 1; array[i] == \old(array[k])));
          //@ loop_modifies array[begin + indexL[startLeft] .. begin + indexL[startLeft + num - 1]], array[last - indexR[startRight + num - 1] .. last - indexR[startRight]], j;
          //@ loop_decreases num - j;
          for (int j = 0; j < num; j++) {
            swap(array, begin + indexL[startLeft + j], last - indexR[startRight + j]);
            j++;

          }

        }
        numLeft -= num;
        numRight -= num;
        startLeft += num;
        startRight += num;
        begin += (numLeft == 0) ? BLOCKSIZE : 0;
        last -= (numRight == 0) ? BLOCKSIZE : 0;

      }

    }
    int shiftR = 0;
    int shiftL = 0;
    if (numRight == 0 && numLeft == 0) {
      shiftL = ((last - begin) + 1) / 2;
      shiftR = (last - begin) + 1 - shiftL;
      startLeft = 0;
      startRight = 0;
      //@ loop_invariant 0 <= j <= shiftL;
      //@ loop_invariant 0 <= numLeft && numLeft <= j;
      //@ loop_invariant 0 <= numRight && numRight <= j;
      //@ loop_invariant numLeft == (\num_of int k; 0 <= k < j; pivot <= array[begin + k]);
      //@ loop_invariant numRight == (\num_of int k; 0 <= k < j; array[last - k] <= pivot);
      //@ loop_invariant (\forall int k; 0 <= k < numLeft; 0 <= indexL[k] && indexL[k] < j && pivot <= array[begin + indexL[k]]);
      //@ loop_invariant (\forall int k; 0 <= k < numRight; 0 <= indexR[k] && indexR[k] < j && array[last - indexR[k]] <= pivot);
      //@ loop_invariant (\forall int k; 0 <= k < numLeft - 1; indexL[k] < indexL[k + 1]);
      //@ loop_invariant (\forall int k; 0 <= k < numRight - 1; indexR[k] < indexR[k + 1]);
      //@ loop_decreases shiftL - j;
      //@ loop_modifies indexL[0 .. shiftL - 1], numLeft, indexR[0 .. shiftL - 1], numRight, j;
      for (int j = 0; j < shiftL; j++) {
        indexL[numLeft] = j;
        numLeft += array[begin + j] >= pivot ? 1 : 0;
        indexR[numRight] = j;
        numRight += pivot >= array[last - j] ? 1 : 0;
        j++;

      }
      if (shiftL < shiftR) {
        indexR[numRight] = shiftR - 1;
        numRight += pivot >= array[last - shiftR + 1] ? 1 : 0;

      }

    } else if (numRight != 0) {
      shiftL = (last - begin) - BLOCKSIZE + 1;
      shiftR = BLOCKSIZE;
      startLeft = 0;
      //@ loop_invariant 0 <= j <= shiftL;
      //@ loop_invariant numLeft == (\num_of int k; 0 <= k < j; pivot <= array[begin + k]);
      //@ loop_invariant (\forall int k; 0 <= k < numLeft; 0 <= indexL[k] && indexL[k] < j && pivot <= array[begin + indexL[k]]);
      //@ loop_invariant (\forall int k; 0 <= k < numLeft - 1; indexL[k] < indexL[k + 1]);
      //@ loop_modifies numLeft, indexL[0 .. shiftL - 1], j;
      //@ loop_decreases shiftL - j;
      for (int j = 0; j < shiftL; j++) {
        indexL[numLeft] = j;
        numLeft += array[begin + j] >= pivot ? 1 : 0;
        j++;

      }

    } else {
      shiftL = BLOCKSIZE;
      shiftR = (last - begin) - BLOCKSIZE + 1;
      startRight = 0;
      //@ loop_invariant 0 <= j <= shiftR;
      //@ loop_invariant numRight == (\num_of int k; 0 <= k < j; array[last - k] <= pivot);
      //@ loop_invariant (\forall int k; 0 <= k < numRight; 0 <= indexR[k] && indexR[k] < j && array[last - indexR[k]] <= pivot);
      //@ loop_invariant (\forall int k; 0 <= k < numRight - 1; indexR[k] < indexR[k + 1]);
      //@ loop_modifies numRight, indexR[0 .. shiftR - 1], j;
      //@ loop_decreases shiftR - j;
      for (int j = 0; j < shiftR; j++) {
        indexR[numRight] = j;
        numRight += pivot >= array[last - j] ? 1 : 0;
        j++;

      }

    }
    num = min(numLeft, numRight);
    if (num > 0) {
      //@ loop_invariant 0 <= j <= num;
      //@ loop_invariant (\forall int i; originalBegin <= i < begin + indexL[startLeft]; array[i] <= pivot);
      //@ loop_invariant j > 0 ==> (\forall int i; originalBegin <= i <= begin + indexL[startLeft + j - 1]; array[i] <= pivot);
      //@ loop_invariant (\forall int i; last - indexR[startRight] < i < originalEnd; pivot <= array[i]);
      //@ loop_invariant j > 0 ==> (\forall int i; last - indexR[startRight + j - 1] <= i < originalEnd; pivot <= array[i]);
      //@ loop_invariant (\forall int i; startLeft + j <= i < startLeft + numLeft; pivot <= array[begin + indexL[i]]);
      //@ loop_invariant (\forall int i; startRight + j <= i < startRight + numRight; array[last - indexR[i]] <= pivot);
      //@ loop_invariant (\forall int i; begin <= i < last + 1; (\num_of int k; begin <= k < last + 1; array[i] == array[k]) == (\num_of int k; begin <= k < last + 1; array[i] == \old(array[k])));
      //@ loop_modifies array[begin + indexL[startLeft] .. begin + indexL[startLeft + num - 1]], array[last - indexR[startRight + num - 1] .. last - indexR[startRight]], j;
      //@ loop_decreases num - j;
      for (int j = 0; j < num; j++) {
        swap(array, begin + indexL[startLeft + j], last - indexR[startRight + j]);
        j++;

      }

    }
    numLeft -= num;
    numRight -= num;
    startLeft += num;
    startRight += num;
    begin += (numLeft == 0) ? shiftL : 0;
    last -= (numRight == 0) ? shiftR : 0;
    if (numLeft != 0) {
      int lowerI = startLeft + numLeft - 1;
      int upper = last - begin;
      //@ loop_invariant 0 <= startLeft && startLeft - 1 <= lowerI && lowerI < startLeft + numLeft && startLeft + numLeft <= BLOCKSIZE;
      //@ loop_invariant upper == last - begin - (startLeft + numLeft - 1 - lowerI);
      //@ loop_invariant (\forall int i; lowerI < i < startLeft + numLeft - 1; indexL[i] == upper + (i - lowerI));
      //@ loop_invariant (\forall int i; begin <= i < begin + indexL[startLeft]; array[i] <= pivot);
      //@ loop_invariant (\forall int i; begin + upper < i <= last; pivot <= array[i]);
      //@ loop_modifies lowerI, upper;
      //@ loop_decreases lowerI + 1;
      while (lowerI >= startLeft && indexL[lowerI] == upper) {
        upper--;
        lowerI--;

      }
      //@ loop_invariant 0 <= startLeft && startLeft - 1 <= lowerI && lowerI < startLeft + numLeft && startLeft + numLeft <= BLOCKSIZE;
      //@ loop_invariant upper == last - begin - (startLeft + numLeft - 1 - lowerI);
      //@ loop_invariant (\forall int i; startLeft <= i < lowerI; indexL[i] == indexL[i + 1] - 1);
      //@ loop_invariant (\forall int i; begin + indexL[startLeft] <= i < begin + upper; pivot <= array[i]);
      //@ loop_invariant (\forall int i; begin + upper < i <= last; pivot <= array[i]);
      //@ loop_invariant lowerI >= startLeft ==> indexL[lowerI] == upper || array[begin + upper] <= pivot;
      //@ loop_invariant lowerI < startLeft && upper >= 0 ==> array[begin + upper] <= pivot;
      //@ loop_invariant (\forall int i; begin <= i < last + 1; (\num_of int k; begin <= k < last + 1; array[i] == array[k]) == (\num_of int k; begin <= k < last + 1; array[i] == \old(array[k])));
      //@ loop_modifies upper, lowerI, array[begin + indexL[startLeft] .. last];
      //@ loop_decreases lowerI + 1;
      while (lowerI >= startLeft) {
        swap(array, begin + upper, begin + indexL[lowerI]);
        upper--;
        lowerI--;

      }
      swap(array, pivotPosition, begin + upper + 1);
      return begin + upper + 1;

    } else if (numRight != 0) {
      int lowerI = startRight + numRight - 1;
      int upper = last - begin;
      //@ loop_invariant 0 <= startRight && startRight - 1 <= lowerI && lowerI < startRight + numRight && startRight + numRight <= BLOCKSIZE;
      //@ loop_invariant upper == last - begin - (startRight + numRight - 1 - lowerI);
      //@ loop_invariant (\forall int i; lowerI < i < startRight + numRight - 1; indexR[i] == upper + (i - lowerI));
      //@ loop_invariant (\forall int i; last - indexR[startRight] < i <= last; pivot <= array[i]);
      //@ loop_invariant (\forall int i; begin <= i < last - upper; array[i] <= pivot);
      //@ loop_modifies lowerI, upper;
      //@ loop_decreases lowerI + 1;
      while (lowerI >= startRight && indexR[lowerI] == upper) {
        upper--;
        lowerI--;

      }
      //@ loop_invariant 0 <= startRight && startRight - 1 <= lowerI && lowerI < startRight + numRight && startRight + numRight <= BLOCKSIZE;
      //@ loop_invariant upper == last - begin - (startRight + numRight - 1 - lowerI);
      //@ loop_invariant (\forall int i; startRight <= i < lowerI; indexR[i] == indexR[i + 1] - 1);
      //@ loop_invariant (\forall int i; begin <= i < last - upper; array[i] <= pivot);
      //@ loop_invariant (\forall int i; last - upper < i <= last - indexR[startRight]; array[i] <= pivot);
      //@ loop_invariant lowerI >= startRight ==> indexR[lowerI] == upper || pivot <= array[last - upper];
      //@ loop_invariant lowerI < startRight && upper >= 0 ==> pivot <= array[last - upper];
      //@ loop_invariant (\forall int i; begin <= i < last + 1; (\num_of int k; begin <= k < last + 1; array[i] == array[k]) == (\num_of int k; begin <= k < last + 1; array[i] == \old(array[k])));
      //@ loop_modifies upper, lowerI, array[begin .. last - indexR[startRight]];
      //@ loop_decreases lowerI + 1;
      while (lowerI >= startRight) {
        swap(array, last - upper, last - indexR[lowerI]);
        upper--;
        lowerI--;

      }
      swap(array, pivotPosition, last - upper);
      return last - upper;

    } else {
      swap(array, pivotPosition, begin);
      return begin;

    }

  }
  
  public static void quickSortVerf( 
  int[] array, int originalBegin, int originalEnd) {
    {
      CProver.assume(array != null && array.length < 500);

    }
    {
      CProver.assume(0 <= originalBegin && originalBegin < originalEnd && originalEnd <= array.length);

    }
    int old39 = array.length;
    int[] old40 = array;
    try {
      int $$param36 = 0;
      int $$param37 = 0;
      int[] $$param38 = null;
      int $$param39 = 0;
      int $$param40 = 0;
      int[] $$param41 = null;
      int $$param42 = 0;
      int $$param43 = 0;
      int begin = originalBegin;
      int end = originalEnd;
       
      int[] stack = new int[STACK_SIZE];
      int top = 0;
      int depth = 0;
      $$param36 = end - begin;
      $$param37 = 2;
      int depthLimit = (int)(2 * logSymb($$param36) / logSymb($$param37)) + 3;
      assert !false;
      stack[top++] = begin;
      assert !false;
      stack[top++] = end;
      while (top > 0) {
        assert !false;
        end = stack[--top];
        assert !false;
        begin = stack[--top];
        while (end - begin > IS_THRESH && depth < depthLimit) {
          $$param38 = array;
          $$param39 = begin;
          $$param40 = end;
          assert !(true && (old40 != $$param38 || $$param40 - 1 > originalEnd - 1 || $$param39 < originalBegin)) : "Illegal assignment to array[begin .. end - 1] conflicting with assignables array[originalBegin .. originalEnd - 1]";
          int pivot = partitionSymb($$param38, $$param39, $$param40);
          if (pivot - begin > end - pivot) {
            assert !false;
            stack[top++] = begin;
            assert !false;
            stack[top++] = pivot;
            assert !false;
            begin = pivot + 1;

          } else {
            assert !false;
            stack[top++] = pivot + 1;
            assert !false;
            stack[top++] = end;
            assert !false;
            end = pivot;

          }
          depth++;

        }
        if (end - begin <= IS_THRESH || depth >= depthLimit) {
          $$param41 = array;
          $$param42 = begin;
          $$param43 = end;
          assert !(true && (old40 != $$param41 || $$param43 - 1 > originalEnd - 1 || $$param42 < originalBegin)) : "Illegal assignment to array[begin .. end - 1] conflicting with assignables array[originalBegin .. originalEnd - 1]";
          insertionSortSymb($$param41, $$param42, $$param43);

        }
        depth--;

      }

    } catch (BlockQuickSort.ReturnException ex) {

    }
    {
      assert array.length == old39;

    }
    {
      int quantVar245i = CProver.nondetInt();
      assert !(originalBegin <= quantVar245i && quantVar245i < originalEnd - 1) || array[quantVar245i] <= array[quantVar245i + 1];

    }
    {
      int[] $$param32 = null;
      int[] $$param33 = null;
      int $$param34 = 0;
      int $$param35 = 0;
      $$param32 = array;
      $$param33 = old40;
      $$param34 = originalBegin;
      $$param35 = originalEnd;
      assert permutationSymb($$param32, $$param33, $$param34, $$param35);

    }

  }
    /*@
    public normal_behavior
      requires array != null && array.length < 500; 
      requires 0 <= originalBegin && originalBegin < originalEnd && originalEnd <= array.length; 
      ensures array.length == \old(array.length); 
      ensures (\forall int i; originalBegin <= i < originalEnd - 1; array[i] <= array[i + 1]); 
      ensures permutation(array, \old(array), originalBegin, originalEnd); 
      assignable array[originalBegin .. originalEnd - 1]; 
   */

  public static void quickSort( 
  int[] array, int originalBegin, int originalEnd) {
    int begin = originalBegin;
    int end = originalEnd;
     
    int[] stack = new int[STACK_SIZE];
    int top = 0;
    int depth = 0;
    int depthLimit = (int)(2 * log(end - begin) / log(2)) + 3;
    stack[top++] = begin;
    stack[top++] = end;
    while (top > 0) {
      end = stack[--top];
      begin = stack[--top];
      while (end - begin > IS_THRESH && depth < depthLimit) {
        int pivot = partition(array, begin, end);
        if (pivot - begin > end - pivot) {
          stack[top++] = begin;
          stack[top++] = pivot;
          begin = pivot + 1;

        } else {
          stack[top++] = pivot + 1;
          stack[top++] = end;
          end = pivot;

        }
        depth++;

      }
      if (end - begin <= IS_THRESH || depth >= depthLimit) {
        insertionSort(array, begin, end);

      }
      depth--;

    }

  }
  
  public static void quickSortRecVerf( 
  int[] array, int begin, int end) {
    {
      CProver.assume(array != null && array.length < 500);

    }
    {
      CProver.assume(0 <= begin && begin < end && end <= array.length);

    }
    int old41 = array.length;
    int[] old42 = new int[1];
    int[] old43 = array;
    for (int i = begin; i <= end - 1; ++i) {
      for (int j = begin; j <= end - 1; ++j) {
        try {
          old42[j % 1] = array[j];

        } catch (java.lang.RuntimeException e) {

        }

      }

    }
    try {
      int $$param44 = 0;
      int $$param45 = 0;
      int[] $$param46 = null;
      int $$param47 = 0;
      int $$param48 = 0;
      int $$param49 = 0;
      int $$param50 = 0;
      int depth = 0;
      $$param44 = end - begin;
      $$param45 = 2;
      int depthLimit = (int)(2 * logSymb($$param44) / logSymb($$param45)) + 3;
      $$param46 = array;
      $$param47 = begin;
      $$param48 = end;
      $$param49 = depth;
      $$param50 = depthLimit;
      assert !(true && (old43 != $$param46 || $$param48 - 1 > $$param48 - 1 || $$param47 < $$param47)) : "Illegal assignment to array[begin .. end - 1] conflicting with assignables array[begin .. end - 1]";
      quickSortRecImplSymb($$param46, $$param47, $$param48, $$param49, $$param50);

    } catch (BlockQuickSort.ReturnException ex) {

    }
    {
      assert array.length == old41;

    }
    {
      int quantVar246i = CProver.nondetInt();
      assert !(begin <= quantVar246i && quantVar246i < end - 1) || array[quantVar246i] <= array[quantVar246i + 1];

    }
    {
      int quantVar247i = CProver.nondetInt();
      int sum_70 = 0;
      int sum_71 = 0;
      if (!!(begin <= quantVar247i && quantVar247i < end)) {
        for (int quantVar248j = begin; begin <= quantVar248j && end - 1 >= quantVar248j; ++quantVar248j) {
          sum_70 += array[quantVar247i] == array[quantVar248j] ? 1 : 0;

        }
        for (int quantVar249j = begin; begin <= quantVar249j && end - 1 >= quantVar249j; ++quantVar249j) {
          sum_71 += array[quantVar247i] == old42[quantVar249j % 1] ? 1 : 0;

        }

      }
      assert !(begin <= quantVar247i && quantVar247i < end) || ((sum_70) == (sum_71));

    }

  }
    /*@
    public normal_behavior
      requires array != null && array.length < 500; 
      requires 0 <= begin && begin < end && end <= array.length; 
      ensures array.length == \old(array.length); 
      ensures (\forall int i; begin <= i < end - 1; array[i] <= array[i + 1]); 
      ensures (\forall int i; begin <= i < end; ((\num_of int j; begin <= j < end; array[i] == array[j]) == (\num_of int j; begin <= j < end; array[i] == \old(array[j])))); 
      assignable array[begin .. end - 1]; 
   */

  public static void quickSortRec( 
  int[] array, int begin, int end) {
    int depth = 0;
    int depthLimit = (int)(2 * log(end - begin) / log(2)) + 3;
    quickSortRecImpl(array, begin, end, depth, depthLimit);

  }
  
  public static void quickSortRecImplVerf( 
  int[] array, int begin, int end, int depth, int depthLimit) {
    {
      CProver.assume(array != null && array.length < 500);

    }
    {
      CProver.assume(0 <= begin && begin <= end && end <= array.length);

    }
    {
      CProver.assume(0 <= depth && depth <= depthLimit && depthLimit < 500);

    }
    int old44 = array.length;
    int[] old45 = new int[1];
    int[] old46 = array;
    for (int i = begin; i <= end - 1; ++i) {
      for (int j = begin; j <= end - 1; ++j) {
        try {
          old45[j % 1] = array[j];

        } catch (java.lang.RuntimeException e) {

        }

      }

    }
    try {
      int[] $$param51 = null;
      int $$param52 = 0;
      int $$param53 = 0;
      int[] $$param54 = null;
      int $$param55 = 0;
      int $$param56 = 0;
      int[] $$param57 = null;
      int $$param58 = 0;
      int $$param59 = 0;
      int $$param60 = 0;
      int $$param61 = 0;
      int[] $$param62 = null;
      int $$param63 = 0;
      int $$param64 = 0;
      int $$param65 = 0;
      int $$param66 = 0;
      if (end - begin <= IS_THRESH || depth >= depthLimit) {
        $$param51 = array;
        $$param52 = begin;
        $$param53 = end;
        assert !(true && (old46 != $$param51 || $$param53 - 1 > $$param53 - 1 || $$param52 < $$param52)) : "Illegal assignment to array[begin .. end - 1] conflicting with assignables array[begin .. end - 1]";
        insertionSortSymb($$param51, $$param52, $$param53);
        {
          throw new BlockQuickSort.ReturnException();

        }

      }
      $$param54 = array;
      $$param55 = begin;
      $$param56 = end;
      assert !(true && (old46 != $$param54 || $$param56 - 1 > $$param56 - 1 || $$param55 < $$param55)) : "Illegal assignment to array[begin .. end - 1] conflicting with assignables array[begin .. end - 1]";
      int pivot = partitionSymb($$param54, $$param55, $$param56);
      $$param57 = array;
      $$param58 = begin;
      $$param59 = pivot;
      $$param60 = depth + 1;
      $$param61 = depthLimit;
      assert !(true && (old46 != $$param57 || $$param59 - 1 > $$param59 - 1 || $$param58 < $$param58)) : "Illegal assignment to array[begin .. end - 1] conflicting with assignables array[begin .. end - 1]";
      quickSortRecImplSymb($$param57, $$param58, $$param59, $$param60, $$param61);
      $$param62 = array;
      $$param63 = pivot;
      $$param64 = end;
      $$param65 = depth + 1;
      $$param66 = depthLimit;
      assert !(true && (old46 != $$param62 || $$param64 - 1 > $$param64 - 1 || $$param63 < $$param63)) : "Illegal assignment to array[begin .. end - 1] conflicting with assignables array[begin .. end - 1]";
      quickSortRecImplSymb($$param62, $$param63, $$param64, $$param65, $$param66);

    } catch (BlockQuickSort.ReturnException ex) {

    }
    {
      assert array.length == old44;

    }
    {
      int quantVar250i = CProver.nondetInt();
      assert !(begin <= quantVar250i && quantVar250i < end - 1) || array[quantVar250i] <= array[quantVar250i + 1];

    }
    {
      int quantVar251i = CProver.nondetInt();
      int sum_72 = 0;
      int sum_73 = 0;
      if (!!(begin <= quantVar251i && quantVar251i < end)) {
        for (int quantVar252j = begin; begin <= quantVar252j && end - 1 >= quantVar252j; ++quantVar252j) {
          sum_72 += array[quantVar251i] == array[quantVar252j] ? 1 : 0;

        }
        for (int quantVar253j = begin; begin <= quantVar253j && end - 1 >= quantVar253j; ++quantVar253j) {
          sum_73 += array[quantVar251i] == old45[quantVar253j % 1] ? 1 : 0;

        }

      }
      assert !(begin <= quantVar251i && quantVar251i < end) || ((sum_72) == (sum_73));

    }

  }
    /*@
    public normal_behavior
      requires array != null && array.length < 500; 
      requires 0 <= begin && begin <= end && end <= array.length; 
      requires 0 <= depth && depth <= depthLimit && depthLimit < 500; 
      ensures array.length == \old(array.length); 
      ensures (\forall int i; begin <= i < end - 1; array[i] <= array[i + 1]); 
      ensures (\forall int i; begin <= i < end; ((\num_of int j; begin <= j < end; array[i] == array[j]) == (\num_of int j; begin <= j < end; array[i] == \old(array[j])))); 
      assignable array[begin .. end - 1]; 
   */

  public static void quickSortRecImpl( 
  int[] array, int begin, int end, int depth, int depthLimit) {
    if (end - begin <= IS_THRESH || depth >= depthLimit) {
      insertionSort(array, begin, end);
      return;

    }
    int pivot = partition(array, begin, end);
    quickSortRecImpl(array, begin, pivot, depth + 1, depthLimit);
    quickSortRecImpl(array, pivot, end, depth + 1, depthLimit);

  }
  
  public static void insertionSortVerf( 
  int[] array, int begin, int end) {
    {
      CProver.assume(array != null && array.length < 500);

    }
    {
      CProver.assume(0 <= begin && begin <= end && end <= array.length);

    }
    int old47 = array.length;
    int[] old48 = new int[1];
    int[] old49 = array;
    for (int i = begin; i <= end - 1; ++i) {
      for (int j = begin; j <= end - 1; ++j) {
        try {
          old48[j % 1] = array[j];

        } catch (java.lang.RuntimeException e) {

        }

      }

    }
    try {
      int[] $$param67 = null;
      int $$param68 = 0;
      int $$param69 = 0;
      for (int i = begin; i < end; ) {
        int j = i;
        while (j > begin && array[j - 1] > array[j]) {
          $$param67 = array;
          $$param68 = j;
          $$param69 = j - 1;
          assert !(true && (old49 != $$param67 || $$param68 > end - 1 || $$param68 < begin)) : "Illegal assignment to array[i] conflicting with assignables array[begin .. end - 1]";
          assert !(true && (old49 != $$param67 || $$param69 > end - 1 || $$param69 < begin)) : "Illegal assignment to array[j] conflicting with assignables array[begin .. end - 1]";
          swapSymb($$param67, $$param68, $$param69);
          j--;

        }
        i++;

      }

    } catch (BlockQuickSort.ReturnException ex) {

    }
    {
      assert array.length == old47;

    }
    {
      int quantVar254i = CProver.nondetInt();
      assert !(begin <= quantVar254i && quantVar254i < end - 1) || array[quantVar254i] <= array[quantVar254i + 1];

    }
    {
      int quantVar255i = CProver.nondetInt();
      int sum_74 = 0;
      int sum_75 = 0;
      if (!!(begin <= quantVar255i && quantVar255i < end)) {
        for (int quantVar256j = begin; begin <= quantVar256j && end - 1 >= quantVar256j; ++quantVar256j) {
          sum_74 += array[quantVar255i] == array[quantVar256j] ? 1 : 0;

        }
        for (int quantVar257j = begin; begin <= quantVar257j && end - 1 >= quantVar257j; ++quantVar257j) {
          sum_75 += array[quantVar255i] == old48[quantVar257j % 1] ? 1 : 0;

        }

      }
      assert !(begin <= quantVar255i && quantVar255i < end) || ((sum_74) == (sum_75));

    }

  }
    /*@
    public normal_behavior
      requires array != null && array.length < 500; 
      requires 0 <= begin && begin <= end && end <= array.length; 
      ensures array.length == \old(array.length); 
      ensures (\forall int i; begin <= i < end - 1; array[i] <= array[i + 1]); 
      ensures (\forall int i; begin <= i < end; ((\num_of int j; begin <= j < end; array[i] == array[j]) == (\num_of int j; begin <= j < end; array[i] == \old(array[j])))); 
      assignable array[begin .. end - 1]; 
   */

  public static void insertionSort( 
  int[] array, int begin, int end) {
    for (int i = begin; i < end; i++) {
      int j = i;
      while (j > begin && array[j - 1] > array[j]) {
        swap(array, j, j - 1);
        j--;

      }

    }

  }
  
  public static void swapVerf( 
  int[] array, int i, int j) {
    {
      CProver.assume(array != null && array.length < 500);

    }
    {
      CProver.assume(0 <= i && i < array.length);

    }
    {
      CProver.assume(0 <= j && j < array.length);

    }
    int old50 = array.length;
    int old51 = array[j];
    int old52 = array[i];
    try {
      int temp = array[i];
      assert !false;
      array[i] = array[j];
      assert !false;
      array[j] = temp;

    } catch (BlockQuickSort.ReturnException ex) {

    }
    {
      assert array.length == old50;

    }
    {
      {
        assert array[i] == old51;
        assert array[j] == old52;

      }

    }

  }
    /*@
    public normal_behavior
      requires array != null && array.length < 500; 
      requires 0 <= i < array.length; 
      requires 0 <= j < array.length; 
      ensures array.length == \old(array.length); 
      ensures array[i] == \old(array[j]) && array[j] == \old(array[i]); 
      assignable array[i], array[j]; 
   */

  public static void swap( 
  int[] array, int i, int j) {
    int temp = array[i];
    array[i] = array[j];
    array[j] = temp;

  }
  
  public static void sortPairVerf(int i1, int i2,  
  int[] array) {
    {
      CProver.assume(array != null && array.length < 500);

    }
    {
      CProver.assume(0 <= i1 && i1 < array.length);

    }
    {
      CProver.assume(0 <= i2 && i2 < array.length);

    }
    int old53 = array.length;
    int old54 = array[i1];
    int old55 = array[i2];
    int[] old56 = array;
    try {
      int[] $$param70 = null;
      int $$param71 = 0;
      int $$param72 = 0;
      if (array[i1] > array[i2]) {
        $$param70 = array;
        $$param71 = i1;
        $$param72 = i2;
        assert !(true && (old56 != $$param70 || $$param71 > i1 || $$param71 < i1) && ($$param70 != $$param70 || $$param71 > i2 || $$param71 < i2)) : "Illegal assignment to array[i] conflicting with assignables array[i1], array[i2]";
        assert !(true && (old56 != $$param70 || $$param72 > i1 || $$param72 < i1) && ($$param70 != $$param70 || $$param72 > i2 || $$param72 < i2)) : "Illegal assignment to array[j] conflicting with assignables array[i1], array[i2]";
        swapSymb($$param70, $$param71, $$param72);

      }

    } catch (BlockQuickSort.ReturnException ex) {

    }
    {
      assert array.length == old53;

    }
    {
      assert (old54 <= old55) ? (array[i1] == old54 && array[i2] == old55) : (array[i1] == old55 && array[i2] == old54);

    }

  }
    /*@
    public normal_behavior
      requires array != null && array.length < 500; 
      requires 0 <= i1 && i1 < array.length; 
      requires 0 <= i2 && i2 < array.length; 
      ensures array.length == \old(array.length); 
      ensures (\old(array[i1]) <= \old(array[i2])) ? (array[i1] == \old(array[i1]) && array[i2] == \old(array[i2])) : (array[i1] == \old(array[i2]) && array[i2] == \old(array[i1])); 
      assignable array[i1], array[i2]; 
   */

  public static void sortPair(int i1, int i2,  
  int[] array) {
    if (array[i1] > array[i2]) {
      swap(array, i1, i2);

    }

  }
  
  public static int medianOf3Verf( 
  int[] array, int begin, int end) {
    {
      CProver.assume(array != null && array.length < 500);

    }
    {
      CProver.assume(end - begin >= 3);

    }
    {
      CProver.assume(0 <= begin && begin < end && end <= array.length);

    }
    int old57 = array.length;
    int[] old58 = new int[1];
    int[] old59 = array;
    for (int i = begin; i <= end - 1; ++i) {
      for (int j = begin; j <= end - 1; ++j) {
        try {
          old58[j % 1] = array[j];

        } catch (java.lang.RuntimeException e) {

        }

      }

    }
    int returnVar = 0;
    try {
      int $$param73 = 0;
      int $$param74 = 0;
      int[] $$param75 = null;
      int $$param76 = 0;
      int $$param77 = 0;
      int[] $$param78 = null;
      int $$param79 = 0;
      int $$param80 = 0;
      int[] $$param81 = null;
      int mid = begin + ((end - begin) / 2);
      $$param73 = begin;
      $$param74 = mid;
      $$param75 = array;
      assert !(true && (old59 != $$param75 || $$param73 > begin || $$param73 < begin) && ($$param75 != $$param75 || $$param73 > begin + ((end - begin) / 2) || $$param73 < begin + ((end - begin) / 2)) && ($$param75 != $$param75 || $$param73 > end - 1 || $$param73 < end - 1)) : "Illegal assignment to array[i1] conflicting with assignables array[begin], array[begin + ((end - begin) / 2)], array[end - 1]";
      assert !(true && (old59 != $$param75 || $$param74 > begin || $$param74 < begin) && ($$param75 != $$param75 || $$param74 > begin + ((end - begin) / 2) || $$param74 < begin + ((end - begin) / 2)) && ($$param75 != $$param75 || $$param74 > end - 1 || $$param74 < end - 1)) : "Illegal assignment to array[i2] conflicting with assignables array[begin], array[begin + ((end - begin) / 2)], array[end - 1]";
      sortPairSymb($$param73, $$param74, $$param75);
      $$param76 = mid;
      $$param77 = end - 1;
      $$param78 = array;
      assert !(true && (old59 != $$param78 || $$param76 > begin || $$param76 < begin) && ($$param78 != $$param78 || $$param76 > begin + ((end - begin) / 2) || $$param76 < begin + ((end - begin) / 2)) && ($$param78 != $$param78 || $$param76 > end - 1 || $$param76 < end - 1)) : "Illegal assignment to array[i1] conflicting with assignables array[begin], array[begin + ((end - begin) / 2)], array[end - 1]";
      assert !(true && (old59 != $$param78 || $$param77 > begin || $$param77 < begin) && ($$param78 != $$param78 || $$param77 > begin + ((end - begin) / 2) || $$param77 < begin + ((end - begin) / 2)) && ($$param78 != $$param78 || $$param77 > end - 1 || $$param77 < end - 1)) : "Illegal assignment to array[i2] conflicting with assignables array[begin], array[begin + ((end - begin) / 2)], array[end - 1]";
      sortPairSymb($$param76, $$param77, $$param78);
      $$param79 = begin;
      $$param80 = mid;
      $$param81 = array;
      assert !(true && (old59 != $$param81 || $$param79 > begin || $$param79 < begin) && ($$param81 != $$param81 || $$param79 > begin + ((end - begin) / 2) || $$param79 < begin + ((end - begin) / 2)) && ($$param81 != $$param81 || $$param79 > end - 1 || $$param79 < end - 1)) : "Illegal assignment to array[i1] conflicting with assignables array[begin], array[begin + ((end - begin) / 2)], array[end - 1]";
      assert !(true && (old59 != $$param81 || $$param80 > begin || $$param80 < begin) && ($$param81 != $$param81 || $$param80 > begin + ((end - begin) / 2) || $$param80 < begin + ((end - begin) / 2)) && ($$param81 != $$param81 || $$param80 > end - 1 || $$param80 < end - 1)) : "Illegal assignment to array[i2] conflicting with assignables array[begin], array[begin + ((end - begin) / 2)], array[end - 1]";
      sortPairSymb($$param79, $$param80, $$param81);
      {
        returnVar = mid;
        throw new BlockQuickSort.ReturnException();

      }

    } catch (BlockQuickSort.ReturnException ex) {

    }
    {
      assert array.length == old57;

    }
    {
      assert returnVar == begin + ((end - begin) / 2);

    }
    {
      {
        assert array[begin] <= array[returnVar];
        assert array[returnVar] <= array[end - 1];

      }

    }
    {
      int quantVar258i = CProver.nondetInt();
      int sum_76 = 0;
      int sum_77 = 0;
      if (!!(begin <= quantVar258i && quantVar258i < end)) {
        for (int quantVar259j = begin; begin <= quantVar259j && end - 1 >= quantVar259j; ++quantVar259j) {
          sum_76 += array[quantVar258i] == array[quantVar259j] ? 1 : 0;

        }
        for (int quantVar260j = begin; begin <= quantVar260j && end - 1 >= quantVar260j; ++quantVar260j) {
          sum_77 += array[quantVar258i] == old58[quantVar260j % 1] ? 1 : 0;

        }

      }
      assert !(begin <= quantVar258i && quantVar258i < end) || ((sum_76) == (sum_77));

    }
    return returnVar;

  }
    /*@
    public normal_behavior
      requires array != null && array.length < 500; 
      requires end - begin >= 3; 
      requires 0 <= begin && begin < end && end <= array.length; 
      ensures array.length == \old(array.length); 
      ensures \result == begin + ((end - begin) / 2); 
      ensures array[begin] <= array[\result] && array[\result] <= array[end - 1]; 
      ensures (\forall int i; begin <= i < end; ((\num_of int j; begin <= j < end; array[i] == array[j]) == (\num_of int j; begin <= j < end; array[i] == \old(array[j])))); 
      assignable array[begin], array[begin + ((end - begin) / 2)], array[end - 1]; 
   */

  public static int medianOf3( 
  int[] array, int begin, int end) {
    int mid = begin + ((end - begin) / 2);
    sortPair(begin, mid, array);
    sortPair(mid, end - 1, array);
    sortPair(begin, mid, array);
    return mid;

  }
  
  public static int partitionVerf( 
  int[] array, int begin, int end) {
    {
      CProver.assume(array != null && array.length < 500);

    }
    {
      CProver.assume(end - begin >= 3);

    }
    {
      CProver.assume(0 <= begin && begin < end && end <= array.length);

    }
    int old60 = array.length;
    int[] old61 = new int[1];
    int[] old62 = array;
    for (int i = begin; i <= end - 1; ++i) {
      for (int j = begin; j <= end - 1; ++j) {
        try {
          old61[j % 1] = array[j];

        } catch (java.lang.RuntimeException e) {

        }

      }

    }
    int returnVar = 0;
    try {
      int[] $$param82 = null;
      int $$param83 = 0;
      int $$param84 = 0;
      int[] $$param85 = null;
      int $$param86 = 0;
      int $$param87 = 0;
      int $$param88 = 0;
      $$param82 = array;
      $$param83 = begin;
      $$param84 = end;
      assert !(true && (old62 != $$param82 || $$param83 > $$param84 - 1 || $$param83 < $$param83)) : "Illegal assignment to array[begin] conflicting with assignables array[begin .. end - 1]";
      assert !(true && (old62 != $$param82 || $$param83 + (($$param84 - $$param83) / 2) > $$param84 - 1 || $$param83 + (($$param84 - $$param83) / 2) < $$param83)) : "Illegal assignment to array[begin + ((end - begin) / 2)] conflicting with assignables array[begin .. end - 1]";
      assert !(true && (old62 != $$param82 || $$param84 - 1 > $$param84 - 1 || $$param84 - 1 < $$param83)) : "Illegal assignment to array[end - 1] conflicting with assignables array[begin .. end - 1]";
      int mid = medianOf3Symb($$param82, $$param83, $$param84);
      $$param85 = array;
      $$param86 = begin + 1;
      $$param87 = end - 1;
      $$param88 = mid;
      assert !(true && (old62 != $$param85 || $$param87 - 1 > end - 1 || $$param86 < begin)) : "Illegal assignment to array[originalBegin .. originalEnd - 1] conflicting with assignables array[begin .. end - 1]";
      {
        returnVar = hoareBlockPartitionSymb($$param85, $$param86, $$param87, $$param88);
        throw new BlockQuickSort.ReturnException();

      }

    } catch (BlockQuickSort.ReturnException ex) {

    }
    {
      assert array.length == old60;

    }
    {
      {
        assert begin <= returnVar;
        assert returnVar < end;

      }

    }
    {
      int quantVar261i = CProver.nondetInt();
      assert !(begin <= quantVar261i && quantVar261i <= returnVar) || array[quantVar261i] <= array[returnVar];

    }
    {
      int quantVar262i = CProver.nondetInt();
      assert !(returnVar <= quantVar262i && quantVar262i < end) || array[returnVar] <= array[quantVar262i];

    }
    {
      int quantVar263i = CProver.nondetInt();
      int sum_78 = 0;
      int sum_79 = 0;
      if (!!(begin <= quantVar263i && quantVar263i < end)) {
        for (int quantVar264j = begin; begin <= quantVar264j && end - 1 >= quantVar264j; ++quantVar264j) {
          sum_78 += array[quantVar263i] == array[quantVar264j] ? 1 : 0;

        }
        for (int quantVar265j = begin; begin <= quantVar265j && end - 1 >= quantVar265j; ++quantVar265j) {
          sum_79 += array[quantVar263i] == old61[quantVar265j % 1] ? 1 : 0;

        }

      }
      assert !(begin <= quantVar263i && quantVar263i < end) || ((sum_78) == (sum_79));

    }
    return returnVar;

  }
    /*@
    public normal_behavior
      requires array != null && array.length < 500; 
      requires end - begin >= 3; 
      requires 0 <= begin && begin < end && end <= array.length; 
      ensures array.length == \old(array.length); 
      ensures begin <= \result && \result < end; 
      ensures (\forall int i; begin <= i <= \result; array[i] <= array[\result]); 
      ensures (\forall int i; \result <= i < end; array[\result] <= array[i]); 
      ensures (\forall int i; begin <= i < end; ((\num_of int j; begin <= j < end; array[i] == array[j]) == (\num_of int j; begin <= j < end; array[i] == \old(array[j])))); 
      assignable array[begin .. end - 1]; 
   */

  public static int partition( 
  int[] array, int begin, int end) {
    int mid = medianOf3(array, begin, end);
    return hoareBlockPartition(array, begin + 1, end - 1, mid);

  }
  
   
  public static double logVerf(double a) {
    {
      CProver.assume(a > 0);

    }
    double returnVar = 0.0;
    try {
      if (a <= 0) {
        throw new IllegalArgumentException("Argument must be positive.");

      }
      int iterations = 1000;
      double result = 0.0;
      double x = (a - 1) / (a + 1);
      for (int i = 0; i < iterations; ) {
        int exponent = 2 * i + 1;
        result += power(x, exponent) / exponent;
        i++;

      }
      {
        returnVar = 2 * result;
        throw new BlockQuickSort.ReturnException();

      }

    } catch (BlockQuickSort.ReturnException ex) {

    }
    {
      {
        assert 1 <= returnVar;
        assert returnVar < 100;

      }

    }
    return returnVar;

  }
    /*@
      requires a > 0; 
      ensures 1 <= \result && \result < 100; 
   */

   
  public static double log(double a) {
    if (a <= 0) {
      throw new IllegalArgumentException("Argument must be positive.");

    }
    int iterations = 1000;
    double result = 0.0;
    double x = (a - 1) / (a + 1);
    for (int i = 0; i < iterations; i++) {
      int exponent = 2 * i + 1;
      result += power(x, exponent) / exponent;

    }
    return 2 * result;

  }
  
  private static double powerVerf(double base, int exponent) {
    double returnVar = 0.0;
    try {
      double result = 1.0;
      for (int i = 0; i < exponent; ) {
        result *= base;
        i++;

      }
      {
        returnVar = result;
        throw new BlockQuickSort.ReturnException();

      }

    } catch (BlockQuickSort.ReturnException ex) {

    } catch (java.lang.RuntimeException e) {
      CProver.assume(false);

    }
    return returnVar;

  }
    /*@
    private behavior
      signals_only java.lang.RuntimeException; 
   */

  private static double power(double base, int exponent) {
    double result = 1.0;
    for (int i = 0; i < exponent; i++) {
      result *= base;

    }
    return result;

  }
  
   
  public static int minVerf(int a, int b) {
    int returnVar = 0;
    try {
      {
        returnVar = a < b ? a : b;
        throw new BlockQuickSort.ReturnException();

      }

    } catch (BlockQuickSort.ReturnException ex) {

    }
    {
      assert returnVar == (a < b ? a : b);

    }
    return returnVar;

  }
    /*@
    public normal_behavior
      ensures \result == (a < b ? a : b); 
   */

   
  public static int min(int a, int b) {
    return a < b ? a : b;

  }
  
   
  public static int maxVerf(int a, int b) {
    int returnVar = 0;
    try {
      {
        returnVar = a > b ? a : b;
        throw new BlockQuickSort.ReturnException();

      }

    } catch (BlockQuickSort.ReturnException ex) {

    }
    {
      assert returnVar == (a > b ? a : b);

    }
    return returnVar;

  }
    /*@
    public normal_behavior
      ensures \result == (a > b ? a : b); 
   */

   
  public static int max(int a, int b) {
    return a > b ? a : b;

  }
  
   
  public static boolean permutationVerf( 
  int[] array1,  
  int[] array2, int begin, int end) {
    {
      CProver.assume(array1 != null);

    }
    {
      CProver.assume(array2 != null);

    }
    {
      CProver.assume(0 <= begin && begin <= end && end <= array1.length);

    }
    {
      CProver.assume(array1.length == array2.length);

    }
    int old63 = array1.length;
    int old64 = array2.length;
    boolean returnVar = true;
    try {
      {
        int i = begin;
        {
          int quantVar272j = CProver.nondetInt();
          int sum_84 = 0;
          int sum_85 = 0;
          {
            assert begin <= i;
            assert i <= end;

          }
          if (!!(begin <= quantVar272j && quantVar272j < i)) {
            for (int quantVar273k = begin; begin <= quantVar273k && end - 1 >= quantVar273k; ++quantVar273k) {
              sum_84 += array1[quantVar272j] == array1[quantVar273k] ? 1 : 0;

            }
            for (int quantVar274k = begin; begin <= quantVar274k && end - 1 >= quantVar274k; ++quantVar274k) {
              sum_85 += array1[quantVar272j] == array2[quantVar274k] ? 1 : 0;

            }

          }
          assert !(begin <= quantVar272j && quantVar272j < i) || (sum_84) == (sum_85);

        }
        i = CProver.nondetInt();
        int oldDecreasesClauseValue12 = end - i;
        {
          int sum_86 = 0;
          int sum_87 = 0;
          boolean b_68 = true;
          CProver.assume(begin <= i && i <= end);
          for (int quantVar275j = begin; begin <= quantVar275j && i - 1 >= quantVar275j; ++quantVar275j) {
            for (int quantVar276k = begin; begin <= quantVar276k && end - 1 >= quantVar276k; ++quantVar276k) {
              sum_86 += array1[quantVar275j] == array1[quantVar276k] ? 1 : 0;

            }
            for (int quantVar277k = begin; begin <= quantVar277k && end - 1 >= quantVar277k; ++quantVar277k) {
              sum_87 += array1[quantVar275j] == array2[quantVar277k] ? 1 : 0;

            }
            b_68 = b_68 && (sum_86) == (sum_87);

          }
          CProver.assume((b_68));

        }
        if (i < end) {
          int count1 = 0;
          int count2 = 0;
          {
            int j = begin;
            {
              int sum_88 = 0;
              int sum_89 = 0;
              {
                assert begin <= j;
                assert j <= end;

              }
              for (int quantVar278k = begin; begin <= quantVar278k && j - 1 >= quantVar278k; ++quantVar278k) {
                sum_88 += array1[i] == array1[quantVar278k] ? 1 : 0;

              }
              assert count1 == (sum_88);
              for (int quantVar279k = begin; begin <= quantVar279k && j - 1 >= quantVar279k; ++quantVar279k) {
                sum_89 += array1[i] == array2[quantVar279k] ? 1 : 0;

              }
              assert count2 == (sum_89);

            }
            j = CProver.nondetInt();
            count2 = CProver.nondetInt();
            count1 = CProver.nondetInt();
            int oldDecreasesClauseValue13 = end - j;
            {
              int sum_90 = 0;
              int sum_91 = 0;
              CProver.assume(begin <= j && j <= end);
              for (int quantVar280k = begin; begin <= quantVar280k && j - 1 >= quantVar280k; ++quantVar280k) {
                sum_90 += array1[i] == array1[quantVar280k] ? 1 : 0;

              }
              CProver.assume(count1 == (sum_90));
              for (int quantVar281k = begin; begin <= quantVar281k && j - 1 >= quantVar281k; ++quantVar281k) {
                sum_91 += array1[i] == array2[quantVar281k] ? 1 : 0;

              }
              CProver.assume(count2 == (sum_91));

            }
            if (j < end) {
              if (array1[i] == array1[j]) {
                count1++;

              }
              if (array1[i] == array2[j]) {
                count2++;

              }
              j++;
              {
                int sum_92 = 0;
                int sum_93 = 0;
                {
                  assert begin <= j;
                  assert j <= end;

                }
                for (int quantVar282k = begin; begin <= quantVar282k && j - 1 >= quantVar282k; ++quantVar282k) {
                  sum_92 += array1[i] == array1[quantVar282k] ? 1 : 0;

                }
                assert count1 == (sum_92);
                for (int quantVar283k = begin; begin <= quantVar283k && j - 1 >= quantVar283k; ++quantVar283k) {
                  sum_93 += array1[i] == array2[quantVar283k] ? 1 : 0;

                }
                assert count2 == (sum_93);

              }
              {
                assert end - j >= 0;
                assert end - j < oldDecreasesClauseValue13;

              }
              CProver.assume(false);

            }

          }
          if (count1 != count2) {
            {
              returnVar = false;
              throw new BlockQuickSort.ReturnException();

            }

          }
          i++;
          {
            int quantVar284j = CProver.nondetInt();
            int sum_94 = 0;
            int sum_95 = 0;
            {
              assert begin <= i;
              assert i <= end;

            }
            if (!!(begin <= quantVar284j && quantVar284j < i)) {
              for (int quantVar285k = begin; begin <= quantVar285k && end - 1 >= quantVar285k; ++quantVar285k) {
                sum_94 += array1[quantVar284j] == array1[quantVar285k] ? 1 : 0;

              }
              for (int quantVar286k = begin; begin <= quantVar286k && end - 1 >= quantVar286k; ++quantVar286k) {
                sum_95 += array1[quantVar284j] == array2[quantVar286k] ? 1 : 0;

              }

            }
            assert !(begin <= quantVar284j && quantVar284j < i) || (sum_94) == (sum_95);

          }
          {
            assert end - i >= 0;
            assert end - i < oldDecreasesClauseValue12;

          }
          CProver.assume(false);

        }

      }
      {
        returnVar = true;
        throw new BlockQuickSort.ReturnException();

      }

    } catch (BlockQuickSort.ReturnException ex) {

    }
    {
      assert array1.length == old63;

    }
    {
      assert array2.length == old64;

    }
    {
      int quantVar266i = CProver.nondetInt();
      int sum_80 = 0;
      int sum_81 = 0;
      int sum_82 = 0;
      int sum_83 = 0;
      boolean b_67 = false;
      if (!!returnVar) {
        if (!!(begin <= quantVar266i && quantVar266i < end)) {
          for (int quantVar267j = begin; begin <= quantVar267j && end - 1 >= quantVar267j; ++quantVar267j) {
            sum_80 += array1[quantVar266i] == array1[quantVar267j] ? 1 : 0;

          }
          for (int quantVar268j = begin; begin <= quantVar268j && end - 1 >= quantVar268j; ++quantVar268j) {
            sum_81 += array1[quantVar266i] == array2[quantVar268j] ? 1 : 0;

          }

        }

      }
      if (!returnVar || (!(begin <= quantVar266i && quantVar266i < end) || ((sum_80) == (sum_81)))) {
        for (int quantVar269i = begin; begin <= quantVar269i && end - 1 >= quantVar269i; ++quantVar269i) {
          for (int quantVar270j = begin; begin <= quantVar270j && end - 1 >= quantVar270j; ++quantVar270j) {
            sum_82 += array1[quantVar269i] == array1[quantVar270j] ? 1 : 0;

          }
          for (int quantVar271j = begin; begin <= quantVar271j && end - 1 >= quantVar271j; ++quantVar271j) {
            sum_83 += array1[quantVar269i] == array2[quantVar271j] ? 1 : 0;

          }
          b_67 = b_67 || !((sum_82) == (sum_83));

        }

      }
      {
        assert !returnVar || (!(begin <= quantVar266i && quantVar266i < end) || ((sum_80) == (sum_81)));
        assert b_67 || returnVar;

      }

    }
    return returnVar;

  }
    /*@
    public normal_behavior
      requires array1 != null; 
      requires array2 != null; 
      requires 0 <= begin && begin <= end && end <= array1.length; 
      requires array1.length == array2.length; 
      ensures array1.length == \old(array1.length); 
      ensures array2.length == \old(array2.length); 
      ensures \result == (\forall int i; begin <= i < end; ((\num_of int j; begin <= j < end; array1[i] == array1[j]) == (\num_of int j; begin <= j < end; array1[i] == array2[j]))); 
   */

   
  public static boolean permutation( 
  int[] array1,  
  int[] array2, int begin, int end) {
    //@ loop_invariant begin <= i <= end;
    //@ loop_invariant (\forall int j; begin <= j < i; (\num_of int k; begin <= k < end; array1[j] == array1[k]) == (\num_of int k; begin <= k < end; array1[j] == array2[k]));
    //@ loop_modifies i;
    //@ loop_decreases end - i;
    for (int i = begin; i < end; i++) {
      int count1 = 0;
      int count2 = 0;
      //@ loop_invariant begin <= j <= end;
      //@ loop_invariant count1 == (\num_of int k; begin <= k < j; array1[i] == array1[k]);
      //@ loop_invariant count2 == (\num_of int k; begin <= k < j; array1[i] == array2[k]);
      //@ loop_modifies j, count1, count2;
      //@ loop_decreases end - j;
      for (int j = begin; j < end; j++) {
        if (array1[i] == array1[j]) {
          count1++;

        }
        if (array1[i] == array2[j]) {
          count2++;

        }
        j++;

      }
      if (count1 != count2) {
        return false;

      }
      i++;

    }
    return true;

  }
  
  public static class ReturnException extends java.lang.RuntimeException {
  }
}