
import org.cprover.CProver;

public class BlockQuickSort {
    /*@
    public behavior
      assignable \nothing; 
      signals () false; 
   */

  public static BlockQuickSort BlockQuickSortSymb() {
    return new BlockQuickSort();
  }
  
  public static int hoareBlockPartitionSymb( 
  int[] array, int originalBegin, int originalEnd, int pivotPosition) {
    assert array != null;
    assert 0 <= originalBegin;
    assert originalBegin < originalEnd;
    assert originalEnd <= array.length;
    assert (originalEnd - originalBegin) >= 1;
    assert originalBegin <= pivotPosition;
    assert pivotPosition < originalEnd;
    int returnVar = CProver.nondetInt();
    int old0 = array.length;
    int old1 = array[pivotPosition];
    int[] old2 = array;
    if (array != null) {
      for (int __tmpVar__0 = originalBegin; __tmpVar__0 <= originalEnd - 1; ++__tmpVar__0) {
        array[__tmpVar__0] = CProver.nondetInt();
      }
    }
    CProver.assume(array.length == old0);
    CProver.assume(originalBegin <= returnVar && returnVar < originalEnd);
    CProver.assume(array[returnVar] == old1);
    boolean b_0 = true;
    b_0 = false;
    for (int quantVar0i = originalBegin; originalBegin <= quantVar0i && returnVar >= quantVar0i; ++quantVar0i) {
      b_0 = b_0 && array[quantVar0i] <= array[returnVar];
    }
    CProver.assume((b_0));
    boolean b_1 = true;
    b_1 = false;
    for (int quantVar1i = returnVar; returnVar <= quantVar1i && originalEnd - 1 >= quantVar1i; ++quantVar1i) {
      b_1 = b_1 && array[returnVar] <= array[quantVar1i];
    }
    CProver.assume((b_1));
    int[] $$param0 = null;
    int[] $$param1 = null;
    int $$param2 = 0;
    int $$param3 = 0;
    $$param0 = array;
    $$param1 = old2;
    $$param2 = originalBegin;
    $$param3 = originalEnd;
    CProver.assume(permutationSymb($$param0, $$param1, $$param2, $$param3));
    return returnVar;
  }
  
  public static void quickSortRecImplSymb( 
  int[] array, int begin, int end, int depth, int depthLimit) {
    assert array != null;
    assert 0 <= begin;
    assert begin <= end;
    assert end <= array.length;
    assert 0 <= depth;
    assert depth <= depthLimit;
    assert depthLimit < Integer.MAX_VALUE;
    int old3 = array.length;
    int[] old4 = array;
    if (array != null) {
      for (int __tmpVar__0 = begin; __tmpVar__0 <= end - 1; ++__tmpVar__0) {
        array[__tmpVar__0] = CProver.nondetInt();
      }
    }
    CProver.assume(array.length == old3);
    boolean b_2 = true;
    b_2 = false;
    for (int quantVar2i = begin; begin <= quantVar2i && end - 1 - 1 >= quantVar2i; ++quantVar2i) {
      b_2 = b_2 && array[quantVar2i] <= array[quantVar2i + 1];
    }
    CProver.assume((b_2));
    int[] $$param4 = null;
    int[] $$param5 = null;
    int $$param6 = 0;
    int $$param7 = 0;
    $$param4 = array;
    $$param5 = old4;
    $$param6 = begin;
    $$param7 = end;
    CProver.assume(permutationSymb($$param4, $$param5, $$param6, $$param7));
  }
  
  public static void insertionSortSymb( 
  int[] array, int begin, int end) {
    assert array != null;
    assert 0 <= begin;
    assert begin <= end;
    assert end <= array.length;
    int old5 = array.length;
    int[] old6 = array;
    if (array != null) {
      for (int __tmpVar__0 = begin; __tmpVar__0 <= end - 1; ++__tmpVar__0) {
        array[__tmpVar__0] = CProver.nondetInt();
      }
    }
    CProver.assume(array.length == old5);
    boolean b_3 = true;
    b_3 = false;
    for (int quantVar3i = begin; begin <= quantVar3i && end - 1 - 1 >= quantVar3i; ++quantVar3i) {
      b_3 = b_3 && array[quantVar3i] <= array[quantVar3i + 1];
    }
    CProver.assume((b_3));
    int[] $$param8 = null;
    int[] $$param9 = null;
    int $$param10 = 0;
    int $$param11 = 0;
    $$param8 = array;
    $$param9 = old6;
    $$param10 = begin;
    $$param11 = end;
    CProver.assume(permutationSymb($$param8, $$param9, $$param10, $$param11));
  }
  
  public static void swapSymb( 
  int[] array, int i, int j) {
    assert array != null;
    assert 0 <= i;
    assert i < array.length;
    assert 0 <= j;
    assert j < array.length;
    int old7 = array.length;
    int old8 = array[j];
    int old9 = array[i];
    array[i] = CProver.nondetInt();
    array[j] = CProver.nondetInt();
    CProver.assume(array.length == old7);
    CProver.assume(array[i] == old8 && array[j] == old9);
  }
  
  public static void sortPairSymb(int i1, int i2,  
  int[] array) {
    assert array != null;
    assert 0 <= i1;
    assert i1 < array.length;
    assert 0 <= i2;
    assert i2 < array.length;
    int old10 = array.length;
    int old11 = array[i1];
    int old12 = array[i2];
    int old13 = array[i1];
    int old14 = array[i2];
    int old15 = array[i2];
    int old16 = array[i1];
    array[i1] = CProver.nondetInt();
    array[i2] = CProver.nondetInt();
    CProver.assume(array.length == old10);
    CProver.assume((old11 <= old12) ? (array[i1] == old13 && array[i2] == old14) : (array[i1] == old15 && array[i2] == old16));
  }
  
  public static int medianOf3Symb( 
  int[] array, int begin, int end) {
    assert array != null;
    assert 0 <= begin;
    assert begin < end;
    assert end <= array.length;
    assert end - begin >= 3;
    int returnVar = CProver.nondetInt();
    int old17 = array.length;
    int[] old18 = array;
    array[begin] = CProver.nondetInt();
    array[begin + ((end - begin) / 2)] = CProver.nondetInt();
    array[end - 1] = CProver.nondetInt();
    CProver.assume(array.length == old17);
    CProver.assume(returnVar == begin + ((end - begin) / 2));
    CProver.assume(array[begin] <= array[returnVar] && array[returnVar] <= array[end - 1]);
    int[] $$param12 = null;
    int[] $$param13 = null;
    int $$param14 = 0;
    int $$param15 = 0;
    $$param12 = array;
    $$param13 = old18;
    $$param14 = begin;
    $$param15 = end;
    CProver.assume(permutationSymb($$param12, $$param13, $$param14, $$param15));
    return returnVar;
  }
  
  public static int partitionSymb( 
  int[] array, int begin, int end) {
    assert array != null;
    assert 0 <= begin;
    assert begin < end;
    assert end <= array.length;
    assert end - begin >= 3;
    int returnVar = CProver.nondetInt();
    int old19 = array.length;
    int[] old20 = array;
    if (array != null) {
      for (int __tmpVar__0 = begin; __tmpVar__0 <= end - 1; ++__tmpVar__0) {
        array[__tmpVar__0] = CProver.nondetInt();
      }
    }
    CProver.assume(array.length == old19);
    CProver.assume(begin <= returnVar && returnVar < end);
    boolean b_4 = true;
    b_4 = false;
    for (int quantVar4i = begin; begin <= quantVar4i && returnVar >= quantVar4i; ++quantVar4i) {
      b_4 = b_4 && array[quantVar4i] <= array[returnVar];
    }
    CProver.assume((b_4));
    boolean b_5 = true;
    b_5 = false;
    for (int quantVar5i = returnVar; returnVar <= quantVar5i && end - 1 >= quantVar5i; ++quantVar5i) {
      b_5 = b_5 && array[returnVar] <= array[quantVar5i];
    }
    CProver.assume((b_5));
    int[] $$param16 = null;
    int[] $$param17 = null;
    int $$param18 = 0;
    int $$param19 = 0;
    $$param16 = array;
    $$param17 = old20;
    $$param18 = begin;
    $$param19 = end;
    CProver.assume(permutationSymb($$param16, $$param17, $$param18, $$param19));
    return returnVar;
  }
  
  public static int log2Symb(int n) {
    assert n > 0;
    int returnVar = CProver.nondetInt();
    CProver.assume(0 <= returnVar && (1 << (returnVar - 1)) < n && n <= (1 << returnVar) && returnVar <= 31);
    return returnVar;
  }
  
  public static boolean permutationSymb( 
  int[] array1,  
  int[] array2, int begin, int end) {
    assert array1 != null;
    assert array2 != null;
    assert 0 <= begin;
    assert begin <= end;
    assert end <= array1.length;
    assert array1.length == array2.length;
    boolean returnVar = CProver.nondetBoolean();
    int old21 = array1.length;
    int old22 = array2.length;
    CProver.assume(array1.length == old21);
    CProver.assume(array2.length == old22);
    boolean b_6 = true;
    int sum_0 = 0;
    int sum_1 = 0;
    int quantVar9i = CProver.nondetInt();
    int sum_2 = 0;
    int sum_3 = 0;
    if (!!returnVar) {
      b_6 = false;
      for (int quantVar6i = begin; begin <= quantVar6i && end - 1 >= quantVar6i; ++quantVar6i) {
        sum_0 = 0;
        for (int quantVar7j = begin; begin <= quantVar7j && end - 1 >= quantVar7j; ++quantVar7j) {
          sum_0 += array1[quantVar6i] == array1[quantVar7j] ? 1 : 0;
        }
        sum_1 = 0;
        for (int quantVar8j = begin; begin <= quantVar8j && end - 1 >= quantVar8j; ++quantVar8j) {
          sum_1 += array1[quantVar6i] == array2[quantVar8j] ? 1 : 0;
        }
        b_6 = b_6 && ((sum_0) == (sum_1));
      }
    }
    if (!returnVar || (b_6)) {
      if (begin <= quantVar9i && quantVar9i < end) {
        sum_2 = 0;
        for (int quantVar10j = begin; begin <= quantVar10j && end - 1 >= quantVar10j; ++quantVar10j) {
          sum_2 += array1[quantVar9i] == array1[quantVar10j] ? 1 : 0;
        }
        sum_3 = 0;
        for (int quantVar11j = begin; begin <= quantVar11j && end - 1 >= quantVar11j; ++quantVar11j) {
          sum_3 += array1[quantVar9i] == array2[quantVar11j] ? 1 : 0;
        }
      }
    }
    CProver.assume((!returnVar || (b_6)) && (begin <= quantVar9i && quantVar9i < end && !((sum_2) == (sum_3)) || returnVar));
    return returnVar;
  }
  
  public BlockQuickSort() {
    {
    }
  }
  private static final int BLOCKSIZE = 2;
  private static final int IS_THRESH = 3;
  private static final int STACK_SIZE = 10;
  private static final int DEPTH_STACK_SIZE = 10;
  
  public static int hoareBlockPartitionVerf( 
  int[] array, int originalBegin, int originalEnd, int pivotPosition) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= originalBegin && originalBegin < originalEnd && originalEnd <= array.length);
    }
    {
      CProver.assume((originalEnd - originalBegin) >= 1);
    }
    {
      CProver.assume(originalBegin <= pivotPosition && pivotPosition < originalEnd);
    }
    int old23 = array.length;
    int old24 = array[pivotPosition];
    int[] old25 = array;
    int[] old26 = array;
    int old27 = originalEnd - 1;
    int old28 = originalBegin;
    int returnVar = 0;
    try {
      int[] $$param24 = null;
      int $$param25 = 0;
      int $$param26 = 0;
      int[] $$param27 = null;
      int $$param28 = 0;
      int $$param29 = 0;
      int[] $$param30 = null;
      int $$param31 = 0;
      int $$param32 = 0;
      int[] $$param33 = null;
      int $$param34 = 0;
      int $$param35 = 0;
      int[] $$param36 = null;
      int $$param37 = 0;
      int $$param38 = 0;
      int[] $$param39 = null;
      int $$param40 = 0;
      int $$param41 = 0;
      int[] $$param42 = null;
      int $$param43 = 0;
      int $$param44 = 0;
      int[] $$param45 = null;
      int $$param46 = 0;
      int $$param47 = 0;
       
      int[] indexL = new int[BLOCKSIZE];
       
      int[] indexR = new int[BLOCKSIZE];
      int begin = originalBegin;
      int end = originalEnd;
      int last = end - 1;
      int pivot = array[pivotPosition];
      $$param24 = array;
      $$param25 = pivotPosition;
      $$param26 = last;
      assert !(true && (old26 != $$param24 || $$param25 > old27 || $$param25 < old28)) : "Illegal assignment to array[i] conflicting with assignables array[originalBegin .. originalEnd - 1]";
      assert !(true && (old26 != $$param24 || $$param26 > old27 || $$param26 < old28)) : "Illegal assignment to array[j] conflicting with assignables array[originalBegin .. originalEnd - 1]";
      swapSymb($$param24, $$param25, $$param26);
      assert !false : "Illegal assignment to pivotPosition = last conflicting with assignables array[originalBegin .. originalEnd - 1]";
      pivotPosition = last;
      last--;
      int numLeft = 0;
      int numRight = 0;
      int startLeft = 0;
      int startRight = 0;
      int num = 0;
      if (last - begin + 1 > 2 * BLOCKSIZE) {
        while (last - begin + 1 > 2 * BLOCKSIZE) {
          if (numLeft == 0) {
            assert !false : "Illegal assignment to startLeft = 0 conflicting with assignables array[originalBegin .. originalEnd - 1]";
            startLeft = 0;
            for (int j = 0; j < BLOCKSIZE; ) {
              assert !false : "Illegal assignment to indexL[numLeft] = j conflicting with assignables array[originalBegin .. originalEnd - 1]";
              indexL[numLeft] = j;
              numLeft += array[begin + j] >= pivot ? 1 : 0;
              j++;
            }
          }
          if (numRight == 0) {
            assert !false : "Illegal assignment to startRight = 0 conflicting with assignables array[originalBegin .. originalEnd - 1]";
            startRight = 0;
            for (int j = 0; j < BLOCKSIZE; ) {
              assert !false : "Illegal assignment to indexR[numRight] = j conflicting with assignables array[originalBegin .. originalEnd - 1]";
              indexR[numRight] = j;
              numRight += pivot >= array[last - j] ? 1 : 0;
              j++;
            }
          }
          assert !false : "Illegal assignment to num = min(numLeft, numRight) conflicting with assignables array[originalBegin .. originalEnd - 1]";
          num = min(numLeft, numRight);
          if (num > 0) {
            for (int j = 0; j < num; ) {
              $$param27 = array;
              $$param28 = begin + indexL[startLeft + j];
              $$param29 = last - indexR[startRight + j];
              assert !(true && (old26 != $$param27 || $$param28 > old27 || $$param28 < old28)) : "Illegal assignment to array[i] conflicting with assignables array[originalBegin .. originalEnd - 1]";
              assert !(true && (old26 != $$param27 || $$param29 > old27 || $$param29 < old28)) : "Illegal assignment to array[j] conflicting with assignables array[originalBegin .. originalEnd - 1]";
              swapSymb($$param27, $$param28, $$param29);
              j++;
            }
          }
          numLeft -= num;
          numRight -= num;
          startLeft += num;
          startRight += num;
          begin += (numLeft == 0) ? BLOCKSIZE : 0;
          last -= (numRight == 0) ? BLOCKSIZE : 0;
        }
      }
      int shiftR = 0;
      int shiftL = 0;
      if (numRight == 0 && numLeft == 0) {
        assert !false : "Illegal assignment to shiftL = ((last - begin) + 1) / 2 conflicting with assignables array[originalBegin .. originalEnd - 1]";
        shiftL = ((last - begin) + 1) / 2;
        assert !false : "Illegal assignment to shiftR = (last - begin) + 1 - shiftL conflicting with assignables array[originalBegin .. originalEnd - 1]";
        shiftR = (last - begin) + 1 - shiftL;
        assert !false : "Illegal assignment to startLeft = 0 conflicting with assignables array[originalBegin .. originalEnd - 1]";
        startLeft = 0;
        assert !false : "Illegal assignment to startRight = 0 conflicting with assignables array[originalBegin .. originalEnd - 1]";
        startRight = 0;
        for (int j = 0; j < shiftL; ) {
          assert !false : "Illegal assignment to indexL[numLeft] = j conflicting with assignables array[originalBegin .. originalEnd - 1]";
          indexL[numLeft] = j;
          numLeft += array[begin + j] >= pivot ? 1 : 0;
          assert !false : "Illegal assignment to indexR[numRight] = j conflicting with assignables array[originalBegin .. originalEnd - 1]";
          indexR[numRight] = j;
          numRight += pivot >= array[last - j] ? 1 : 0;
          j++;
        }
        if (shiftL < shiftR) {
          assert !false : "Illegal assignment to indexR[numRight] = shiftR - 1 conflicting with assignables array[originalBegin .. originalEnd - 1]";
          indexR[numRight] = shiftR - 1;
          numRight += pivot >= array[last - shiftR + 1] ? 1 : 0;
        }
      } else if (numRight != 0) {
        assert !false : "Illegal assignment to shiftL = (last - begin) - BLOCKSIZE + 1 conflicting with assignables array[originalBegin .. originalEnd - 1]";
        shiftL = (last - begin) - BLOCKSIZE + 1;
        assert !false : "Illegal assignment to shiftR = BLOCKSIZE conflicting with assignables array[originalBegin .. originalEnd - 1]";
        shiftR = BLOCKSIZE;
        assert !false : "Illegal assignment to startLeft = 0 conflicting with assignables array[originalBegin .. originalEnd - 1]";
        startLeft = 0;
        for (int j = 0; j < shiftL; ) {
          assert !false : "Illegal assignment to indexL[numLeft] = j conflicting with assignables array[originalBegin .. originalEnd - 1]";
          indexL[numLeft] = j;
          numLeft += array[begin + j] >= pivot ? 1 : 0;
          j++;
        }
      } else {
        assert !false : "Illegal assignment to shiftL = BLOCKSIZE conflicting with assignables array[originalBegin .. originalEnd - 1]";
        shiftL = BLOCKSIZE;
        assert !false : "Illegal assignment to shiftR = (last - begin) - BLOCKSIZE + 1 conflicting with assignables array[originalBegin .. originalEnd - 1]";
        shiftR = (last - begin) - BLOCKSIZE + 1;
        assert !false : "Illegal assignment to startRight = 0 conflicting with assignables array[originalBegin .. originalEnd - 1]";
        startRight = 0;
        for (int j = 0; j < shiftR; ) {
          assert !false : "Illegal assignment to indexR[numRight] = j conflicting with assignables array[originalBegin .. originalEnd - 1]";
          indexR[numRight] = j;
          numRight += pivot >= array[last - j] ? 1 : 0;
          j++;
        }
      }
      assert !false : "Illegal assignment to num = min(numLeft, numRight) conflicting with assignables array[originalBegin .. originalEnd - 1]";
      num = min(numLeft, numRight);
      if (num > 0) {
        for (int j = 0; j < num; ) {
          $$param30 = array;
          $$param31 = begin + indexL[startLeft + j];
          $$param32 = last - indexR[startRight + j];
          assert !(true && (old26 != $$param30 || $$param31 > old27 || $$param31 < old28)) : "Illegal assignment to array[i] conflicting with assignables array[originalBegin .. originalEnd - 1]";
          assert !(true && (old26 != $$param30 || $$param32 > old27 || $$param32 < old28)) : "Illegal assignment to array[j] conflicting with assignables array[originalBegin .. originalEnd - 1]";
          swapSymb($$param30, $$param31, $$param32);
          j++;
        }
      }
      numLeft -= num;
      numRight -= num;
      startLeft += num;
      startRight += num;
      begin += (numLeft == 0) ? shiftL : 0;
      last -= (numRight == 0) ? shiftR : 0;
      if (numLeft != 0) {
        int lowerI = startLeft + numLeft - 1;
        int upper = last - begin;
        while (lowerI >= startLeft && indexL[lowerI] == upper) {
          upper--;
          lowerI--;
        }
        while (lowerI >= startLeft) {
          $$param33 = array;
          $$param34 = begin + upper;
          $$param35 = begin + indexL[lowerI];
          assert !(true && (old26 != $$param33 || $$param34 > old27 || $$param34 < old28)) : "Illegal assignment to array[i] conflicting with assignables array[originalBegin .. originalEnd - 1]";
          assert !(true && (old26 != $$param33 || $$param35 > old27 || $$param35 < old28)) : "Illegal assignment to array[j] conflicting with assignables array[originalBegin .. originalEnd - 1]";
          swapSymb($$param33, $$param34, $$param35);
          upper--;
          lowerI--;
        }
        $$param36 = array;
        $$param37 = pivotPosition;
        $$param38 = begin + upper + 1;
        assert !(true && (old26 != $$param36 || $$param37 > old27 || $$param37 < old28)) : "Illegal assignment to array[i] conflicting with assignables array[originalBegin .. originalEnd - 1]";
        assert !(true && (old26 != $$param36 || $$param38 > old27 || $$param38 < old28)) : "Illegal assignment to array[j] conflicting with assignables array[originalBegin .. originalEnd - 1]";
        swapSymb($$param36, $$param37, $$param38);
        {
          returnVar = begin + upper + 1;
          throw new BlockQuickSort.ReturnException();
        }
      } else if (numRight != 0) {
        int lowerI = startRight + numRight - 1;
        int upper = last - begin;
        while (lowerI >= startRight && indexR[lowerI] == upper) {
          upper--;
          lowerI--;
        }
        while (lowerI >= startRight) {
          $$param39 = array;
          $$param40 = last - upper;
          $$param41 = last - indexR[lowerI];
          assert !(true && (old26 != $$param39 || $$param40 > old27 || $$param40 < old28)) : "Illegal assignment to array[i] conflicting with assignables array[originalBegin .. originalEnd - 1]";
          assert !(true && (old26 != $$param39 || $$param41 > old27 || $$param41 < old28)) : "Illegal assignment to array[j] conflicting with assignables array[originalBegin .. originalEnd - 1]";
          swapSymb($$param39, $$param40, $$param41);
          upper--;
          lowerI--;
        }
        $$param42 = array;
        $$param43 = pivotPosition;
        $$param44 = last - upper;
        assert !(true && (old26 != $$param42 || $$param43 > old27 || $$param43 < old28)) : "Illegal assignment to array[i] conflicting with assignables array[originalBegin .. originalEnd - 1]";
        assert !(true && (old26 != $$param42 || $$param44 > old27 || $$param44 < old28)) : "Illegal assignment to array[j] conflicting with assignables array[originalBegin .. originalEnd - 1]";
        swapSymb($$param42, $$param43, $$param44);
        {
          returnVar = last - upper;
          throw new BlockQuickSort.ReturnException();
        }
      } else {
        $$param45 = array;
        $$param46 = pivotPosition;
        $$param47 = begin;
        assert !(true && (old26 != $$param45 || $$param46 > old27 || $$param46 < old28)) : "Illegal assignment to array[i] conflicting with assignables array[originalBegin .. originalEnd - 1]";
        assert !(true && (old26 != $$param45 || $$param47 > old27 || $$param47 < old28)) : "Illegal assignment to array[j] conflicting with assignables array[originalBegin .. originalEnd - 1]";
        swapSymb($$param45, $$param46, $$param47);
        {
          returnVar = begin;
          throw new BlockQuickSort.ReturnException();
        }
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old23;
    }
    {
      {
        assert originalBegin <= returnVar;
        assert returnVar < originalEnd;
      }
    }
    {
      assert array[returnVar] == old24;
    }
    {
      int quantVar12i = CProver.nondetInt();
      assert !(originalBegin <= quantVar12i && quantVar12i <= returnVar) || array[quantVar12i] <= array[returnVar];
    }
    {
      int quantVar13i = CProver.nondetInt();
      assert !(returnVar <= quantVar13i && quantVar13i < originalEnd) || array[returnVar] <= array[quantVar13i];
    }
    {
      int[] $$param20 = null;
      int[] $$param21 = null;
      int $$param22 = 0;
      int $$param23 = 0;
      $$param20 = array;
      $$param21 = old25;
      $$param22 = originalBegin;
      $$param23 = originalEnd;
      assert permutationSymb($$param20, $$param21, $$param22, $$param23);
    }
    return returnVar;
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= originalBegin && originalBegin < originalEnd && originalEnd <= array.length; 
      requires (originalEnd - originalBegin) >= 1; 
      requires originalBegin <= pivotPosition && pivotPosition < originalEnd; 
      ensures array.length == \old(array.length); 
      ensures originalBegin <= \result && \result < originalEnd; 
      ensures array[\result] == \old(array[pivotPosition]); 
      ensures (\forall int i; originalBegin <= i <= \result; array[i] <= array[\result]); 
      ensures (\forall int i; \result <= i < originalEnd; array[\result] <= array[i]); 
      ensures permutation(array, \old(array), originalBegin, originalEnd); 
      assignable array[originalBegin .. originalEnd - 1]; 
   */

  public static int hoareBlockPartition( 
  int[] array, int originalBegin, int originalEnd, int pivotPosition) {
     
    int[] indexL = new int[BLOCKSIZE];
     
    int[] indexR = new int[BLOCKSIZE];
    int begin = originalBegin;
    int end = originalEnd;
    int last = end - 1;
    int pivot = array[pivotPosition];
    swap(array, pivotPosition, last);
    pivotPosition = last;
    last--;
    int numLeft = 0;
    int numRight = 0;
    int startLeft = 0;
    int startRight = 0;
    int num = 0;
    if (last - begin + 1 > 2 * BLOCKSIZE) {
      //@ loop_invariant originalBegin <= begin && begin <= last && last < originalEnd - 1;
      //@ loop_invariant 0 <= numLeft && numLeft <= BLOCKSIZE;
      //@ loop_invariant 0 <= numRight && numRight <= BLOCKSIZE;
      //@ loop_invariant 0 <= startLeft && startLeft <= BLOCKSIZE && startLeft + numLeft <= BLOCKSIZE;
      //@ loop_invariant 0 <= startRight && startRight <= BLOCKSIZE && startRight + numRight <= BLOCKSIZE;
      //@ loop_invariant 0 <= num && num <= BLOCKSIZE;
      //@ loop_invariant numRight == 0 || numLeft == 0;
      //@ loop_invariant array[originalEnd - 1] == \old(array[pivotPosition]);
      //@ loop_invariant (\exists int i; 0 <= i < (originalEnd - originalBegin); begin == originalBegin + i * BLOCKSIZE);
      //@ loop_invariant (\exists int i; 0 <= i < (originalEnd - originalBegin); last == originalEnd - 2 - i * BLOCKSIZE);
      //@ loop_invariant (\forall int i; 0 <= i < BLOCKSIZE; 0 <= indexL[i] && indexL[i] < BLOCKSIZE);
      //@ loop_invariant (\forall int i; 0 <= i < numLeft; indexL[startLeft + i] < last - begin && pivot <= array[begin + indexL[startLeft + i]]);
      //@ loop_invariant (\forall int i; 0 <= i < startLeft + numLeft - 1; indexL[i] < indexL[i + 1]);
      //@ loop_invariant (numLeft != 0) ==> numLeft == (\num_of int i; startLeft <= i < BLOCKSIZE; pivot <= array[begin + i]);
      //@ loop_invariant (\forall int i; 0 <= i < BLOCKSIZE; 0 <= indexR[i] && indexR[i] < BLOCKSIZE);
      //@ loop_invariant (\forall int i; 0 <= i < numRight; indexR[startRight + i] < last - begin && array[last - indexR[startRight + i]] <= pivot);
      //@ loop_invariant (\forall int i; 0 <= i < startRight + numRight - 1; indexR[i] < indexR[i + 1]);
      //@ loop_invariant (numRight != 0) ==> numRight == (\num_of int i; startRight <= i < BLOCKSIZE; array[last - i] <= pivot);
      //@ loop_invariant (numLeft == 0) ==> (\forall int i; originalBegin <= i < begin; array[i] <= pivot);
      //@ loop_invariant (numLeft != 0) ==> (\forall int i; originalBegin <= i < begin + indexL[startLeft]; array[i] <= pivot);
      //@ loop_invariant (numRight == 0) ==> (\forall int i; last < i < originalEnd; pivot <= array[i]);
      //@ loop_invariant (numRight != 0) ==> (\forall int i; last - indexR[startRight] < i < originalEnd; pivot <= array[i]);
      //@ loop_invariant permutation(array, \old(array), originalBegin, originalEnd);
      //@ loop_modifies array[max(begin, originalBegin) .. min(begin + BLOCKSIZE - 1, originalEnd - 2)], array[max(last - BLOCKSIZE - 1, originalBegin) .. min(last, originalEnd - 2)], last, begin, numLeft, numRight, startLeft, startRight, num, indexL[0 .. BLOCKSIZE - 1], indexR[0 .. BLOCKSIZE - 1];
      //@ loop_decreases last - begin;
      while (last - begin + 1 > 2 * BLOCKSIZE) {
        if (numLeft == 0) {
          startLeft = 0;
          //@ loop_invariant 0 <= j <= BLOCKSIZE;
          //@ loop_invariant numLeft == (\num_of int k; 0 <= k < j; pivot <= array[begin + k]);
          //@ loop_invariant (\forall int k; 0 <= k < numLeft; 0 <= indexL[k] && indexL[k] < j && pivot <= array[begin + indexL[k]]);
          //@ loop_invariant (\forall int k; 0 <= k < BLOCKSIZE; 0 <= indexL[k] && indexL[k] < BLOCKSIZE);
          //@ loop_invariant (\forall int k; 0 <= k < numLeft - 1; indexL[k] < indexL[k + 1]);
          //@ loop_modifies numLeft, indexL[0 .. BLOCKSIZE - 1], j;
          //@ loop_decreases BLOCKSIZE - j;
          for (int j = 0; j < BLOCKSIZE; j++) {
            indexL[numLeft] = j;
            numLeft += array[begin + j] >= pivot ? 1 : 0;
          }
        }
        if (numRight == 0) {
          startRight = 0;
          //@ loop_invariant 0 <= j <= BLOCKSIZE;
          //@ loop_invariant numRight == (\num_of int k; 0 <= k < j; array[last - k] <= pivot);
          //@ loop_invariant (\forall int k; 0 <= k < numRight; 0 <= indexR[k] && indexR[k] < j && array[last - indexR[k]] <= pivot);
          //@ loop_invariant (\forall int k; 0 <= k < BLOCKSIZE; 0 <= indexR[k] && indexR[k] < BLOCKSIZE);
          //@ loop_invariant (\forall int k; 0 <= k < numRight - 1; indexR[k] < indexR[k + 1]);
          //@ loop_modifies numRight, indexR[0 .. BLOCKSIZE - 1], j;
          //@ loop_decreases BLOCKSIZE - j;
          for (int j = 0; j < BLOCKSIZE; j++) {
            indexR[numRight] = j;
            numRight += pivot >= array[last - j] ? 1 : 0;
          }
        }
        num = min(numLeft, numRight);
        if (num > 0) {
          //@ loop_invariant 0 <= j <= num;
          //@ loop_invariant (\forall int i; originalBegin <= i < begin + indexL[startLeft]; array[i] <= pivot);
          //@ loop_invariant j > 0 ==> (\forall int i; originalBegin <= i <= begin + indexL[startLeft + j - 1]; array[i] <= pivot);
          //@ loop_invariant (\forall int i; last - indexR[startRight] < i < originalEnd; pivot <= array[i]);
          //@ loop_invariant j > 0 ==> (\forall int i; last - indexR[startRight + j - 1] <= i < originalEnd; pivot <= array[i]);
          //@ loop_invariant (\forall int i; startLeft + j <= i < startLeft + numLeft; pivot <= array[begin + indexL[i]]);
          //@ loop_invariant (\forall int i; startRight + j <= i < startRight + numRight; array[last - indexR[i]] <= pivot);
          //@ loop_invariant permutation(array, \old(array), begin, last + 1);
          //@ loop_modifies array[begin + indexL[startLeft] .. begin + indexL[startLeft + num - 1]], array[last - indexR[startRight + num - 1] .. last - indexR[startRight]], j;
          //@ loop_decreases num - j;
          for (int j = 0; j < num; j++) {
            swap(array, begin + indexL[startLeft + j], last - indexR[startRight + j]);
          }
        }
        numLeft -= num;
        numRight -= num;
        startLeft += num;
        startRight += num;
        begin += (numLeft == 0) ? BLOCKSIZE : 0;
        last -= (numRight == 0) ? BLOCKSIZE : 0;
      }
    }
    int shiftR = 0;
    int shiftL = 0;
    if (numRight == 0 && numLeft == 0) {
      shiftL = ((last - begin) + 1) / 2;
      shiftR = (last - begin) + 1 - shiftL;
      startLeft = 0;
      startRight = 0;
      //@ loop_invariant 0 <= j <= shiftL;
      //@ loop_invariant 0 <= numLeft && numLeft <= j;
      //@ loop_invariant 0 <= numRight && numRight <= j;
      //@ loop_invariant numLeft == (\num_of int k; 0 <= k < j; pivot <= array[begin + k]);
      //@ loop_invariant numRight == (\num_of int k; 0 <= k < j; array[last - k] <= pivot);
      //@ loop_invariant (\forall int k; 0 <= k < numLeft; 0 <= indexL[k] && indexL[k] < j && pivot <= array[begin + indexL[k]]);
      //@ loop_invariant (\forall int k; 0 <= k < BLOCKSIZE; 0 <= indexL[k] && indexL[k] < BLOCKSIZE);
      //@ loop_invariant (\forall int k; 0 <= k < numRight; 0 <= indexR[k] && indexR[k] < j && array[last - indexR[k]] <= pivot);
      //@ loop_invariant (\forall int k; 0 <= k < BLOCKSIZE; 0 <= indexR[k] && indexR[k] < BLOCKSIZE);
      //@ loop_invariant (\forall int k; 0 <= k < numLeft - 1; indexL[k] < indexL[k + 1]);
      //@ loop_invariant (\forall int k; 0 <= k < numRight - 1; indexR[k] < indexR[k + 1]);
      //@ loop_decreases shiftL - j;
      //@ loop_modifies indexL[0 .. shiftL - 1], numLeft, indexR[0 .. shiftL - 1], numRight, j;
      for (int j = 0; j < shiftL; j++) {
        indexL[numLeft] = j;
        numLeft += array[begin + j] >= pivot ? 1 : 0;
        indexR[numRight] = j;
        numRight += pivot >= array[last - j] ? 1 : 0;
      }
      if (shiftL < shiftR) {
        indexR[numRight] = shiftR - 1;
        numRight += pivot >= array[last - shiftR + 1] ? 1 : 0;
      }
    } else if (numRight != 0) {
      shiftL = (last - begin) - BLOCKSIZE + 1;
      shiftR = BLOCKSIZE;
      startLeft = 0;
      //@ loop_invariant 0 <= j <= shiftL;
      //@ loop_invariant numLeft == (\num_of int k; 0 <= k < j; pivot <= array[begin + k]);
      //@ loop_invariant (\forall int k; 0 <= k < numLeft; 0 <= indexL[k] && indexL[k] < j && pivot <= array[begin + indexL[k]]);
      //@ loop_invariant (\forall int k; 0 <= k < BLOCKSIZE; 0 <= indexL[k] && indexL[k] < BLOCKSIZE);
      //@ loop_invariant (\forall int k; 0 <= k < numLeft - 1; indexL[k] < indexL[k + 1]);
      //@ loop_modifies numLeft, indexL[0 .. shiftL - 1], j;
      //@ loop_decreases shiftL - j;
      for (int j = 0; j < shiftL; j++) {
        indexL[numLeft] = j;
        numLeft += array[begin + j] >= pivot ? 1 : 0;
      }
    } else {
      shiftL = BLOCKSIZE;
      shiftR = (last - begin) - BLOCKSIZE + 1;
      startRight = 0;
      //@ loop_invariant 0 <= j <= shiftR;
      //@ loop_invariant numRight == (\num_of int k; 0 <= k < j; array[last - k] <= pivot);
      //@ loop_invariant (\forall int k; 0 <= k < numRight; 0 <= indexR[k] && indexR[k] < j && array[last - indexR[k]] <= pivot);
      //@ loop_invariant (\forall int k; 0 <= k < BLOCKSIZE; 0 <= indexR[k] && indexR[k] < BLOCKSIZE);
      //@ loop_invariant (\forall int k; 0 <= k < numRight - 1; indexR[k] < indexR[k + 1]);
      //@ loop_modifies numRight, indexR[0 .. shiftR - 1], j;
      //@ loop_decreases shiftR - j;
      for (int j = 0; j < shiftR; j++) {
        indexR[numRight] = j;
        numRight += pivot >= array[last - j] ? 1 : 0;
      }
    }
    num = min(numLeft, numRight);
    if (num > 0) {
      //@ loop_invariant 0 <= j <= num;
      //@ loop_invariant (\forall int i; originalBegin <= i < begin + indexL[startLeft]; array[i] <= pivot);
      //@ loop_invariant j > 0 ==> (\forall int i; originalBegin <= i <= begin + indexL[startLeft + j - 1]; array[i] <= pivot);
      //@ loop_invariant (\forall int i; last - indexR[startRight] < i < originalEnd; pivot <= array[i]);
      //@ loop_invariant j > 0 ==> (\forall int i; last - indexR[startRight + j - 1] <= i < originalEnd; pivot <= array[i]);
      //@ loop_invariant (\forall int i; startLeft + j <= i < startLeft + numLeft; pivot <= array[begin + indexL[i]]);
      //@ loop_invariant (\forall int i; startRight + j <= i < startRight + numRight; array[last - indexR[i]] <= pivot);
      //@ loop_invariant permutation(array, \old(array), begin, last + 1);
      //@ loop_modifies array[begin + indexL[startLeft] .. begin + indexL[startLeft + num - 1]], array[last - indexR[startRight + num - 1] .. last - indexR[startRight]], j;
      //@ loop_decreases num - j;
      for (int j = 0; j < num; j++) {
        swap(array, begin + indexL[startLeft + j], last - indexR[startRight + j]);
      }
    }
    numLeft -= num;
    numRight -= num;
    startLeft += num;
    startRight += num;
    begin += (numLeft == 0) ? shiftL : 0;
    last -= (numRight == 0) ? shiftR : 0;
    if (numLeft != 0) {
      int lowerI = startLeft + numLeft - 1;
      int upper = last - begin;
      //@ loop_invariant 0 <= startLeft && startLeft - 1 <= lowerI && lowerI < startLeft + numLeft && startLeft + numLeft <= BLOCKSIZE;
      //@ loop_invariant upper == last - begin - (startLeft + numLeft - 1 - lowerI);
      //@ loop_invariant (\forall int i; lowerI < i < startLeft + numLeft - 1; indexL[i] == upper + (i - lowerI));
      //@ loop_invariant (\forall int i; begin <= i < begin + indexL[startLeft]; array[i] <= pivot);
      //@ loop_invariant (\forall int i; begin + upper < i <= last; pivot <= array[i]);
      //@ loop_modifies lowerI, upper;
      //@ loop_decreases lowerI + 1;
      while (lowerI >= startLeft && indexL[lowerI] == upper) {
        upper--;
        lowerI--;
      }
      //@ loop_invariant 0 <= startLeft && startLeft - 1 <= lowerI && lowerI < startLeft + numLeft && startLeft + numLeft <= BLOCKSIZE;
      //@ loop_invariant upper == last - begin - (startLeft + numLeft - 1 - lowerI);
      //@ loop_invariant (\forall int i; startLeft <= i < lowerI; indexL[i] == indexL[i + 1] - 1);
      //@ loop_invariant (\forall int i; begin + indexL[startLeft] <= i < begin + upper; pivot <= array[i]);
      //@ loop_invariant (\forall int i; begin + upper < i <= last; pivot <= array[i]);
      //@ loop_invariant lowerI >= startLeft ==> indexL[lowerI] == upper || array[begin + upper] <= pivot;
      //@ loop_invariant lowerI < startLeft && upper >= 0 ==> array[begin + upper] <= pivot;
      //@ loop_invariant permutation(array, \old(array), begin, last + 1);
      //@ loop_modifies upper, lowerI, array[begin + indexL[startLeft] .. last];
      //@ loop_decreases lowerI + 1;
      while (lowerI >= startLeft) {
        swap(array, begin + upper, begin + indexL[lowerI]);
        upper--;
        lowerI--;
      }
      swap(array, pivotPosition, begin + upper + 1);
      return begin + upper + 1;
    } else if (numRight != 0) {
      int lowerI = startRight + numRight - 1;
      int upper = last - begin;
      //@ loop_invariant 0 <= startRight && startRight - 1 <= lowerI && lowerI < startRight + numRight && startRight + numRight <= BLOCKSIZE;
      //@ loop_invariant upper == last - begin - (startRight + numRight - 1 - lowerI);
      //@ loop_invariant (\forall int i; lowerI < i < startRight + numRight - 1; indexR[i] == upper + (i - lowerI));
      //@ loop_invariant (\forall int i; last - indexR[startRight] < i <= last; pivot <= array[i]);
      //@ loop_invariant (\forall int i; begin <= i < last - upper; array[i] <= pivot);
      //@ loop_modifies lowerI, upper;
      //@ loop_decreases lowerI + 1;
      while (lowerI >= startRight && indexR[lowerI] == upper) {
        upper--;
        lowerI--;
      }
      //@ loop_invariant 0 <= startRight && startRight - 1 <= lowerI && lowerI < startRight + numRight && startRight + numRight <= BLOCKSIZE;
      //@ loop_invariant upper == last - begin - (startRight + numRight - 1 - lowerI);
      //@ loop_invariant (\forall int i; startRight <= i < lowerI; indexR[i] == indexR[i + 1] - 1);
      //@ loop_invariant (\forall int i; begin <= i < last - upper; array[i] <= pivot);
      //@ loop_invariant (\forall int i; last - upper < i <= last - indexR[startRight]; array[i] <= pivot);
      //@ loop_invariant lowerI >= startRight ==> indexR[lowerI] == upper || pivot <= array[last - upper];
      //@ loop_invariant lowerI < startRight && upper >= 0 ==> pivot <= array[last - upper];
      //@ loop_invariant permutation(array, \old(array), begin, last + 1);
      //@ loop_modifies upper, lowerI, array[begin .. last - indexR[startRight]];
      //@ loop_decreases lowerI + 1;
      while (lowerI >= startRight) {
        swap(array, last - upper, last - indexR[lowerI]);
        upper--;
        lowerI--;
      }
      swap(array, pivotPosition, last - upper);
      return last - upper;
    } else {
      swap(array, pivotPosition, begin);
      return begin;
    }
  }
  
  public static void quickSortVerf( 
  int[] array, int originalBegin, int originalEnd) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= originalBegin && originalBegin < originalEnd && originalEnd <= array.length);
    }
    int old29 = array.length;
    int[] old30 = array;
    int[] old31 = array;
    int old32 = originalEnd - 1;
    int old33 = originalBegin;
    try {
      int $$param52 = 0;
      int[] $$param53 = null;
      int $$param54 = 0;
      int $$param55 = 0;
      int[] $$param56 = null;
      int $$param57 = 0;
      int $$param58 = 0;
      int begin = originalBegin;
      int end = originalEnd;
      $$param52 = end - begin;
      int depthLimit = 2 * log2Symb($$param52) + 3;
       
      int[] stack = new int[STACK_SIZE];
       
      int[] depthStack = new int[DEPTH_STACK_SIZE];
      int stackPointer = 0;
      int depthPointer = 0;
      int depth = 0;
      assert !false : "Illegal assignment to stack[stackPointer] = begin conflicting with assignables array[originalBegin .. originalEnd - 1]";
      stack[stackPointer] = begin;
      assert !false : "Illegal assignment to stack[stackPointer + 1] = end conflicting with assignables array[originalBegin .. originalEnd - 1]";
      stack[stackPointer + 1] = end;
      stackPointer += 2;
      assert !false : "Illegal assignment to depthStack[depthPointer] = depth conflicting with assignables array[originalBegin .. originalEnd - 1]";
      depthStack[depthPointer] = depth;
      depthPointer++;
      while (stackPointer > 0) {
        if (depth < depthLimit && (end - begin > IS_THRESH)) {
          $$param53 = array;
          $$param54 = begin;
          $$param55 = end;
          assert !(true && (old31 != $$param53 || $$param55 - 1 > old32 || $$param54 < old33)) : "Illegal assignment to array[begin .. end - 1] conflicting with assignables array[originalBegin .. originalEnd - 1]";
          int pivot = partitionSymb($$param53, $$param54, $$param55);
          if (pivot - begin > end - pivot - 1) {
            assert !false : "Illegal assignment to stack[stackPointer] = begin conflicting with assignables array[originalBegin .. originalEnd - 1]";
            stack[stackPointer] = begin;
            assert !false : "Illegal assignment to stack[stackPointer + 1] = pivot conflicting with assignables array[originalBegin .. originalEnd - 1]";
            stack[stackPointer + 1] = pivot;
            assert !false : "Illegal assignment to begin = pivot + 1 conflicting with assignables array[originalBegin .. originalEnd - 1]";
            begin = pivot + 1;
          } else {
            assert !false : "Illegal assignment to stack[stackPointer] = pivot + 1 conflicting with assignables array[originalBegin .. originalEnd - 1]";
            stack[stackPointer] = pivot + 1;
            assert !false : "Illegal assignment to stack[stackPointer + 1] = end conflicting with assignables array[originalBegin .. originalEnd - 1]";
            stack[stackPointer + 1] = end;
            assert !false : "Illegal assignment to end = pivot conflicting with assignables array[originalBegin .. originalEnd - 1]";
            end = pivot;
          }
          stackPointer += 2;
          depth++;
          assert !false : "Illegal assignment to depthStack[depthPointer] = depth conflicting with assignables array[originalBegin .. originalEnd - 1]";
          depthStack[depthPointer] = depth;
          depthPointer++;
        } else {
          $$param56 = array;
          $$param57 = begin;
          $$param58 = end;
          assert !(true && (old31 != $$param56 || $$param58 - 1 > old32 || $$param57 < old33)) : "Illegal assignment to array[begin .. end - 1] conflicting with assignables array[originalBegin .. originalEnd - 1]";
          insertionSortSymb($$param56, $$param57, $$param58);
          stackPointer -= 2;
          assert !false : "Illegal assignment to begin = stack[stackPointer] conflicting with assignables array[originalBegin .. originalEnd - 1]";
          begin = stack[stackPointer];
          assert !false : "Illegal assignment to end = stack[stackPointer + 1] conflicting with assignables array[originalBegin .. originalEnd - 1]";
          end = stack[stackPointer + 1];
          depthPointer--;
          assert !false : "Illegal assignment to depth = depthStack[depthPointer] conflicting with assignables array[originalBegin .. originalEnd - 1]";
          depth = depthStack[depthPointer];
        }
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old29;
    }
    {
      int quantVar14i = CProver.nondetInt();
      assert !(originalBegin <= quantVar14i && quantVar14i < originalEnd - 1) || array[quantVar14i] <= array[quantVar14i + 1];
    }
    {
      int[] $$param48 = null;
      int[] $$param49 = null;
      int $$param50 = 0;
      int $$param51 = 0;
      $$param48 = array;
      $$param49 = old30;
      $$param50 = originalBegin;
      $$param51 = originalEnd;
      assert permutationSymb($$param48, $$param49, $$param50, $$param51);
    }
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= originalBegin && originalBegin < originalEnd && originalEnd <= array.length; 
      ensures array.length == \old(array.length); 
      ensures (\forall int i; originalBegin <= i < originalEnd - 1; array[i] <= array[i + 1]); 
      ensures permutation(array, \old(array), originalBegin, originalEnd); 
      assignable array[originalBegin .. originalEnd - 1]; 
   */

  public static void quickSort( 
  int[] array, int originalBegin, int originalEnd) {
    int begin = originalBegin;
    int end = originalEnd;
    int depthLimit = 2 * log2(end - begin) + 3;
     
    int[] stack = new int[STACK_SIZE];
     
    int[] depthStack = new int[DEPTH_STACK_SIZE];
    int stackPointer = 0;
    int depthPointer = 0;
    int depth = 0;
    stack[stackPointer] = begin;
    stack[stackPointer + 1] = end;
    stackPointer += 2;
    depthStack[depthPointer] = depth;
    depthPointer++;
    //@ loop_invariant 0 <= stackPointer && stackPointer < STACK_SIZE;
    //@ loop_invariant 0 <= depth && depth <= depthLimit;
    //@ loop_invariant originalBegin <= begin && begin <= end && end <= originalEnd;
    //@ loop_invariant (\forall int i; originalBegin <= i < min(begin, (\min int j; 0 <= j < stackPointer; stack[j])); array[i] <= array[i + 1]);
    //@ loop_invariant (\forall int i; max(end, (\max int j; 0 <= j < stackPointer; stack[j])) <= i < originalEnd; array[i] <= array[i + 1]);
    //@ loop_invariant (\forall int i; originalBegin <= i < originalEnd; (\num_of int k; originalBegin <= k < originalEnd; array[i] == array[k]) == (\num_of int k; originalBegin <= k < originalEnd; array[i] == \old(array[k])));
    //@ loop_modifies stackPointer, depth, stack[0 .. STACK_SIZE - 1], array[originalBegin .. originalEnd - 1];
    //@ loop_decreases (\sum int i; originalBegin <= i < originalEnd; (\num_of int j; i <= j < originalEnd; array[j] < array[i]));
    while (stackPointer > 0) {
      if (depth < depthLimit && (end - begin > IS_THRESH)) {
        int pivot = partition(array, begin, end);
        if (pivot - begin > end - pivot - 1) {
          stack[stackPointer] = begin;
          stack[stackPointer + 1] = pivot;
          begin = pivot + 1;
        } else {
          stack[stackPointer] = pivot + 1;
          stack[stackPointer + 1] = end;
          end = pivot;
        }
        stackPointer += 2;
        depth++;
        depthStack[depthPointer] = depth;
        depthPointer++;
      } else {
        insertionSort(array, begin, end);
        stackPointer -= 2;
        begin = stack[stackPointer];
        end = stack[stackPointer + 1];
        depthPointer--;
        depth = depthStack[depthPointer];
      }
    }
  }
  
  public static void quickSortRecVerf( 
  int[] array, int begin, int end) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= begin && begin < end && end <= array.length);
    }
    int old34 = array.length;
    int[] old35 = array;
    int[] old36 = array;
    int old37 = end - 1;
    int old38 = begin;
    try {
      int $$param63 = 0;
      int[] $$param64 = null;
      int $$param65 = 0;
      int $$param66 = 0;
      int $$param67 = 0;
      int $$param68 = 0;
      int depth = 0;
      $$param63 = end - begin;
      int depthLimit = 2 * log2Symb($$param63) + 3;
      $$param64 = array;
      $$param65 = begin;
      $$param66 = end;
      $$param67 = depth;
      $$param68 = depthLimit;
      assert !(true && (old36 != $$param64 || $$param66 - 1 > old37 || $$param65 < old38)) : "Illegal assignment to array[begin .. end - 1] conflicting with assignables array[begin .. end - 1]";
      quickSortRecImplSymb($$param64, $$param65, $$param66, $$param67, $$param68);
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old34;
    }
    {
      int quantVar15i = CProver.nondetInt();
      assert !(begin <= quantVar15i && quantVar15i < end - 1) || array[quantVar15i] <= array[quantVar15i + 1];
    }
    {
      int[] $$param59 = null;
      int[] $$param60 = null;
      int $$param61 = 0;
      int $$param62 = 0;
      $$param59 = array;
      $$param60 = old35;
      $$param61 = begin;
      $$param62 = end;
      assert permutationSymb($$param59, $$param60, $$param61, $$param62);
    }
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= begin && begin < end && end <= array.length; 
      ensures array.length == \old(array.length); 
      ensures (\forall int i; begin <= i < end - 1; array[i] <= array[i + 1]); 
      ensures permutation(array, \old(array), begin, end); 
      assignable array[begin .. end - 1]; 
   */

  public static void quickSortRec( 
  int[] array, int begin, int end) {
    int depth = 0;
    int depthLimit = 2 * log2(end - begin) + 3;
    quickSortRecImpl(array, begin, end, depth, depthLimit);
  }
  
  public static void quickSortRecImplVerf( 
  int[] array, int begin, int end, int depth, int depthLimit) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= begin && begin <= end && end <= array.length);
    }
    {
      CProver.assume(0 <= depth && depth <= depthLimit && depthLimit < Integer.MAX_VALUE);
    }
    int old39 = array.length;
    int[] old40 = array;
    int[] old41 = array;
    int old42 = end - 1;
    int old43 = begin;
    try {
      int[] $$param73 = null;
      int $$param74 = 0;
      int $$param75 = 0;
      int[] $$param76 = null;
      int $$param77 = 0;
      int $$param78 = 0;
      int[] $$param79 = null;
      int $$param80 = 0;
      int $$param81 = 0;
      int $$param82 = 0;
      int $$param83 = 0;
      int[] $$param84 = null;
      int $$param85 = 0;
      int $$param86 = 0;
      int $$param87 = 0;
      int $$param88 = 0;
      if (end - begin <= IS_THRESH || depth >= depthLimit) {
        $$param73 = array;
        $$param74 = begin;
        $$param75 = end;
        assert !(true && (old41 != $$param73 || $$param75 - 1 > old42 || $$param74 < old43)) : "Illegal assignment to array[begin .. end - 1] conflicting with assignables array[begin .. end - 1]";
        insertionSortSymb($$param73, $$param74, $$param75);
        {
          throw new BlockQuickSort.ReturnException();
        }
      }
      $$param76 = array;
      $$param77 = begin;
      $$param78 = end;
      assert !(true && (old41 != $$param76 || $$param78 - 1 > old42 || $$param77 < old43)) : "Illegal assignment to array[begin .. end - 1] conflicting with assignables array[begin .. end - 1]";
      int pivot = partitionSymb($$param76, $$param77, $$param78);
      $$param79 = array;
      $$param80 = begin;
      $$param81 = pivot;
      $$param82 = depth + 1;
      $$param83 = depthLimit;
      assert !(true && (old41 != $$param79 || $$param81 - 1 > old42 || $$param80 < old43)) : "Illegal assignment to array[begin .. end - 1] conflicting with assignables array[begin .. end - 1]";
      quickSortRecImplSymb($$param79, $$param80, $$param81, $$param82, $$param83);
      $$param84 = array;
      $$param85 = pivot;
      $$param86 = end;
      $$param87 = depth + 1;
      $$param88 = depthLimit;
      assert !(true && (old41 != $$param84 || $$param86 - 1 > old42 || $$param85 < old43)) : "Illegal assignment to array[begin .. end - 1] conflicting with assignables array[begin .. end - 1]";
      quickSortRecImplSymb($$param84, $$param85, $$param86, $$param87, $$param88);
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old39;
    }
    {
      int quantVar16i = CProver.nondetInt();
      assert !(begin <= quantVar16i && quantVar16i < end - 1) || array[quantVar16i] <= array[quantVar16i + 1];
    }
    {
      int[] $$param69 = null;
      int[] $$param70 = null;
      int $$param71 = 0;
      int $$param72 = 0;
      $$param69 = array;
      $$param70 = old40;
      $$param71 = begin;
      $$param72 = end;
      assert permutationSymb($$param69, $$param70, $$param71, $$param72);
    }
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= begin && begin <= end && end <= array.length; 
      requires 0 <= depth && depth <= depthLimit && depthLimit < Integer.MAX_VALUE; 
      ensures array.length == \old(array.length); 
      ensures (\forall int i; begin <= i < end - 1; array[i] <= array[i + 1]); 
      ensures permutation(array, \old(array), begin, end); 
      assignable array[begin .. end - 1]; 
   */

  public static void quickSortRecImpl( 
  int[] array, int begin, int end, int depth, int depthLimit) {
    if (end - begin <= IS_THRESH || depth >= depthLimit) {
      insertionSort(array, begin, end);
      return;
    }
    int pivot = partition(array, begin, end);
    quickSortRecImpl(array, begin, pivot, depth + 1, depthLimit);
    quickSortRecImpl(array, pivot, end, depth + 1, depthLimit);
  }
  
  public static void insertionSortVerf( 
  int[] array, int begin, int end) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= begin && begin <= end && end <= array.length);
    }
    int old44 = array.length;
    int[] old45 = array;
    int[] old46 = array;
    int old47 = end - 1;
    int old48 = begin;
    try {
      int[] $$param93 = null;
      int $$param94 = 0;
      int $$param95 = 0;
      for (int i = begin; i < end; ) {
        int j = i;
        while (j > begin && array[j - 1] > array[j]) {
          $$param93 = array;
          $$param94 = j;
          $$param95 = j - 1;
          assert !(true && (old46 != $$param93 || $$param94 > old47 || $$param94 < old48)) : "Illegal assignment to array[i] conflicting with assignables array[begin .. end - 1]";
          assert !(true && (old46 != $$param93 || $$param95 > old47 || $$param95 < old48)) : "Illegal assignment to array[j] conflicting with assignables array[begin .. end - 1]";
          swapSymb($$param93, $$param94, $$param95);
          j--;
        }
        i++;
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old44;
    }
    {
      int quantVar17i = CProver.nondetInt();
      assert !(begin <= quantVar17i && quantVar17i < end - 1) || array[quantVar17i] <= array[quantVar17i + 1];
    }
    {
      int[] $$param89 = null;
      int[] $$param90 = null;
      int $$param91 = 0;
      int $$param92 = 0;
      $$param89 = array;
      $$param90 = old45;
      $$param91 = begin;
      $$param92 = end;
      assert permutationSymb($$param89, $$param90, $$param91, $$param92);
    }
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= begin && begin <= end && end <= array.length; 
      ensures array.length == \old(array.length); 
      ensures (\forall int i; begin <= i < end - 1; array[i] <= array[i + 1]); 
      ensures permutation(array, \old(array), begin, end); 
      assignable array[begin .. end - 1]; 
   */

  public static void insertionSort( 
  int[] array, int begin, int end) {
    for (int i = begin; i < end; i++) {
      int j = i;
      while (j > begin && array[j - 1] > array[j]) {
        swap(array, j, j - 1);
        j--;
      }
    }
  }
  
  public static void swapVerf( 
  int[] array, int i, int j) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= i && i < array.length);
    }
    {
      CProver.assume(0 <= j && j < array.length);
    }
    int old49 = array.length;
    int old50 = array[j];
    int old51 = array[i];
    int[] old52 = array;
    int old53 = i;
    int old54 = j;
    try {
      int temp = array[i];
      assert !(true && (old52 != array || i > old53 || i < old53) && (array != array || i > old54 || i < old54)) : "Illegal assignment to array[i] = array[j] conflicting with assignables array[i], array[j]";
      array[i] = array[j];
      assert !(true && (old52 != array || j > old53 || j < old53) && (array != array || j > old54 || j < old54)) : "Illegal assignment to array[j] = temp conflicting with assignables array[i], array[j]";
      array[j] = temp;
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old49;
    }
    {
      {
        assert array[i] == old50;
        assert array[j] == old51;
      }
    }
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= i < array.length; 
      requires 0 <= j < array.length; 
      ensures array.length == \old(array.length); 
      ensures array[i] == \old(array[j]) && array[j] == \old(array[i]); 
      assignable array[i], array[j]; 
   */

  public static void swap( 
  int[] array, int i, int j) {
    int temp = array[i];
    array[i] = array[j];
    array[j] = temp;
  }
  
  public static void sortPairVerf(int i1, int i2,  
  int[] array) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= i1 && i1 < array.length);
    }
    {
      CProver.assume(0 <= i2 && i2 < array.length);
    }
    int old55 = array.length;
    int old56 = array[i1];
    int old57 = array[i2];
    int old58 = array[i1];
    int old59 = array[i2];
    int old60 = array[i2];
    int old61 = array[i1];
    int[] old62 = array;
    int old63 = i1;
    int old64 = i2;
    try {
      int[] $$param96 = null;
      int $$param97 = 0;
      int $$param98 = 0;
      if (array[i1] > array[i2]) {
        $$param96 = array;
        $$param97 = i1;
        $$param98 = i2;
        assert !(true && (old62 != $$param96 || $$param97 > old63 || $$param97 < old63) && ($$param96 != $$param96 || $$param97 > old64 || $$param97 < old64)) : "Illegal assignment to array[i] conflicting with assignables array[i1], array[i2]";
        assert !(true && (old62 != $$param96 || $$param98 > old63 || $$param98 < old63) && ($$param96 != $$param96 || $$param98 > old64 || $$param98 < old64)) : "Illegal assignment to array[j] conflicting with assignables array[i1], array[i2]";
        swapSymb($$param96, $$param97, $$param98);
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old55;
    }
    {
      assert (old56 <= old57) ? (array[i1] == old58 && array[i2] == old59) : (array[i1] == old60 && array[i2] == old61);
    }
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= i1 && i1 < array.length; 
      requires 0 <= i2 && i2 < array.length; 
      ensures array.length == \old(array.length); 
      ensures (\old(array[i1]) <= \old(array[i2])) ? (array[i1] == \old(array[i1]) && array[i2] == \old(array[i2])) : (array[i1] == \old(array[i2]) && array[i2] == \old(array[i1])); 
      assignable array[i1], array[i2]; 
   */

  public static void sortPair(int i1, int i2,  
  int[] array) {
    if (array[i1] > array[i2]) {
      swap(array, i1, i2);
    }
  }
  
  public static int medianOf3Verf( 
  int[] array, int begin, int end) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= begin && begin < end && end <= array.length);
    }
    {
      CProver.assume(end - begin >= 3);
    }
    int old65 = array.length;
    int[] old66 = array;
    int[] old67 = array;
    int old68 = begin;
    int old69 = begin + ((end - begin) / 2);
    int old70 = end - 1;
    int returnVar = 0;
    try {
      int $$param103 = 0;
      int $$param104 = 0;
      int[] $$param105 = null;
      int $$param106 = 0;
      int $$param107 = 0;
      int[] $$param108 = null;
      int $$param109 = 0;
      int $$param110 = 0;
      int[] $$param111 = null;
      int mid = begin + ((end - begin) / 2);
      $$param103 = begin;
      $$param104 = mid;
      $$param105 = array;
      assert !(true && (old67 != $$param105 || $$param103 > old68 || $$param103 < old68) && ($$param105 != $$param105 || $$param103 > old69 || $$param103 < old69) && ($$param105 != $$param105 || $$param103 > old70 || $$param103 < old70)) : "Illegal assignment to array[i1] conflicting with assignables array[begin], array[begin + ((end - begin) / 2)], array[end - 1]";
      assert !(true && (old67 != $$param105 || $$param104 > old68 || $$param104 < old68) && ($$param105 != $$param105 || $$param104 > old69 || $$param104 < old69) && ($$param105 != $$param105 || $$param104 > old70 || $$param104 < old70)) : "Illegal assignment to array[i2] conflicting with assignables array[begin], array[begin + ((end - begin) / 2)], array[end - 1]";
      sortPairSymb($$param103, $$param104, $$param105);
      $$param106 = mid;
      $$param107 = end - 1;
      $$param108 = array;
      assert !(true && (old67 != $$param108 || $$param106 > old68 || $$param106 < old68) && ($$param108 != $$param108 || $$param106 > old69 || $$param106 < old69) && ($$param108 != $$param108 || $$param106 > old70 || $$param106 < old70)) : "Illegal assignment to array[i1] conflicting with assignables array[begin], array[begin + ((end - begin) / 2)], array[end - 1]";
      assert !(true && (old67 != $$param108 || $$param107 > old68 || $$param107 < old68) && ($$param108 != $$param108 || $$param107 > old69 || $$param107 < old69) && ($$param108 != $$param108 || $$param107 > old70 || $$param107 < old70)) : "Illegal assignment to array[i2] conflicting with assignables array[begin], array[begin + ((end - begin) / 2)], array[end - 1]";
      sortPairSymb($$param106, $$param107, $$param108);
      $$param109 = begin;
      $$param110 = mid;
      $$param111 = array;
      assert !(true && (old67 != $$param111 || $$param109 > old68 || $$param109 < old68) && ($$param111 != $$param111 || $$param109 > old69 || $$param109 < old69) && ($$param111 != $$param111 || $$param109 > old70 || $$param109 < old70)) : "Illegal assignment to array[i1] conflicting with assignables array[begin], array[begin + ((end - begin) / 2)], array[end - 1]";
      assert !(true && (old67 != $$param111 || $$param110 > old68 || $$param110 < old68) && ($$param111 != $$param111 || $$param110 > old69 || $$param110 < old69) && ($$param111 != $$param111 || $$param110 > old70 || $$param110 < old70)) : "Illegal assignment to array[i2] conflicting with assignables array[begin], array[begin + ((end - begin) / 2)], array[end - 1]";
      sortPairSymb($$param109, $$param110, $$param111);
      {
        returnVar = mid;
        throw new BlockQuickSort.ReturnException();
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old65;
    }
    {
      assert returnVar == begin + ((end - begin) / 2);
    }
    {
      {
        assert array[begin] <= array[returnVar];
        assert array[returnVar] <= array[end - 1];
      }
    }
    {
      int[] $$param99 = null;
      int[] $$param100 = null;
      int $$param101 = 0;
      int $$param102 = 0;
      $$param99 = array;
      $$param100 = old66;
      $$param101 = begin;
      $$param102 = end;
      assert permutationSymb($$param99, $$param100, $$param101, $$param102);
    }
    return returnVar;
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= begin && begin < end && end <= array.length; 
      requires end - begin >= 3; 
      ensures array.length == \old(array.length); 
      ensures \result == begin + ((end - begin) / 2); 
      ensures array[begin] <= array[\result] && array[\result] <= array[end - 1]; 
      ensures permutation(array, \old(array), begin, end); 
      assignable array[begin], array[begin + ((end - begin) / 2)], array[end - 1]; 
   */

  public static int medianOf3( 
  int[] array, int begin, int end) {
    int mid = begin + ((end - begin) / 2);
    sortPair(begin, mid, array);
    sortPair(mid, end - 1, array);
    sortPair(begin, mid, array);
    return mid;
  }
  
  public static int partitionVerf( 
  int[] array, int begin, int end) {
    {
      CProver.assume(array != null);
    }
    {
      CProver.assume(0 <= begin && begin < end && end <= array.length);
    }
    {
      CProver.assume(end - begin >= 3);
    }
    int old71 = array.length;
    int[] old72 = array;
    int[] old73 = array;
    int old74 = end - 1;
    int old75 = begin;
    int returnVar = 0;
    try {
      int[] $$param116 = null;
      int $$param117 = 0;
      int $$param118 = 0;
      int[] $$param119 = null;
      int $$param120 = 0;
      int $$param121 = 0;
      int $$param122 = 0;
      $$param116 = array;
      $$param117 = begin;
      $$param118 = end;
      assert !(true && (old73 != $$param116 || $$param117 > old74 || $$param117 < old75)) : "Illegal assignment to array[begin] conflicting with assignables array[begin .. end - 1]";
      assert !(true && (old73 != $$param116 || $$param117 + (($$param118 - $$param117) / 2) > old74 || $$param117 + (($$param118 - $$param117) / 2) < old75)) : "Illegal assignment to array[begin + ((end - begin) / 2)] conflicting with assignables array[begin .. end - 1]";
      assert !(true && (old73 != $$param116 || $$param118 - 1 > old74 || $$param118 - 1 < old75)) : "Illegal assignment to array[end - 1] conflicting with assignables array[begin .. end - 1]";
      int mid = medianOf3Symb($$param116, $$param117, $$param118);
      $$param119 = array;
      $$param120 = begin + 1;
      $$param121 = end - 1;
      $$param122 = mid;
      assert !(true && (old73 != $$param119 || $$param121 - 1 > old74 || $$param120 < old75)) : "Illegal assignment to array[originalBegin .. originalEnd - 1] conflicting with assignables array[begin .. end - 1]";
      {
        returnVar = hoareBlockPartitionSymb($$param119, $$param120, $$param121, $$param122);
        throw new BlockQuickSort.ReturnException();
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array.length == old71;
    }
    {
      {
        assert begin <= returnVar;
        assert returnVar < end;
      }
    }
    {
      int quantVar18i = CProver.nondetInt();
      assert !(begin <= quantVar18i && quantVar18i <= returnVar) || array[quantVar18i] <= array[returnVar];
    }
    {
      int quantVar19i = CProver.nondetInt();
      assert !(returnVar <= quantVar19i && quantVar19i < end) || array[returnVar] <= array[quantVar19i];
    }
    {
      int[] $$param112 = null;
      int[] $$param113 = null;
      int $$param114 = 0;
      int $$param115 = 0;
      $$param112 = array;
      $$param113 = old72;
      $$param114 = begin;
      $$param115 = end;
      assert permutationSymb($$param112, $$param113, $$param114, $$param115);
    }
    return returnVar;
  }
    /*@
    public normal_behavior
      requires array != null; 
      requires 0 <= begin && begin < end && end <= array.length; 
      requires end - begin >= 3; 
      ensures array.length == \old(array.length); 
      ensures begin <= \result && \result < end; 
      ensures (\forall int i; begin <= i <= \result; array[i] <= array[\result]); 
      ensures (\forall int i; \result <= i < end; array[\result] <= array[i]); 
      ensures permutation(array, \old(array), begin, end); 
      assignable array[begin .. end - 1]; 
   */

  public static int partition( 
  int[] array, int begin, int end) {
    int mid = medianOf3(array, begin, end);
    return hoareBlockPartition(array, begin + 1, end - 1, mid);
  }
  
   
  public static int log2Verf(int n) {
    {
      CProver.assume(n > 0);
    }
    int returnVar = 0;
    try {
      int log2Value = 0;
      while (n > 1) {
        n /= 2;
        log2Value++;
      }
      {
        returnVar = log2Value;
        throw new BlockQuickSort.ReturnException();
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      {
        assert 0 <= returnVar;
        assert (1 << (returnVar - 1)) < n;
        assert n <= (1 << returnVar);
        assert returnVar <= 31;
      }
    }
    return returnVar;
  }
    /*@
    public normal_behavior
      requires n > 0; 
      ensures 0 <= \result && (1 << (\result - 1)) < n && n <= (1 << \result) && \result <= 31; 
   */

   
  public static int log2(int n) {
    int log2Value = 0;
    while (n > 1) {
      n /= 2;
      log2Value++;
    }
    return log2Value;
  }
  
  public static int minVerf(int a, int b) {
    int returnVar = 0;
    try {
      {
        returnVar = a < b ? a : b;
        throw new BlockQuickSort.ReturnException();
      }
    } catch (BlockQuickSort.ReturnException ex) {
    } catch (java.lang.RuntimeException e) {
      CProver.assume(false);
    }
    return returnVar;
  }
    /*@
    public behavior
      signals_only java.lang.RuntimeException; 
   */

  public static int min(int a, int b) {
    return a < b ? a : b;
  }
  
  public static int maxVerf(int a, int b) {
    int returnVar = 0;
    try {
      {
        returnVar = a > b ? a : b;
        throw new BlockQuickSort.ReturnException();
      }
    } catch (BlockQuickSort.ReturnException ex) {
    } catch (java.lang.RuntimeException e) {
      CProver.assume(false);
    }
    return returnVar;
  }
    /*@
    public behavior
      signals_only java.lang.RuntimeException; 
   */

  public static int max(int a, int b) {
    return a > b ? a : b;
  }
  
   
  public static boolean permutationVerf( 
  int[] array1,  
  int[] array2, int begin, int end) {
    {
      CProver.assume(array1 != null);
    }
    {
      CProver.assume(array2 != null);
    }
    {
      CProver.assume(0 <= begin && begin <= end && end <= array1.length);
    }
    {
      CProver.assume(array1.length == array2.length);
    }
    int old76 = array1.length;
    int old77 = array2.length;
    boolean returnVar = true;
    try {
      for (int i = begin; i < end; ) {
        int count1 = 0;
        int count2 = 0;
        for (int j = begin; j < end; ) {
          if (array1[i] == array1[j]) {
            count1++;
          }
          if (array1[i] == array2[j]) {
            count2++;
          }
          j++;
        }
        if (count1 != count2) {
          {
            returnVar = false;
            throw new BlockQuickSort.ReturnException();
          }
        }
        i++;
      }
      {
        returnVar = true;
        throw new BlockQuickSort.ReturnException();
      }
    } catch (BlockQuickSort.ReturnException ex) {
    }
    {
      assert array1.length == old76;
    }
    {
      assert array2.length == old77;
    }
    {
      int quantVar20i = CProver.nondetInt();
      int sum_4 = 0;
      int sum_5 = 0;
      boolean b_7 = false;
      int sum_6 = 0;
      int sum_7 = 0;
      if (!!returnVar) {
        if (!!(begin <= quantVar20i && quantVar20i < end)) {
          sum_4 = 0;
          for (int quantVar21j = begin; begin <= quantVar21j && end - 1 >= quantVar21j; ++quantVar21j) {
            sum_4 += array1[quantVar20i] == array1[quantVar21j] ? 1 : 0;
          }
          sum_5 = 0;
          for (int quantVar22j = begin; begin <= quantVar22j && end - 1 >= quantVar22j; ++quantVar22j) {
            sum_5 += array1[quantVar20i] == array2[quantVar22j] ? 1 : 0;
          }
        }
      }
      if (!returnVar || (!(begin <= quantVar20i && quantVar20i < end) || ((sum_4) == (sum_5)))) {
        b_7 = false;
        for (int quantVar23i = begin; begin <= quantVar23i && end - 1 >= quantVar23i; ++quantVar23i) {
          sum_6 = 0;
          for (int quantVar24j = begin; begin <= quantVar24j && end - 1 >= quantVar24j; ++quantVar24j) {
            sum_6 += array1[quantVar23i] == array1[quantVar24j] ? 1 : 0;
          }
          sum_7 = 0;
          for (int quantVar25j = begin; begin <= quantVar25j && end - 1 >= quantVar25j; ++quantVar25j) {
            sum_7 += array1[quantVar23i] == array2[quantVar25j] ? 1 : 0;
          }
          b_7 = b_7 || !((sum_6) == (sum_7));
        }
      }
      {
        assert !returnVar || (!(begin <= quantVar20i && quantVar20i < end) || ((sum_4) == (sum_5)));
        assert b_7 || returnVar;
      }
    }
    return returnVar;
  }
    /*@
    public normal_behavior
      requires array1 != null; 
      requires array2 != null; 
      requires 0 <= begin && begin <= end && end <= array1.length; 
      requires array1.length == array2.length; 
      ensures array1.length == \old(array1.length); 
      ensures array2.length == \old(array2.length); 
      ensures \result == (\forall int i; begin <= i < end; ((\num_of int j; begin <= j < end; array1[i] == array1[j]) == (\num_of int j; begin <= j < end; array1[i] == array2[j]))); 
   */

   
  public static boolean permutation( 
  int[] array1,  
  int[] array2, int begin, int end) {
    //@ loop_invariant begin <= i <= end;
    //@ loop_invariant (\forall int j; begin <= j < i; (\num_of int k; begin <= k < end; array1[j] == array1[k]) == (\num_of int k; begin <= k < end; array1[j] == array2[k]));
    //@ loop_modifies i;
    //@ loop_decreases end - i;
    for (int i = begin; i < end; i++) {
      int count1 = 0;
      int count2 = 0;
      //@ loop_invariant begin <= j <= end;
      //@ loop_invariant count1 == (\num_of int k; begin <= k < j; array1[i] == array1[k]);
      //@ loop_invariant count2 == (\num_of int k; begin <= k < j; array1[i] == array2[k]);
      //@ loop_modifies j, count1, count2;
      //@ loop_decreases end - j;
      for (int j = begin; j < end; j++) {
        if (array1[i] == array1[j]) {
          count1++;
        }
        if (array1[i] == array2[j]) {
          count2++;
        }
      }
      if (count1 != count2) {
        return false;
      }
    }
    return true;
  }
  
  public static class ReturnException extends java.lang.RuntimeException {
  }
}